<?php 

namespace App\Trustwork;


	
class Helper 
{
	
	public function explode_cash($cash)
	{
		$cash = explode(',', $cash);
		if ( count($cash) > 1)
		 {
			$merge = $cash[0].$cash[1];
		return $merge; 
		}
		$merge = $cash[0];
		return $merge; 
	}	

}
 ?>