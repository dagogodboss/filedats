<?php 

namespace App\Trustwork;

use App\User;
use App\GetHelp;
use App\Messages;
use Carbon\Carbon;
use App\AdminTable;
use App\ProvideHelp;
use App\MatchedUser;
use App\Trustwork\Helper;
use App\Recommitment_table;
use Illuminate\Support\Facades\Auth;

class Trust
{
	protected $helper;
	
	public function __construct()
	{
		$this->helper = new Helper();
	}

	public function VerifyUser($data)
	{
		$data->phone_token = str_random(6);
		$data->save();	
		
		$phone_number = $data->phone_token;
        
        $phone_number = substr($phone_number, 1);
        
        $phone_number = '234'.$phone_number;

		$this->send_token($data->phone_number, $phone_number, config('app.sms.welcome'));
		return $data;
	}

	public function send_token($phone_number, $token=null, $msg)
	{
        $data = [
            'username' => config('app.sms_username'),
            'password' => config('app.sms_password'),
            'sender'   => config('app.send_by'),
            'mobiles'   => $phone_number,
            'message'  => $msg.$token,
        ];

		$ch = curl_init();
	    curl_setopt($ch, CURLOPT_URL, config('app.sms_url'));
	    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");  
	    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
    	$res = curl_exec($ch);
    	//return 1701;
    	if($res === 1701){
    		
    		return 1701;
    	}
    	elseif($res === 1702){
    		return redirect('home')->with('error', 'There is an error with the supplied phone number');
    	}else{
    		return redirect('home')->with('error', 'We Encoutered an Error please try again later.');
    	}
	}

	public function AddRecomitment($data)
	{
		// explode the user amount
		$amount = $this->helper->explode_cash($data->plan);

		$recomit_amount = ($amount * config('app.recomit_pecentage')) + $amount ;

		$matched_amount = ($amount * config('app.recomit_pecentage'));
		// select from Admin db

		$admin = AdminTable::inRandomOrder()->first();

			$matchuser = MatchedUser::create([
				'sponsor_user_id' 				=> $admin->user_id,
				'provider_user_id'				=> $data->id,
				'amount'						=> $matched_amount,
				'payment_status'				=> 'no',
				'recommit'						=> 'yes',
			]);

			if($matchuser) 
			{
				Messages::create([

					'user_id' => $data->id,
					'message' => 'Welcome '.$data->name.', your Registration was successful. You selected the '.$data->plan.' Plan, you are required to pay a 50% upfront Donation of the plan you selected as Re-Commitment Charge. After two days you will be matched to donate a 100% of your plan to your up liner or sponsor. The Fifty Percent is protecting you and other users. So the Total cash you will be paying is NGN '.$recomit_amount.''

				]);
			}

		return $data;
	}

}
