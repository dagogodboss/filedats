<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GetHelp extends Model
{
    protected $fillable = 
    [
    	'amount',
        'user_id',
        'user_permission',

    ];

    public function user()
    {
        return $this->belongsTo('App\User');
    }
}
