<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Messages extends Model
{
    protected $fillable = [
    	'user_id',
    	'status',
    	'message',
    ];

    public function user()
    {
    	return $this->belongsTo('App\User');
    }
}
