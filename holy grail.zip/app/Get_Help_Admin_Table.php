<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Get_Help_Admin_Table extends Model
{
    protected $fillable = [
    	'user_id',
    	'amount',
    	'just_use',
    ];

    public function user()
    {
    	return $this->belongsTo(User::class);
    }
}
