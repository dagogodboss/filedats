<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MatchedUser extends Model
{

	protected $fillable = [
		'sponsor_user_id', 
		'provider_user_id', 
		'amount',
		'payment_status',
		'payment_proof',
		'recommit',
	];

	public function user()
	{
		return $this->belongsTo('App\User');
	}

}
