<?php

namespace App\Http\Middleware;

use Closure;
use App\User;

class RecycleMiddleware
{

    public function handle($request, Closure $next)
    {
        if(\Auth::user()->payment_status == 'recycle')
        {
            abort(408);
        }
        return $next($request);
    }
}
