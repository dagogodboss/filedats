<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class VerifiedAccount
{

    public function handle($request, Closure $next)
    {
        if (Auth::user()->verified == false) {
        	if (Auth::user()->verification_count()->get()->count() >= 3) 
        	{
        		Auth::user()->account_state = 'blocked';
        		Auth::user()->save();
        		abort(406);
        	}
            return abort(410);
        }
        return $next($request);
    }
}
