<?php
        $gh    = GH::where('amount', $user->investment_plan_amount)
                    ->oldest()
                    ->first();

           if ($gh) {


            $data = new GH();
            $getUser = new User();
            $user->findOrFail(\Auth::user()->id);
            if(!Assign::where('sponsor_user_id', $gh->user_id)->where('provider_user_id',$user->id)){
           
            
            $addMatch = Assign::create([
            'sponsor_user_id' => $gh->user_id,
            'sponsor_user_name' => $gh->user_name,
            'sponsor_user_email' => $gh->user_email,
            'sponsor_user_phone' => $gh->user_phone,
            'sponsor_user_account_number' => $gh->account_number,
            'sponsor_user_bank_name' => $gh->bank_name,
            'sponsor_user_investment_plan_id' => $gh->investment_plan_id,
            'sponsor_user_investment_plan_name' => $gh->investment_plan_name,
            'sponsor_user_amount' => $gh->amount,
            'provider_user_id' => $user->id,
            'provider_user_name' => $user->name,
            'provider_user_email' => $user->email,
            'provider_user_phone' => $user->phone_number,
            'provider_user_account_number' => $user->account_number,
            'provider_user_bank_name' => $user->bank_name,
            'provider_user_investment_plan_id' => $user->investment_plan_id,
            'provider_user_investment_plan_name' => $user->investment_plan_name,
            'provider_user_amount' => $user->investment_plan_amount,

            ]);
        }
            $gh->destroy($gh->user_id);
            $user =    User::findOrFail(\Auth::user()->id);
            $match = $this->matchUsers($user,$gh);      
            }