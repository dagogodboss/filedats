<?php

namespace App\Http\Controllers;

use App\AdminTable;
use Illuminate\Http\Request;

class FrontierController extends Controller
{

    public function index()
    {
        return view('admin.frontier.index',[
            'users' => AdminTable::where('user_id','!=', '0')->paginate(config('app.per_page')),
            ]); 
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(AdminTable $user, $id)
    {
        return view('admin.frontier.edit',[
            'user' => $user->find($id),
            ]);
    }

    public function update(Request $request, AdminTable $user)
    {
        $this->validate($request,[
             'name' => 'required|max:255',
            'bank_name' => 'required|string|min:6',
            'account_number' => 'required|digits:10',
        ]);

        $update = $user->find($request->id);
        if($update->update($request->all())){
            return redirect('/frontier')->with('success','Update Done');
        }
    }

    
    public function destroy($id)
    {
        AdminTable::find($id)->delete();
        return back()->with('error', 'You have deleted a Frontier');
    }
}
