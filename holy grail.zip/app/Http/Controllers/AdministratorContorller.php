<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdministratorContorller extends Controller
{
    public	function __construct()
	{

	}
   	
   	public function index(Request $request)
   	{
         return view('admin.main');
   	}
}
