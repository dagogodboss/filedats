<?php

namespace App\Http\Controllers;

use App\User;
use App\MatchedUser;
use App\ProvideHelp;
use App\PurgeComplain;
use Illuminate\Http\Request;
use App\Http\Controllers\Payment\FakePayment;

class ReserveListController extends Controller
{
    public $fake;

    private $DonationList;

    public function __construct(){
        $this->middleware('role:admin');
        $this->fake = new FakePayment();
        $this->DonationList = new ProvideHelp();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.reservelist.index',[
            'matches' => MatchedUser::where('sponsor_user_id','!=', '0')->paginate(config('app.per_page')),
            ]); 
    }
   
    
    public function show(MatchedUser $reserveList, $id)
    {
        $data = $reserveList->find($id);
        $data->payment_status = 'fake';
        $data->save();
        $user1 = User::find($data->provider_user_id);
        $user2 = User::find($data->sponsor_user_id);
        $userComplain = PurgeComplain::create([
            'matched_id'            => $id,
            'payer_id'              => $data->provider_user_id,
            'payer_account_name'    => $user1->name,
            'payer_account_number'  => $user1->account_number,
            'payer_bank_name'       => $user1->bank_name,
            'payer_phone_number'    => $user1->phone_number,
            'amount'                => $data->amount,
            'complainer_id'         => $data->sponsor_user_id,
            'complanier_name'       => $user2->name,
            'complanier_account_number' => $user2->account_number,
            'complanier_bank_name'  => $user2->bank_name,
            'complanier_phone_number'   => $user2->phone_number,
            'proof_of_payment'      => '$randomName',
            'mode_of_payment'       => 'admin',
            'identification_number' => '$data->identification_number',
        ]);
        $this->fake->add_to_Transaction_table($data);
        $this->fake->message_user($userComplain);

        return redirect('/reservelist')->with('success', 'Purge Process Started :)');
    }

    public function edit(MatchedUser $reserveList,$id)
    {
        return view('admin.reservelist.edit', [
            'reservelist' => $reserveList->find($id), 
        ]);
    }

    public function update(Request $request, MatchedUser $reserveList, $id)
    {

        $data = $reserveList->find($id);
        $input = $request->except([
            '_token',
            ]);
        $data->fill($input);
        $data->save();
        return redirect('/reservelist')->with('success', 'The Editing was Successful');
    }

    protected function Confirm(MatchedUser $reserveList,Request $request)
    {
        $listDetials = $reserveList->find($request->uuid);
        if($listDetials != null){
            $amountEarn  =    ($listDetials->reserve_amount * config('app.percent')) + $listDetials->reserve_amount;
            $earning_user = User::find($listDetials->provider_user_id);
            $earning_user_donation = $earning_user->gethelp()->first();
            switch ($earning_user_donation) {
                case null:
                   if($this->add_user_donation_list($earning_user, $amountEarn) && $this->fake->add_to_Transaction_table($listDetials) && $this->DeleteReservation($request->uuid))
                   {
                        return back()->with('success', 'Confrimation Done');
                   }
                   else{
                        dd('Hello I\'m tired for now talk to you later.');
                    }
                    break;
                
                default:
                    $earning_user_donation->amount = $earning_user_donation->amount + $amountEarn;
                    if($earning_user_donation->save() && $this->fake->add_to_Transaction_table($listDetials) && $this->DeleteReservation($request->uuid)){
                     return back()->with('success', 'Confrimation Done');
                    }
                    else{
                        dd('Hello I\'m tired for now talk to you later.');
                    }
                    break;
            }
        }
    }

    private function add_user_donation_list($user, $amount)
    {
        if($this->DonationList->create([
            'amount'        => $amount,
            'user_id'       => $user->id,
            'user_name'     => $user->name,
            'user_email'    => $user->email,
            'username'      => $user->username,
            'bank_name'     => $user->bank_name,
            'phone_number'  => $user->phone_number,
            'account_number'=> $user->account_number,
        ]))
        {
            return true;
        }
    }

    private function DeleteReservation($id){
        if(MatchedUser::find($id)->delete()){
            return true;
        }
    }

    protected function Delete(Request $request, MatchedUser $reservelist){
        if($reservelist->find($request->uuid)->delete()){
            return back()->with('success', 'You have Delete that data');
        }
    }
}
