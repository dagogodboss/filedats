<?php

namespace App\Http\Controllers;

use App\Messages;
use App\ContactSupport;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function index()
    {
        return view('admin.contact.index',[
            'contact' => ContactSupport::paginate(50),
        ]);
    }

    public function create()
    {
        //
    }

    public function reply_message_users(Request $request, ContactSupport $contact)
    {
        $this->validate($request,[
            'message' => 'required',
        ]);

        if(Messages::create($request->all())){
            if($contact->find($request->id)->delete()){
                return back()->with('success', 'Message Sent! :)');
            }
        }
    }

    public function show(ContactSupport $contact, $id)
    {
        if($contact->find($id)->delete()){
            return back()->with('success', 'Contact message has been deleted.');
        }
    }


    public function edit($id)
    {
        //
    }
    public function update(Request $request, $id)
    {
        //
    }
    public function destroy($id)
    {
        //
    }
}
