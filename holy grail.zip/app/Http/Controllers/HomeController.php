<?php

namespace App\Http\Controllers;

use App\User;
use App\Messages;
use Carbon\Carbon;
use App\AdminTable;
use App\SiteControl;
use App\MatchedUser;
use App\Trustwork\Trust;
use App\Trustwork\Helper;
use App\GetHelp as GH;
use App\ProvideHelp as PH;
use Illuminate\Http\Request;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\Auth;
use Illuminate\Contracts\Auth\Guard;

class HomeController extends Controller
{

    protected $roadak;
    
    protected $users;

    protected $helper;

    protected $MatchedUsersTable;

    protected $startDownliner;

    public function __construct(Guard $auth)
    {
        $this->auth = $auth;
        $this->middleware('auth');
        $this->middleware('verified');
        $this->users                = new User();
        $this->helper               = new Helper();
        $this->roadak               = new Trust();
        $this->MatchedUsersTable    = new MatchedUser();
    }

    protected function outgoing_cash(){
        return view('user.pay.out_going', [
            'Donation_To_Pay' => $this->auth->user()->DoantionToPay()->whereNull('recommit')->get(),
        ]);
    }

    protected function index(SiteControl $crtl, AdminTable $admin_users_table, User $users_table)
    {
        $this->auth->user()->getReferrals();
        $this->upgrade_user();        
        if(Auth::user()->messages()->where('status', 'unread')->first() != null) 
        {
            return view('user.messages.read', [
                'message' => Auth::user()->messages()->where('status', 'unread')->first(),
            ]);
        }
        if(Auth::user()->payment_status == 'recycle')
        {
            abort(408);
        }
        if(Auth::user()->recommit()->where('recommit', 'yes')->first() != null) 
        {
            $matched_details = Auth::user()->recommit()->where('recommit', 'yes')->first();
            $sponsor_details = AdminTable::where('user_id', $matched_details->sponsor_user_id)->first();
            $cash            = $matched_details->amount;
            return view('user.pay.recomit', [
                'amount'    => $cash,
                'sponsor'   => $sponsor_details,
                'matched_details'  => $matched_details,
            ]);
        }

        if(Auth::user()->recommitpayment()->where('recommit', 'yes')->first() != null) 
        {
            $matched_details = Auth::user()->recommitpayment()->where('recommit', 'yes')->first();
            $payer_details = User::find($matched_details->provider_user_id);
            
            $cash            = $matched_details->amount;
            return view('user.pay.confirmRecomit', [
                'amount'    => $cash,
                'payer'  => $payer_details,
                'matched_details'  => $matched_details,
            ]);
        }

        if (Auth::user()->provide_help()->first() != null) 
        {
            if (Auth::user()->provide_help()->first()->created_at->diffInDays(Carbon::now()) < 14) {
                return view('user.pay.timer');
            }
        }
        
        
        $Donation_To_Pay = $this->auth->user()->DoantionToPay()->get();
        
        $Donation_To_Receive = $this->auth->user()->DonationToRecieve()->get();
        return view('home', [
           'Donation_To_Pay'    => $Donation_To_Pay,
           'Donation_To_Receive'=> $Donation_To_Receive,
        ]);

    }



    protected function AddPlan(Request $req){

        $investId = $this->plan->findOrFail($req->id);

        $user =     User::findOrFail(\Auth::user()->id);
        
        $user->update([
                'plan'        => $investId->amount,
                'number_of_recycle' => Auth::user()->number_of_recycle + 1,                
        ]);
        
        $amount = $this->helper->explode_cash($user->plan);

        $recomit_amount = ($amount * config('app.recomit_pecentage')) + $amount ;

        $matched_amount = ($amount * config('app.recomit_pecentage'));
        
        $admin = AdminTable::inRandomOrder()->first();

            $matchuser = MatchedUser::create([
                'sponsor_user_id'               => $admin->user_id,
                'provider_user_id'              => $user->id,
                'amount'                        => $matched_amount,
                'payment_status'                => 'no',
                'recommit'                      => 'yes',
            ]);

            if($matchuser) 
            {
                Messages::create([

                    'user_id' => $user->id,
                    'message' => 'Hello '.$user->name.', you have changed your plan. You selected the NGN'.$user->plan.' Plan, you are required to pay a 50% upfront Donation of this plan you selected as Re-Commitment Charge. After two days you will be matched to donate a 100% of this same plan to your up liner or sponsor.The Fifty Percent is protecting you and other users. So the Total cash you will be paying is NGN '.$recomit_amount.''

                ]);
            }
            return 1;
    }

    protected function upgrade_user(){
       $count = Auth::user()->referrals()->get()->count();
        if($count > config('app.upgrade_count')){
            if(!Auth::user()->hasRole('leader')){
                dd(Auth::user()->assign('leader'));

            }
        }
    }

    protected function recycle(Request $req){

        $user =     User::findOrFail(\Auth::user()->id);

        $newPH = new PH();

        $newPH->create([
            'user_id'               => $user->id,
            'amount'                => $user->amount,
           

            ]);

            $user->update([
                'plan'        => $user->plan,    
                'number_of_recycle' => Auth::user()->number_of_recycle + 1,
                'payment_status'  => 'pay-pledge',            
                ]);

            return 1;
    }

    protected function resets(Request $request)
    {
        Auth::user()->plan = '';
        Auth::user()->payment_status = null;
        Auth::user()->save();
        return 1;
    }

}
