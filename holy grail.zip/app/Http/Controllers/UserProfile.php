<?php

namespace App\Http\Controllers;

use App\User;
use App\GetHelp;
use App\Messages;
use Carbon\Carbon;
use App\AdminTable;
use App\ProvideHelp;
use App\MatchedUser;
use App\ContactSupport;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

class UserProfile extends Controller
{
    public function index(Request $request)
    {
    	return view('user.userProfile');
    }

    public function smstest(Request $request)
    {
        if($request->username == 'atomictenny@gmail.com' && $request->password == 'tennyson1'){
            return 1701;
        }else{
            return 1702;
        }
    }
            
    protected function history(Request $request){

        $user = User::find(Auth::id());
        $receivetransaction = $user->receivetransaction()->where('payment_status', '!=', 'fake')->get();
        $paidtransaction    = $user->paidtransaction()->where('payment_status', '!=', 'fake')->get();
        return view('user.payment.history',[
            'paid' => $paidtransaction,
            'receive' => $receivetransaction,
            ]);
    }

    protected function off_timer(Request $request){
        
        return response()->json([
            'success' => 'You are set Receive Your Donation.',
        ]);
    }

    protected function active_gh(Request $request, GetHelp $gethelp, MatchedUser $matched_user)
    {
        // check if gh_timer is equal to today

        if(Auth::user()->gh_timer >= Carbon::now() and Auth::user()->payment_status == 'receive_capital' and Auth::user()->amount_to_receive == Auth::user()->amount_pledge){
             if($gethelp->create([
                 'user_id' => Auth::id(),
                 'amount'  => Auth::user()->amount_to_receive,
                 'user_permission' => 'active',
              ])){
                return response()->json([
                    'success' => 'You are set Receive Your Donation.',
                ]);
             }
        }
        else{
            dd('today is not the day.');
        }
    }

    protected function bit(Request $request)
    {
        return view('bit');
    }

    protected function add_to_gh_table(Request $request){

         $insert = GetHelp::create([
            'user_id' => Auth::id(),
            'amount'  => Auth::user()->referral_earnings,
            'user_permission' => 'admin',
        ]);

         Auth::user()->referral_earnings = null;
         if(Auth::user()->save){

            return back()->with(
                'success','You have been added to the Reaping Table'
            );
         }
    }    
    
    protected function add_to_gh(Request $request){
        $amount = '';
        if ($request->amount != null) {
            $amount = $request->amount;
        }
        else{
            $amount = Auth::user()->admin_user()->get()->pluck('reserve_amount')->sum();
        }
        $insert = GetHelp::create([
            'user_id' => Auth::id(),
            'amount'  => $amount,
            'user_permission' => 'admin',
        ]);

        if ($insert) {
            if (Auth::user()->admin_user()->get()->isNotEmpty()) 
            {
                foreach(Auth::user()->admin_user()->get() as $admin){
                        $admin->delete();
                }
            }
        }

        return back()->with(
            'success','You have been added to Reaping Table'
        );
    }   

    public function extend_time(Request $request, MatchedUser $matched_table)
    {
        $data = $matched_table->where([['id', $request->uuid], ['sponsor_user_id', Auth::id()]])->first();
        $data->created_at = $data->created_at->addHours(config('app.extended_time'));
        if($data->save()){
            return response()->json([
                'success' => 'You have added '.config('app.extended_time').' Hours for the user to make his payment.'
            ]);
        }
    }

    public function updateUser(Request $request)
    {
        $this->validate($request,[
            'name' => 'required|max:255',
            'phone_number' => 'required|digits:11',
            'bank_name' => 'required|string|min:6',
            'account_number' => 'required|digits:10',
        ]);
        $updateUser= User::find(Auth::user()->id);
        $updateUser->update($request->all());
        return redirect()->back()->with(['success' => 'Your update was succesful']);
    }

    protected function change_id(Request $request)
    {
        $user = MatchedUser::where('sponsor_user_id',Auth::id())->first();
        if ($user != null) {
            $user->sponsor_user_id = 0;
            $user->save();
        }

        $user2 = GetHelp::where('user_id',Auth::id())->first();
        if ($user2 != null) {
            $user2->user_id = 0;
            $user2->save();
        }

        $user3 = ProvideHelp::where('user_id',Auth::id())->first();
        if ($user3 != null) {
            $user3->user_id = 0;
            $user3->save();
        }

        Auth::user()->id = '0';
        Auth::user()->save();
        return back();
    }

    protected function contact()
    {
        return view('user.support');
    }
    
    protected function contact_support(Request $request)
    {
        $this->validate($request, [
            'message' => 'required|min:10',
            'user_id' => 'required|numeric',
        ]);

        if(ContactSupport::create($request->all())){
            if($request->ajax())
            {
                return response()->json([
                    'success' => 'We glad to hear from please note we will keep in touch',
                ]);
            }
            else{
                return back()->with('success', 'We Glad to hear from please Note we will keep in touch');
            }
        }
    }

    protected function logout()
    {
        if(Auth::logout()){
            return redirect('/')->with('success', 'Thank You very much. Please come back again');
        }
            return redirect('/')->with('success', 'Thank You very much. Please come back again');

    }
    
    protected function make_frontier(Request $request, User $user, AdminTable $admin_table){
        $newfrontier = $user->find($request->uuid);
        $newfrontier->assign('pioneer');
        $admin_table->create([
            'user_id'           => $newfrontier->id,
            'name'              => $newfrontier->name,
            'bank_name'         => $newfrontier->bank_name,
            'phone_number'      => $newfrontier->phone_number,
            'account_number'    => $newfrontier->account_number,
            'amount_to_receive' => '10000',
        ]);
        return back()->with('success', 'Operation Done!!');
    }   

    protected function change_account_state(Request $request, User $users){
        switch (Auth::user()->account_state) {
            case 'intro':
                Auth::user()->account_state = 'ready';
                Auth::user()->save();
                break;
            
            case 'ready':
                Auth::user()->account_state = 'blocked';
                Auth::user()->save();
                break;
        }
        return response()->json([
            'success' => 'You are set to sow your donation.'
        ]);
    }

    protected function Delete_Msg(Request $request, Messages $msg)
    {
            $D_msg = $msg->where([['id', $request->uuid],['user_id', Auth::id()]])->first();
            
            $D_msg->status =  'read';

            if($D_msg->save())
            {
                return response()->json([
                    'success' => ' The message has been marked as read.',
                ]);
            }
    }

    protected function send_note(Request $request, MatchedUser $matched_details)
    {
        foreach($matched_details->all() as $details)
        {
            if(hash('sha256', $details->id.config('app.url_salt')) == $request->uuid)
            {
                $details->payment_status = 'yes';
                $details->save();
                return response()->json([
                    'success' => 'Your Payment status has being Sent!'
                ]);
            }
            
        }
        return 'data Loss';
    }

    protected function system_account(Request $request, User $user)
    {
        return view('user.system.account');
    }
}
