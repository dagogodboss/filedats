<?php

namespace App\Http\Controllers;

use App\proff;
use App\MatchedUser;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class UploadPopController extends Controller
{
 
	public function index(Request $request)
	{
  		
      $listData = MatchedUser::where([['id', $request->listid],['provider_user_id', Auth::user()->id]])->first();
      
      if ($listData != null) 
      {
          return view('user.upload_pop', [
              'owner_data' => $listData,
          ]);
      }
      else{
        if ($request->ajax()) 
        {
          return response()->json([
              'error' => 'User is not found'
          ], 422);
        }
        return back()->with('error', 'Sorry there is an error with your Matched Details, if this persist please contact Admin.');
      }
      
    	
  }

   public function upload(Request $req)
   { 

         $this->validate($req,[
            'proof_of_payment' => 'required'
            ]);

         $allowed = ['jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG'];
         
         $file = $req->file('proof_of_payment');
         
         // Get the mime
      $getMime = explode('.', $file->getClientOriginalName());
      
      $mime = end($getMime);

         if($_FILES['proof_of_payment']['size'] <= 2097152){
            if(in_array($mime, $allowed) == true){
                     if(!empty($file))
                     {
                        $randomName = substr_replace(sha1(microtime($getMime[0])), '', 12).'.'.$mime;
                        $fileput= $file->move(storage_path('app/public'), $randomName);
         
                        if($fileput)
         
                        {
                           $list = MatchedUser::where('provider_user_id', $req->provider_user_id)
                                    ->where('sponsor_user_id',$req->sponsor_user_id)
                                    ->where('amount', $req->amount)->first();
                           
                           $list->payment_proof     = $randomName;
                           $list->payment_status    = 'yes';
                           $upadate = $list->save();
                           if ($upadate) 
                           {  
                              if($req->ajax())
                              { 
                              return response()->json([
                              'success' => 'Your Payment Proof was sent',
                              ], 200); 
                              }
                              else
                              {
                              return back()->with( 'success','Your Payment Proof was sent');
                              }
                           }
 
                        }
                        else
                        { 
                           if($req->ajax())
                           { 
                              return response()->json([
                              'error' => 'We Couldn\'t upload your proof for now',
                              ], 422); 
                           }
                           else
                           {
                              return back()->with( 'error','We Couldn\'t upload your proof for now');
                           }
                        }
                     }
                     else
                     { 
                        if($req->ajax())
                        { 
                           return response()->json([
                           'error' => 'You are not allowed to do that.',
                           ], 422); 
                        }
                        else
                        {
                           return back()->with( 'error','You are not allowed to do that.');
                        }
                     }
                  }
                  else
                  { 
                        if($req->ajax())
                        { 
                           return response()->json([
                           'error' => 'Invalid Image format',
                           ], 422); 
                        }
                        else
                        {
                           return back()->with( 'error','Invalid Image format');
                        }
                  }
               }
               else
               {            
                  if($req->ajax())
                  { 
                     return response()->json([
                     'error' => 'Your image size is larger than 2 MB',
                     ], 422); 
                  }
                  else
                  {
                     return back()->with( 'error','Your image size is larger than 2 MB');
                  }                
               }
    }

}