<?php

namespace App\Http\Controllers;

use App\User;
use App\GetHelp as GH;
use App\ProvideHelp;
use App\MatchedUser;
use Illuminate\Http\Request;
use App\Http\Controllers\HomeController;

class GetHelpController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
    	$user = new User;
        $all = $user->all();
    	return view('auto')->with('all', $all);

    }

    public function adduser(Request $request){


        
    }

   

}
