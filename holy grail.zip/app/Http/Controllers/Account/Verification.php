<?php

namespace App\Http\Controllers\Account;

use App\User;
use App\Trustwork\Trust;
use App\Verification_Count;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

class Verification extends Controller
{
	protected $trustwork;
	
	public function __construct(){
		$this->trustwork = new Trust();
	}

    protected function verify(Request $request, User $users)
    {
    	$this->validate($request, [
    		'phone_token' => 'required|max:6|min:6',
    	]);
    	
    	$user = $users->find(Auth::id());

    	if ($user->phone_token === $request->phone_token) {
    		$user->verified = true;
            $user->account_state = 'intro';
            $user->assign('Participant');
    		if($user->save()){
    			return response()->json([
    				'success' => 'Verification was successful', 
    			]);
    		}
    	}
    	else{
    		Verification_Count::create([
    			'user_id' => Auth::id(),
    		]);
    		return response()->json([
    			'error' => 'Wrong code. If you did not get the code please request for another.'
    		], 423);
    	}

    }

    protected function sendmsg(Request $request)
    {
    	
    	$phone_number = Auth::user()->phone_number;

        $phone_number = substr($phone_number, 1);
        $phone_number = '234'.$phone_number;
    
    	$token = str_random(6);
    	
    	Auth::user()->phone_token = $token;
    	
    	Auth::user()->save();

    	$msg = 'Use this Code to Verify your account'.$token;
    	
    	if($this->trustwork->send_token($phone_number, $token=null, $msg) === 1701)
        {
            return response()->json([
             'success' => 'Verification Code Sent Successfully.'
            ]);
        }
        else{
            //dd($this->trustwork->send_token($phone_number, $token=null, $msg));
            return response()->json([
             'error' => 'Error has occured while trying to send you your code.',
            ]);
        }

    }

    protected function countV(Request $request)
    {
    	if(Auth::user()->verification_count()->get()->count() >= 3)
    	{
    		Auth::user()->account_state = 'blocked';
    		Auth::user()->save();
            return Auth::user()->verification_count()->get()->count(); 
    	}
    	return Auth::user()->verification_count()->get()->count(); 
    }
}
