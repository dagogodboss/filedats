<?php

namespace App\Http\Controllers\System;

use App\User;
use App\GetHelp;
use App\ProvideHelp;
use App\MatchedUser;
use Illuminate\Http\Request;
use App\Auxillary\Auxillary;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class MartrixController extends Controller
{
     	public function add_Donation(Request $request, ProvideHelp $providehelp, User $user, Auxillary $aux)
	  	{
	        	$this->validate($request, [
	        		'amount' => 'required|numeric|min:6000|max:1000000',
	        	]);
	          
	          if(!ends_with($request->amount, '000')){
	            return response()->json([
	              'error' => 'Amount must be round thousand'
	              ], 422);
	          }
	          
	          if ($request->amount  % 1000 !== 0) {
	            return response()->json([
	                'error' => 'Amount must be a multiple of N2,000.Eg: 10k, 12k, 14k'
	              ],422);
	          }

	        if($aux->provide_helps($request->amount))
	  		{
	  			return response()->json([
	  				'success' => 'You have successfully Sowed please refresh your Browser to see your matched Partner.'
	  			]);
	  		}		
	  			
	  	}
}
