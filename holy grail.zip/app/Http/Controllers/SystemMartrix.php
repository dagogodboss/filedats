<?php

namespace App\Http\Controllers;

use App\User;
use App\GetHelp;
use Carbon\Carbon;
use App\AdminTable;
use App\ProvideHelp;
use App\MatchedUser;
use App\Trustwork\Helper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SystemMartrix extends Controller
{
    private $first_Reciving_user;

    private $first_Donting_User;

    private $help;

    public function __construct(){
        $this->help = new Helper();
    }
    public function index()
    {
        return view('admin.system.index');
    }

    protected function run_matches(ProvideHelp $providehelp, GetHelp $gethelp, MatchedUser $match)
    {
        do 
        {
            $this->first_Donting_User = $providehelp->where('created_at', '<', Carbon::now()->subDays(0))->first();
        
            // first of get admin user
            $this->first_Reciving_user = $gethelp->where('user_permission', 'admin')->oldest()->first();

                      
            //check if the user is empty
            if ($this->first_Reciving_user == null) 
            {
              $this->first_Reciving_user = $gethelp->where('user_permission', 'active')->oldest()->first(); 
              //dd($this->first_Reciving_user);
            }
            
            // check if both collection has element in them

            
           if($this->first_Donting_User != null && $this->first_Reciving_user!= null)
           {    
                         
              $this->check_gh_user_state($this->first_Reciving_user);
              $this->check_ph_user_state($this->first_Donting_User); 

                // check the smaller amount 
                   if($this->first_Donting_User->amount >= $this->first_Reciving_user->amount) 
                   {     
                      $this->check_the_next_gh_user($this->first_Donting_User, $this->first_Reciving_user);
                       $match_details = $match->create([
                           'sponsor_user_id'                  => $this->first_Reciving_user->user_id,
                           'provider_user_id'                 => $this->first_Donting_User->user_id,
                           'amount'                           => $this->first_Reciving_user->amount,
                           'provider_gives_proof'             => 'false',
                           'payment_status'                   => 'not-paid',
                                       ]);
                       if($match_details){
                         $this->Subtract_gh_From_ph($this->first_Donting_User, $this->first_Reciving_user, $match_details);
                           echo 'Operation Done! Using Receiving <br>';
                       }
                   }
                   else
                   {
                      $match_details = $match->create([
                           'sponsor_user_id'                  => $this->first_Reciving_user->user_id,
                           'provider_user_id'                 => $this->first_Donting_User->user_id,
                           'amount'                           => $this->first_Donting_User->amount,
                           'provider_gives_proof'             => 'false',
                           'payment_status'                   => 'not-paid',
                                       ]);
                       if($match_details)
                       {
                           $this->Subtract_ph_From_gh($this->first_Donting_User, $this->first_Reciving_user, $match_details);
                           echo 'Operation Done! Using Donating <br> ';
                       }
                   }
            }
            else
            {
                return 'Nothing more to Do!!';
            }
        } while ($providehelp->all()->count() > 0);
    }

    private function Subtract_gh_From_ph($ph_user, $gh_user, $match_details)
    {
        if(ceil($ph_user->amount - $match_details->amount) !== 0 && ceil($ph_user->amount - $match_details->amount) > 0)
        {
            $amount = ceil($ph_user->amount - $match_details->amount);
            $this->update_ph_user($ph_user->user_id, $amount);
            $this->delete_gh_user($gh_user);
        }
        else
        {
            $this->delete_ph_user($ph_user);
            $this->delete_gh_user($gh_user);
        }

    }

    private function Subtract_ph_From_gh($ph_user, $gh_user, $match_details)
    {
        // for ph user 

        if(ceil($gh_user->amount - $match_details->amount) != 0 && ceil($gh_user->amount - $match_details->amount) > 0)
        {
            $amount = ceil($gh_user->amount - $match_details->amount);
            $this->update_gh_user($gh_user->user_id, $amount);
            $this->delete_ph_user($ph_user);
        }
        else
        {
             $this->delete_gh_user($gh_user);
             $this->delete_ph_user($ph_user);
        }
        
    }

    private function update_ph_user($uuid, $amount)
    {
        $user = ProvideHelp::where('user_id',$uuid)->first();
        $user->amount = $amount;
        $user->save();
    }

    private function delete_ph_user($uuid)
    {
        if(ProvideHelp::where([['id', $uuid->id],['user_id',$uuid->user_id]])->first()->delete())
        {
          return true;
        }
    }

    private function update_gh_user($uuid, $amount)
    {
        $user = GetHelp::where('user_id',$uuid)->first();
        $user->amount = $amount;
        $user->save();
    }

    private function delete_gh_user($uuid)
    {
      if (GetHelp::where([['id', $uuid->id],['user_id',$uuid->user_id]])->first() != null) 
      { 
        if(GetHelp::where([['id', $uuid->id],['user_id',$uuid->user_id]])->first()->delete()){
          return true;
        }
      }
      return true;
    }

    public function Delete_Matched_User($uuid)
    {
        if(MatchedUser::findWith('id', $uuid)->first()->delete()){
          return true;
        }
    }

    private function check_gh_user_state($gh_user)
    {
      if (User::find($gh_user->user_id)->account_state == 'blocked') 
      {
        $this->first_Reciving_user = GetHelp::where('user_id', '!=', $gh_user->user_id)->where('created_at', '<', Carbon::now()->subDays(5))->oldest()->first();
        $this->check_gh_user_state($this->first_Reciving_user);
      }else{
        $this->first_Reciving_user = $gh_user;

      }
    }

    private function check_ph_user_state($ph_user)
    {
      if (User::find($ph_user->user_id)->account_state == 'blocked') 
      {
        $this->first_Donting_User = ProvideHelp::where('user_id', '!=', $ph_user->user_id)->where('created_at', '<', Carbon::now()->subDays(2))->first();
        $this->check_ph_user_state($this->first_Donting_User);
      }else{
        $this->first_Donting_User = $ph_user;
      }
    }

    private function check_the_next_gh_user($ph_user, $gh_user)
    {

        if($gh_user != null && ceil($ph_user->amount/$gh_user->amount) > 3)
        {
            $gh_user = GetHelp::where('user_id', '!=', $gh_user->user_id)->where('user_permission', 'active')->oldest()->first();
            $this->check_the_next_gh_user($ph_user,$gh_user);
        }
        else
        {
             $this->first_Reciving_user = $gh_user;
        }

        if ($gh_user == null) 
        {
         // do something about ph
            $adminuser = Get_Help_Admin_Table::where('just_use', 'no')->inRandomOrder()->first();
            if ($adminuser != null) 
            {
                $adminuser->just_use = 'yes';
                $adminuser->amount = ceil($this->help->explode_cash($ph_user->amount)/rand(1,3));
                $adminuser->save();
                $this->first_Reciving_user = $adminuser;    
            }
            else{
                 dd('admin don finish');
             }
        }
        
    }

    private function check_the_next_ph_user($ph_user, $gh_user)
    {
        if(ceil($gh_user->amount/$ph_user->amount) > 3)
        {
            $this->first_Donting_User = ProvideHelp::where('user_id', '!=', $ph_user->user_id)->oldest()->first();
            $this->check_ph_user_state($this->first_Donting_User, $gh_user);
        }
        else
        {
             $this->first_Donting_User = $ph_user;
        }
    }
}
