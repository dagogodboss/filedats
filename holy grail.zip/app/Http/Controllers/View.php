<?php  

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\proff;

class View extends Controller
{
    public function index(Request $request)
    {


    	$imagesel = proff::where('user_id', $request->sponor_id)->where('payer_id', $request->payer_id)->first();
    		$image = $imagesel->image;
    	return view('view')->with('data', $image);
    }
}
