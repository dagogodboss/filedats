<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
class Admin extends Controller
{
    public function index(Request $request)
    {
    	
    	$user = User::findOrFail($request->id)->first();
    	if(hasRole('admin')){
    		echo "string";
    		die();
    	}
    	$admin = $user->assign('admin');
    	dd($admin);
    	if ($admin) {
    		return "good";
    	}
    	return "BAD";
    }
}
