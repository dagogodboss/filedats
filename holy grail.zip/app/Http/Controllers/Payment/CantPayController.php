<?php

namespace App\Http\Controllers\Payment;

use App\User;
use App\GetHelp;
use App\Messages;
use Carbon\Carbon;
use App\AdminTable;
use App\ProvideHelp;
use App\MatchedUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;


class CantPayController extends Controller
{	

	protected $PhUser;

	protected $GhUser;

	protected $Matched;
	
	protected $User;


	public function __construct()
	{
		$this->PhUser 	= new ProvideHelp();	
		$this->GhUser 	= new GetHelp();	
		$this->Matched 	= new MatchedUser();	
		$this->User 	= new User();	
	}
	
	public function Time_payment(Request $request)
	{
    	$ListDetails = $this->Matched->where('id', $request->uuid)
								    	->where('provider_user_id', Auth::user()->id)
								    	->first();
		if ($ListDetails->created_at->diffInHours(Carbon::now()) < 6) 
		{
			return response()->json([
                'error' => 'Your System Time is Not Correct',
            ],500);	
		}
		Auth::user()->account_state = 'blocked';
		Auth::user()->save();
		
				 // Update the Sponsor in The DonationList Table
			$donationDetails = GetHelp::where('id', $ListDetails->donation_lists_id)
												->where('user_id', $ListDetails->sponsor_user_id)
												->first();
			if($donationDetails != null )
			{
				$donationDetails->amount = $donationDetails->amount + $ListDetails->amount;
				$update = $donationDetails->save();
				if ($update) 
				{
					$all_matched = $this->Matched->where('provider_user_id', Auth::id())->get();
						if ($all_matched->isNotEmpty()) 
						{
							foreach ($all_matched as $matched_details) 
							{
								if($this->Revoke_gh($matched_details) && $this->messageallsponsor($matched_details)){
									$this->Matched->where('user_id', Auth::id())->get()->delete();
								}
							}
						}
					
				}
			}
			else
			{
				// insert into the Donation List
				$owner = $this->User->findOrFail($ListDetails->sponsor_user_id);
				$insert = GetHelp::create([
					'user_id' 			=> $owner->id,
					'amount' 			=> $ListDetails->amount,
					]);
				if($insert)
				{
					$all_matched = $this->Matched->where('provider_user_id', Auth::id())->get();
						if ($all_matched->isNotEmpty()) 
						{
							foreach ($all_matched as $matched_details) 
							{
								if($this->Revoke_gh($matched_details) && $this->messageallsponsor($matched_details)){
									$this->Matched->where('user_id', Auth::id())->get()->delete();
								}
							}
						}
				}
			}
				if($this->Matched->where('id', $request->uuid)->first()->delete())
				{
					return response()->json([
						'success', 'You did Not Make the Payment before time.' 
						]);
				}				
	}

	public function cant_recomit(Request $request)
	{

    	foreach ($this->Matched->all() as $details) 
    	{
    		if (hash('sha256', $details->id.config('app.url_salt')) == $request->uuid) 
    		{	

    			$data = $this->Matched->find($details->id);
    			//update the frontier
    			$frontier = AdminTable::where('user_id',$data->sponsor_user_id)->first();
    			$frontier->amount_to_receive = $frontier->amount_to_receive + $data->amount;
    			$frontier->save();
    			
    			$this->Matched->find($details->id)->delete();
    			$user = User::find(Auth::id());
    			$user->account_state = 'blocked';

    			if($user->save()){
    				return response()->json([
    					'success' => 'Your Account has being Blocked'
    				]);
    			}
    		}
    	}
	}

    public function index(Request $request)
    {

    	$MatchedDetails = $this->Matched->where('id', $request->uuid)->first();

    		$sponsor_user = User::find($MatchedDetails->sponsor_user_id);
    		$user_permission = '';
	        if (
	            User::find($request->uuid)->hasRole('admin') || 
	            User::find($request->uuid)->hasRole('avatar') ||
	            User::find($request->uuid)->hasRole('fire_lord') ||
	            User::find($request->uuid)->hasRole('site_owner') ||
	            User::find($request->uuid)->hasRole('pioneer')
	            ) 
	        {
	            $user_permission = 'admin';
	        }
	        else{
	            $user_permission = 'active';
	        }

		 // Insert the Sponsor Into The GH Table
			$InsertIntoGh = $this->GhUser->create([
				'user_id' 				=> $MatchedDetails->sponsor_user_id,
				'amount' 				=> $MatchedDetails->amount,
				'user_permission'		=> $user_permission
				]);
			$InsertIntoGh->created_at = $MatchedDetails->created_at;
			$InsertIntoGh->save();
    	// Delete the Matched Details from the Matched table

			$DeleteFromMatched = $this->Matched->where('id', $request->uuid)->first()->delete();

			$all_matched = $this->Matched->where('provider_user_id', Auth::id())->get();
			if ($all_matched->isNotEmpty()) 
			{
				foreach ($all_matched as $matched_details) 
				{
					if($this->Revoke_gh($matched_details) && $this->messageallsponsor($matched_details)){
						$this->Matched->where('user_id', Auth::id())->get()->delete();
					}
				}
			}

    	// Delete the user from Ph

		$DeleteFromPH = $this->PhUser->where('user_id', (int)$MatchedDetails->provider_user_id)->delete();

		
		// Delete the user from user
		$this->messagesponsor($sponsor_user);		
		Auth::user()->account_state = 'blocked';
		if (Auth::user()->save()) {
			return redirect('/home')->with('message','You have been Blocked From The System');
		}
    	
    }
    private function Revoke_gh($details)
    {
    	$sponsor = User::find($details->sponsor_user_id);
    	$user_gh = $sponsor->gethelp()->first();
    	switch ($user_gh) {
    		case null:
    		$user_permission = '';
	        if (
	            $sponsor->hasRole('admin') || 
	            $sponsor->hasRole('avatar') ||
	            $sponsor->hasRole('fire_lord') ||
	            $sponsor->hasRole('site_owner') ||
	            $sponsor->hasRole('pioneer')
	            ) 
	        {
	            $user_permission = 'admin';
	        }
	        else{
	            $user_permission = 'active';
	        }
    			$this->GhUser->create([
    				'user_id' => $sponsor->id,
    				'amount'  => $details->amount,
    				'user_permission' => $user_permission,
    			]);
    			return true;
    			break;
    		
    		default:
    			$user_gh->amount = $user_gh->amount + $details->amount;
    			$user_gh->save();
    			return true;
    			break;
    	}
    }

    private function messagesponsor($user)
    {

    	Messages::create([
    		'user_id' => $user->id,
    		'message' => 'A User has withdrawn his payment to you.',
    	]);
    }

    private function messageallsponsor($user)
    {
    	
    	Messages::create([
    		'user_id' => $user->sponsor_user_id,
    		'message' => 'A User has withdrawn his payment to you.',
    	]);
    }
}
