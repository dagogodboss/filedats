<?php

namespace App\Http\Controllers\Payment;

use App\User;
use App\GetHelp;
use App\Messages;
use Carbon\Carbon;
use App\AdminTable;
use App\ProvideHelp;
use App\MatchedUser;
use App\Transaction;
use App\WaitingTimer;
use App\Trustwork\Helper;
use App\Auxillary\Auxillary;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\SystemMartrix;
use Illuminate\Support\Facades\Auth;

class ConfirmPayment extends Controller
{
    protected $help;
    
    protected $User;
    
    protected $DonationList;

    protected $ReserveList;

    public function __construct()
    {
        $this->User             = new User();   
        $this->DonationList     = new GetHelp();     
        $this->ReserveList      = new MatchedUser();     
        $this->help             = new Helper();
        $this->system           = new SystemMartrix();
        $this->aux              = new Auxillary();
    }

    private function balance_checker($amount_confirm){
        Auth::user()->amount_to_receive = Auth::user()->amount_to_receive - $amount_confirm; 
        Auth::user()->amount_collected = Auth::user()->amount_collected + $amount_confirm; 
        if (Auth::user()->amount_to_receive <= 0) 
        {
            Auth::user()->amount_collected = null;
            Auth::user()->amount_to_receive = null;
            Auth::user()->payment_status = 'pay_new_pledge_receive_bonus';
            Auth::user()->save();
        }

    }

    private function increase_user_payment($paid_amount, $user_id){
        $paying_user = User::find($user_id);
        $paying_user->amount_to_receive = $paying_user->amount_to_receive + $paid_amount;
        $paying_user->save();
        if ($paying_user->amount_to_receive == $paying_user->amount_pledge and $paying_user->payment_status == 'pay_pledge') {
            $paying_user->payment_status = 'receive_capital';
            $paying_user->save();
        }
    }

    private function bonus_checker($amount){
        Auth::user()->bonus_to_receive = Auth::user()->bonus_to_receive - $amount_confirm; 
        Auth::user()->amount_collected = Auth::user()->amount_collected + $amount_confirm; 
        if (Auth::user()->bonus_to_receive <= 0) 
        {
            $this->aux->insert_to_ph_table();
            Auth::user()->amount_collected = null;
            Auth::user()->bonus_to_receive = null;
            Auth::user()->payment_status = 'pay_pledge';
            Auth::user()->save();
            Messages::create([
                'user_id' =>  Auth::id(),
                'message' => 'You have successfully collected your bonus earining of 70%. And hence you are have been added to pay your complete pledge',
            ]);
        }
    }

    public function Confirm(Request $request)
    {
        $ListDetails = $this->ReserveList->where('id', $request->uuid)
                                         ->where('sponsor_user_id', Auth::user()->id)
                                        ->first();            
        if($ListDetails != null)
        {
            switch (Auth::user()->payment_status){
                case 'receive_capital':
                    $this->balance_checker($ListDetails->amount);
                    $this->increase_user_payment($ListDetails->$amount, $ListDetails->provider_user_id);
                    $this->insert_into_transaction_table($newSponsor, Auth::user()->id, $ListDetails);
                    $this->message_ph_user($newSponsor);
                    if($this->DeleteUser($newSponsor, $request) == true)
                    {
                        return response()->json([
                            'complete' => 'The User has been Confirm!',
                        ]);
                    }  
                break;
                
                default:
                    $this->bonus_checker($ListDetails->amount);
                    $this->increase_user_payment($ListDetails->$amount, $ListDetails->provider_user_id);
                    $this->insert_into_transaction_table($newSponsor, Auth::user()->id, $ListDetails);
                    $this->message_ph_user($newSponsor);
                    if($this->DeleteUser($newSponsor, $request) == true)
                    {
                        return response()->json([
                            'complete' => 'The User has been Confirm!',
                        ]);
                    }    
                break;
            }
            
        }
        return response()->json([
                'error' => 'The matched details is no longer available on the Database!',
                            ]);

    }

    private function DeleteUser($user, $request)
    {
        $this->ReserveList->where('id', $request->uuid)
                            ->where('provider_user_id', $user->id)
                            ->where('sponsor_user_id', Auth::user()->id)
                            ->delete();
        return true;
    }

    protected function ViewProof(Request $request)
    {
        $ListDetails = $this->ReserveList->where('id', $request->uuid)
                                        ->where('sponsor_user_id', Auth::user()->id)
                                        ->first();
        if($ListDetails != null && $ListDetails->payment_proof != "")
        {
            return response()->json([
            'image' => $ListDetails->payment_proof,
            ]);
        }
        return response()->json([
            'error' => 'No Image Available for this entries',
            ]);
    }


    private function add_user_donation_list($user, $amount)
    {
        $user_permission = '';
                
        if (
            $user->hasRole('admin') || 
            $user->hasRole('avatar') ||
            $user->hasRole('fire_lord') ||
            $user->hasRole('site_owner') ||
            $user->hasRole('pioneer')
            ) 
        {
            $user_permission = 'admin';
        }
        else{
            $user_permission = 'inactive';
        }

        if($this->DonationList->create([
            'amount'            => $amount,
            'user_id'           => $user->id,
            'user_permission'   => $user_permission,
        ]))
        {
            return true;
        }
    }
    
    private function insert_into_transaction_table($user, $id, $details)
    {   
                if(Transaction::create([
                    'p_user'              => $user->id,
                    'r_user'              => $id,
                    'amount'              => $details->amount,
                    'payment_status'      => $details->payment_status,
                ]))
                {
                    return true;
                }
    }


    public function confirm_recomit(Request $request, MatchedUser $matched_details, User $user, ProvideHelp $ph_table, AdminTable $admin)
    {
        foreach($matched_details->all() as $details)
        {
            if(hash('sha256', $details->id.config('app.url_salt')) == $request->uuid)
            {
                $paying_user = $user->find($details->provider_user_id);

                switch ($paying_user->payment_status){
                    case null:
                        $paying_user->amount_to_receive = $paying_user->amount_to_receive + $details->amount; 
                        $paying_user->payment_status = 'pay_pledge';
                        if($paying_user->save())
                        {
                            $frontier = $admin->where('user_id', $details->sponsor_user_id)->first();

                            $frontier->amount_collected = $frontier->amount_collected + $details->amount;

                            $frontier->save();
                            
                            $this->addToPh($paying_user);
                            if(Messages::create([
                                    'user_id' => $paying_user->id,
                                    'message' => 'Your Account has been verified and your re-commitment confirmed. Please note that your ten days countdown to pay up the complete Sowed amount. has Started.',
                                ]))
                            {      
                                $matched_details->find($details->id)->delete();
                                return response()->json([
                                    'success' => 'Payment has being confirmed.',
                                ]);    
                            }  
                        }
                        break;
                    case 'pay_new_pledge_receive_bonus':
                        // write function to add bonus.
                        if($paying_user->bonus_to_receive != null){
                            $this->insert_user_bonus($paying_user);
                            $paying_user->payment_status = 'receive_bonus';
                            $paying_user->save();
                            $this->matched_user($paying_user);
                            if(Messages::create([
                                    'user_id' => $paying_user->id,
                                    'message' => 'Your commitment is confirmed. Please note that you are have now been added to the donation list to receive your bonus.',
                                ]))
                            {      
                                $matched_details->find($details->id)->delete();
                                return response()->json([
                                    'success' => 'Payment has being confirmed.',
                                ]);    
                            } 
                        }else{
                            dd($this);
                        }
                        break;
                    default:
                        # code...
                        break;
                }

            }
            
        }
    } 

    private function matched_user($user){
        do
        {
            $provider = ProvideHelp::first();
            if($provider != null)
            {
                if ($user->bonus_to_receive <= $provider->amount) 
                    {
                        $this->ReserveList->create([
                            'sponsor_user_id' => $user->id,
                            'provider_user_id' => $provider->user_id,
                            'amount'           => $user->bonus_to_receive,
                        ]);
                       $this->sub_provider_from_user($user->bonus_to_receive, $provider, $user); 
                    }
                    else{
                        $this->ReserveList->create([
                            'sponsor_user_id' => $user->id,
                            'provider_user_id' => $provider->user_id,
                            'amount'           => $provider->amount,
                        ]);
                       $this->sub_user_from_provider($user->bonus_to_receive, $provider, $user); 
                    }
            }
        } 
        while ( $user->bonus_to_receive <= 0);
    }
    
    private function sub_provider_from_user($bonus_amount, $provider, $bonus_user)
    {
        if (ceil($provider->amount - $bonus_amount) !== 0 && ceil($provider->amount - $bonus_amount) > 0) 
        {
            $amount = $provider->amount - $bonus_amount;
            $this->system->update_ph_user($provider->user_id, $amount);
            $bonus_user->bonus_to_receive = 0;
            $bonus_user->save();
        }
        else{
            $bonus_user->bonus_to_receive = 0;
            $bonus_user->save();
             $this->system->delete_ph_user($provider);
        }

    }    

    private function sub_user_from_provider($bonus_amount, $provider, $bonus_user){
        if ($bonus_amount - $provider->amount !== 0 && $bonus_amount - $provider->amount > 0) 
        {
            $amount = $bonus_amount - $provider->amount;
            $this->system->delete_ph_user($provider);
            $bonus_user->bonus_to_receive = $amount;
            $bonus_user->save();
        }
        else{
            $this->system->delete_ph_user($provider);
            $bonus_user->bonus_to_receive = $bonus_amount - $provider->amount ;
            $bonus_user->save();
        }
    }

    private function insert_user_bonus($user){
        $this->DonationList->create([
            'amount'            => $user->bonus_to_receive,
            'user_id'           => $user->id,
            'user_permission'   => 'active',
        ]);
    }

    public function purge_recomit(Request $request, MatchedUser $matched_details, AdminTable $admin)
    {

        foreach ($this->Matched->all() as $details) 
        {
            if (hash('sha256', $details->id.config('app.url_salt')) == $request->uuid) 
            {
                $frontier = $admin->find($details->sponsor_user_id);
                $frontier->amount_to_receive = $frontier->amount_to_receive + $details->amount; 
                $this->Matched->find($details->id)->delete();
                $user = User::find($details->provider_user_id);
                $user->provide_help()->delete();
                $user->account_state = 'blocked';
                if($user->save()){
                    return response()->json([
                        'success' => 'The User Account has being Blocked'
                    ]);
                }
            }
        }
    }

    public function addToPh($paying_user)
    {
        ProvideHelp::create([
            'user_id'        => $paying_user->id,
            'amount'         => $paying_user->complete_charge,
        ]);

    }   
    

    private function checkUserForRecommitment($uuid, $gotten_amount)
    {
        $user = User::find($uuid);
        if ($user != null) 
        {
                //check if the user is refereed
                if ($user->was_referred()->first() != null) 
                {   
                    $referred_user = $user->was_referred()->first();
                    $referred_by = User::find($referred_user->referree_user_id);
                    switch ($user->was_referred()->first()->reward) 
                    {
                        case 'no' :
                            $amount = ceil($gotten_amount * 0.5);
                            $referee = User::find($user->was_referred()->first()->referree_user_id);
                            $referee->referral_earnings = $referee->referral_earnings + $amount;
                            $referee->save();
                            // inform user
                            $refered = \App\ReferralRelationship::where('user_id', $user->id)->first();
                            $refered->reward = 'yes';
                            if($refered->save())
                            {
                                $this->message_user($referee);
                            }
                            break;
                    }
                        
                    if ($referred_by->hasRole('pioneer')) {
                         $amount = ceil($gotten_amount * 0.3);
                            $referred_by->referral_earnings = $referred_by->referral_earnings + $amount;
                            if($refered_by->save())
                            {
                                $this->message_user_refered($referee, 'The User you referred has Refer another User and you have gotten 3% of the referred user\'s Sown Donation.');
                            }
                    }
                    if($referred_by->was_referred()->first()){
                        $ref = $referred_by->was_referred()->first();
                        $ref_user = User::find($ref->id);
                        if ($ref_user->hasRole('pioneer')) {
                            $amount = ceil($gotten_amount * 0.01);
                            $ref_user->referral_earnings = $ref_user->referral_earnings + $amount;
                            if($ref_user->save())
                            {
                                $this->message_user_refered($referee, 'The User you referred has Referred another user that user has refer another user thus you have gotten 1% of the referred user\'s Sown Donation.');
                            }
                        }
                    }
                }
                return true;
        }
    }

    private function message_user_refered($user, $message){
        Messages::create([
            'user_id' => $user->id,
            'message' => $message,
        ]);
    }
    private function message_user($referee)
    {
        Messages::create([
            'user_id' => $referee->id,
            'message' => ' Hello '. $referee->name .' the user you referred has made his/her first Donation and you have receive 10% of his/her donation.',
        ]);
    }

    private function message_ph_user($user)
    {
        Messages::create([
            'user_id' => $user->id,
            'message' => 'Your Payment has been confirmed. And You have been added to Donation Table to receive help. Please Note that it will take 1 - 4 days for You to Recieve your donation.'
        ]);
    }
}
