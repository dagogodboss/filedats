<?php

namespace App\Http\Controllers\Payment;

use App\User;
use App\Messages;
use Carbon\Carbon;
use App\ReserveList;
use App\Transaction;
use App\DonationList;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;


class CantPayController extends Controller
{	

	protected $user;
	protected $message;
	protected $DonationList;
	protected $ReserveList;

	public function __construct()
	{
		$this->user 			= new User();	
		$this->message 			= new Messages();
		$this->ReserveList 		= new ReserveList();	
		$this->DonationList 	= new DonationList();	
	}

	public function Time_payment(Request $request)
	{
    	$ListDetails = $this->ReserveList->where('id', $request->uuid)
								    	->where('user_id', Auth::user()->id)
								    	->first();
		if ($ListDetails->created_at->diffInHours(Carbon::now()) < 6) 
		{
			return response()->json([
                'error' => 'Your System Time is Not Correct',
            ],500);	
		}
		
				 // Update the Sponsor in The DonationList Table
			$donationDetails = $this->DonationList->where('id', $ListDetails->donation_lists_id)
												->where('user_id', $ListDetails->owner_id)
												->first();
			if($donationDetails != null )
			{
				$donationDetails->amount = $donationDetails->amount + $ListDetails->reserve_amount;
				$update = $donationDetails->save();
				if ($update) 
				{
					$this->deleteAction($ListDetails);
					
				}
			}
			else
			{
				// insert into the Donation List
				$owner = $this->user->findOrFail($ListDetails->owner_id);
				$insert = $this->DonationList->create([
					'user_id' 			=> $owner->id,
					'name'				=> $owner->name,
					'email'				=> $owner->email,
					'amount' 			=> $ListDetails->reserve_amount,
					'bank_name' 		=> $owner->bank_name,
					'phone_number' 		=> $owner->phone_number,
					'account_number' 	=> $owner->account_number,
					]);
				if($insert)
				{
					$this->deleteAction($ListDetails);
				}
			}				
	}

    public function index(Request $request)
    {
    	$ListDetails = $this->ReserveList->where('id', $request->uuid)
								    	->where('user_id', Auth::user()->id)
								    	->first();

		 // Update the Sponsor in The DonationList Table
			$donationDetails = $this->DonationList->where('id', $ListDetails->donation_lists_id)
												->where('user_id', $ListDetails->owner_id)
												->first();
			if($donationDetails != null )
			{
				$donationDetails->amount = $donationDetails->amount + $ListDetails->reserve_amount;
				$update = $donationDetails->save();
				if ($update) 
				{
					$this->deleteAction($ListDetails);
					
				}
			}
			else
			{
				// insert into the Donation List
				$owner = $this->user->findOrFail($ListDetails->owner_id);
				$insert = $this->DonationList->create([
					'user_id' 			=> $owner->id,
					'name'				=> $owner->name,
					'email'				=> $owner->email,
					'amount' 			=> $ListDetails->reserve_amount,
					'bank_name' 		=> $owner->bank_name,
					'phone_number' 		=> $owner->phone_number,
					'account_number' 	=> $owner->account_number,
					]);
				if($insert)
				{
					$this->deleteAction($ListDetails);
				}
			}					    	
    	
	}
		
		// Delete the user from the system

	private function deleteAction($user)
	{
		$DeleteFromReserveList = $this->ReserveList->where('id', $user->id)
											->where('donation_lists_id', $user->donation_lists_id)
											->where('user_id', $user->user_id)
											->where('reserve_amount', $user->reserve_amount)
											->delete();
		// remove User from Donation List
		$donation = Auth::user()->donationlist()->get();
		$ownerList = Auth::user()->Ownerreservelist()->get();
		$r_donation = Auth::user()->reservelist()->get();
		if ($donation->isNotEmpty()) 
		{
			Auth::user()->donationlist()->delete();
		}
		if($r_donation->isNotEmpty()) 
		{
			$all_user_reserve = Auth::user()->reservelist()->get();
			foreach ($all_user_reserve as $reserve) 
			{
				$this->send_to_gh($reserve);
			}
			Auth::user()->reservelist()->delete();
		}
		if($ownerList->isNotEmpty())
		{
			$all_user_reserve = Auth::user()->Ownerreservelist()->get();
			foreach ($all_user_reserve as $reserve) 
			{
				$this->message_ph_user($reserve);
				$this->add_to_transaction($reserve);
			}
			Auth::user()->Ownerreservelist()->delete();
		}
		//Blocked the user account
		Auth::user()->user_account_state = 'blocked';
		if (Auth::user()->save()) 
		{
			return response()->json([
                'success' => 'You are Blocked from using this Site.',
            ]);
		}
	}

	private function send_to_gh($details)
	{
			$user = $this->user->findOrFail($details->owner_id);
			$UserDonation = $user->donationlist()->first();
			if ($UserDonation != null) 
			{
				$UserDonation->amount = $UserDonation->amount + $details->reserve_amount;
				($UserDonation->save()) ?
				$this->message_user($details) : '' ;
			}
			else
			{
				($create = $this->DonationList->create([
					'user_id' 			=> $user->id,
					'name'				=> $user->name,
					'email'				=> $user->email,
					'amount' 			=> $details->reserve_amount,
					'bank_name' 		=> $user->bank_name,
					'phone_number' 		=> $user->phone_number,
					'account_number' 	=> $user->account_number,
				])); 
				{
					$this->message_user($details);

				}
			}
			return false;
	}

	private function message_user($data = null)
	{
		// This User  {name} has withdraw his donation of {amount} to you for reason best known to the User and has been Blocked from this System.
		$message = $this->message->create([
			'user_id' 	=> $data->owner_id,
			'message' 	=> 'This User  '.$data->payer_account_name.' has withdraw his donation of '.$data->reserve_amount.' to you for reason best known to the User and has been Blocked from this System.',
		]);
		return true;
	}

	private function message_ph_user($data = null)
	{
		// This User  {name} has withdraw his donation of {amount} to you for reason best known to the User and has been Blocked from this System.
		$message = $this->message->create([
			'user_id' 	=> $data->user_id,
			'message' 	=> 'This User  '.$data->payer_account_name.' has been Blocked from the system and all his donation remove please you have to go Reserve another Donation. We apologies For any inconvenience.',
		]);
		return true;
	}
	private function add_to_transaction($data)
	{
		Transaction::create([
					'payer_id' 				=> $data->user_id,
					'payee_id' 				=> $data->owner_id,
					'payer_account_name'	=> $data->payer_account_name,
					'payer_bank_name' 		=> $data->payer_bank_name,
					'upload_proof' 			=> $data->upload_proof,
          			'donation_list_id' 		=> $data->id,
					'payee_bank_name' 		=> $data->bank_name,
					'proof_image' 			=> $data->proof_image,
					'payer_phone_number'	=> $data->payer_phone_number,
					'payee_phone_number'	=> $data->phone_number,
					'payee_account_name'	=> $data->account_name,
					'payer_account_number'	=> $data->payer_account_number,
					'payee_account_number'	=> $data->account_number,
					'reserve_amount' 		=> $data->reserve_amount,
		]);
		return true;
	}
}
