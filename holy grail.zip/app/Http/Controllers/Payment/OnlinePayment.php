<?php

namespace App\Http\Controllers\Payment;

use App\User;
use App\AdminTable;
use App\MatchedUser;
use Illuminate\Http\Request;
use Illuminate\Contracts\Auth\Guard;
use App\Http\Controllers\Controller;

class OnlinePayment extends Controller
{
	public function __construct(Guard $auth){
		 $this->auth = $auth;
	}
    public function index(Request $request, User $user,  AdminTable $admin_users_table)
    {
    	if($this->auth->user()->recommit()->where('recommit', 'yes')->first() != null) 
        {
            $matched_details = $this->auth->user()->recommit()->where('recommit', 'yes')->first();
            $sponsor_details = $admin_users_table->where('user_id', $matched_details->sponsor_user_id)->first();
            $cash            = $matched_details->amount;
            return view('user.payment.form', [
                'amount'    => $cash,
                'sponsor'  => $sponsor_details,
                'matched_details'  => $matched_details,
            ]);
        }
    }
}
