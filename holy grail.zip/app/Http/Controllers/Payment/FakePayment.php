<?php

namespace App\Http\Controllers\Payment;

use App\User;
use App\Messages;
use App\MatchedUser;
use App\Transaction;
use App\GetHelp;
use App\PurgeComplain;
use App\ComplainCount;
use App\Mail\FakePayment as MailFakePayment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

class FakePayment extends Controller
{	
	
	protected $User;
	
	protected $DonationList;
	
	protected $ReserveList;

	public function __construct()
	{
		$this->middleware('auth');
		$this->User 			= new User();	
		$this->ReserveList 		= new MatchedUser();	
		$this->DonationList 	= new MatchedUser();	
	}

   public function fakepayment(Request $request)
   {
      $complain_count = ComplainCount::where('user_id', Auth::id())->get()->count();
      if ($complain_count >= 5) 
      {
        if($request->ajax()){
          return response()->json([
              'error' => 'Sorry you have exceeded your number of Purge Privillage Please Contact Administrator for assistance',
          ], 422);
        }
        return back()->with('error', 'Sorry you have exceeded your number of Purge Privillage Please Contact Administrator for assistance');
      }else{
        $checkList = $this->ReserveList->where('id', $request->uuid)->first();

       if ($checkList != null) {
          return response()->json([
            'listDetails' => $checkList,
          ]);
        }
      }
   		return response()->json
   		([
    		'error' => 'An error has occured. The record you tried to pull is not found on our database'
    	]);
   }

   public function send_notice(Request $request)
   {
   		
        $this->validate($request, [
        'mode_of_payment'     => 'required|string',
        'uuid'          =>  'required|numeric', 
        'identification_number' => 'required|string',
        'proof_of_payment'    => 'required',
      ]);
      
        if(PurgeComplain::where('matched_id', $request->uuid)->first()) {
            return back()->with('error', 'Sorry you have already flag this payment as fake once you can\'t do it again ');
        }
        $list = MatchedUser::find($request->uuid);
        
        if($list != null)
        { 

          $allowed = ['jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG'];
         
              $file = $request->file('proof_of_payment');
         
              // Get the mime
            $getMime = explode('.', $file->getClientOriginalName());
              
            $mime = end($getMime);

            if($_FILES['proof_of_payment']['size'] <= 2097152)
            {
              if(in_array($mime, $allowed) == true)
              {
                if(!empty($file))
                {
                            $randomName = substr_replace(sha1(microtime($getMime[0])), '', 12).'.'.$mime;
                            $fileput= $file->move(storage_path('app/public'), $randomName);
         
                     if($fileput)
                     {
                     $payee = User::find($list->sponsor_user_id);
                     $payer = User::find($list->provider_user_id);

                     $userComplain = PurgeComplain::create([
                        'matched_id'            => $request->uuid,
                        'payer_id'              => $payer->id,
                        'payer_account_name'      => $payer->name,
                        'payer_account_number'      => $payer->account_number,
                        'payer_bank_name'         => $payer->bank_name,
                        'payer_phone_number'      => $payer->phone_number,
                        'amount'              => $list->amount,
                        'complainer_id'           => $payee->id,
                        'complanier_name'         => $payee->name,
                        'complanier_account_number'   => $payee->account_number,
                        'complanier_bank_name'      => $payee->bank_name,
                        'complanier_phone_number'   => $payee->phone_number,
                        'proof_of_payment'        => $randomName,
                                'mode_of_payment'           => $request->mode_of_payment,
                                'reason'            => $request->identification_number,
                     ]);

                  $list->payment_status = 'fake';
                  $list->save();
                  //Mail::to('admin@'.config('app.name', 'Laravel'))->send(new MailFakePayment($userComplain));
                  if ($userComplain != null) 
                  {     
                    if ($this->add_to_Transaction_table($list) && $this->count_complain($userComplain) && $this->message_user($userComplain)) 
                    {
                      return redirect('home')->with('success', 'Your complain has been sent! Please Note that it will take 24 hours to resovle the issue.');
                    }
                  }
                            }
                            else
                            {
                              return redirect()->back()->with('error', 'We Couldn\'t upload your proof for now');
                            }
                          }
                          else{
                            return redirect()->back()->with('error', 'You must be Dumb');
                          }
                        }
                        else{
                           return redirect()->back()->with('error','Invalid Image format');
                        }
                    }
                    else
                    {
                    return redirect()->back()->with('error','Your image size is larger than 2 MB');
               }
          
        }
        return redirect()->back()->with('error', 'Sorry there was an error with your request.');
   	}

    public function message_user($data = null)
    {
      $message = Messages::create([
        'user_id'   => $data->payer_id,
        'message'   => 'This User  '.$data->complanier_name.' has Flag your Payment of '.$data->reserve_amount.' as fake Please quickly contact admin using the Support Form.',
      ]);
      return true;
    }

    public function add_to_Transaction_table($data)
    {
        Transaction::create([
          'matched_id' => $data->matched_id,
          'p_user' => $data->provider_user_id,
          'r_user' => $data->sponsor_user_id,
          'payment_status' => $data->payment_status,
          'payment_image' => $data->proof_of_payment,
          'amount' => $data->amount
        ]);
        return true;
    }

    private function count_complain($data){

      ComplainCount::create([
          'complainer_id' => $data->complainer_id,
          'payer_id'      => $data->payer_id,
        ]);
      return true;

    }
}
