<?php

namespace App\Http\Controllers;

use App\User;
use App\GetHelp;
use App\Messages;
use App\AdminTable;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function _construct()
    {
        $this->middleware('role:admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(User $user)
    {
        return view('admin.users.index',[
            'users' => $user->paginate(config('app.per_page')),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function add_donation(User $user, $id)
    {
        return view('admin.users.donation',[
            'user' => $user->find($id),
        ]);
    }

    public function add_donation_list(User $user, Request $request)
    {
        $this->validate($request,[
            'amount' => 'required|numeric|min:5000|max:200000',
        ]);
        
        if($user->find($request->user_id)->gethelp()->first() == null)
        {
            $user_help = GetHelp::create($request->all());
            if($user_help)
            {
                if (
                    $user->find($request->user_id)->hasRole('admin') || 
                    $user->find($request->user_id)->hasRole('avatar') ||
                    $user->find($request->user_id)->hasRole('fire_lord') ||
                    $user->find($request->user_id)->hasRole('site_owner') ||
                    $user->find($request->user_id)->hasRole('pioneer')
                    ) 
                {
                    $user_help->user_permission = 'admin';
                    $user_help->save();
                }
                return back()->with('success', 'User has been added up');
            }  
        }
        else{
            $userList = $user->find($request->user_id)->gethelp()->first();
            $userList->amount = $userList->amount + $request->amount;
            if (
                    $user->find($request->user_id)->hasRole('admin') || 
                    $user->find($request->user_id)->hasRole('avatar') ||
                    $user->find($request->user_id)->hasRole('fire_lord') ||
                    $user->find($request->user_id)->hasRole('site_owner') ||
                    $user->find($request->user_id)->hasRole('pioneer')
                    ) 
                {
                    $userList->user_permission = 'admin';
                }
            if($userList->save()){
                return back()->with('success', 'User has been added up');
            }
        }
        
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user, $id)
    {  
        $admin = $user->find($id)->toArray();
        $data = array_add($admin, 'user_id', $admin['id']);
        $maindata = array_add($data, 'amount', 1000);
            
        
       if($user->find($id)->hasRole('admin') == false)
       {
            
            if($user->find($id)->assign('admin'))
            {
                $admincreate = AdminTable::create($maindata);
                return back()->with('success', 'That User is Now an Administrator(--)');
            }
        }
        return back()->with('success', 'That User is already an Administrator (:');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user, $id)
    {
        return view('admin.users.edit',[
            'user' => $user->find($id),
            ]);
    }
    protected function block(User $user, $id)
    {
        $userz = $user->find($id);
        if($userz->hasRole('admin')){
            return back()->with('error', 'You can\'t Block that User.');
        }
        $userz->account_state = 'blocked';
        if ($userz->save()) 
        {
            return back()->with('success', 'That user has been Blocked.');
        }
    }

    protected function unblock(User $user, $id)
    {
        $userz = $user->find($id);
        $userz->account_state = null;
        if ($userz->save()) 
        {
            return back()->with('success', 'That user has been Un-Block.');
        }
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        $this->validate($request,[
             'name' => 'required|max:255',
            //'email' => 'required|email|max:255|unique:users',
            //'password' => 'required|min:6|confirmed',
            //'phone_number' => 'required|digits:11|unique:users,phone_number,whereNot:'.$request->id,
            'bank_name' => 'required|string|min:6',
            'account_number' => 'required|digits:10',
        ]);

        $update = $user->find($request->id);
        if($update->update($request->all())){
            return redirect('/user')->with('success','Update Done');
        }
    }
    protected function message(Request $request)
    {
        $this->validate($request,[
            'message' => 'required',
        ]);

        if(Messages::create($request->all())){
            return back()->with('success', 'Message Sent! :)');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        //
    }
}
