<?php

namespace App\Http\Controllers;

use App\User;
use App\GetHelp;
use App\ProvideHelp;
use App\MatchedUser;
use Illuminate\Http\Request;
use App\Auxillary\Auxillary;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class UserPledgeController extends Controller
{
     	public function add_Donation(Request $request, ProvideHelp $providehelp, User $user, Auxillary $aux)
	  	{
	        	$this->validate($request, [
	        		'amount' => 'required|numeric|min:6000|max:1000000',
	        	]);
	          
	          if(!ends_with($request->amount, '000')){
	            return response()->json([
	              'error' => 'Amount must be round thousand'
	              ], 422);
	          }
	          
	          if ($request->amount  % 1000 !== 0) {
	            return response()->json([
	                'error' => 'Amount must be a multiple of N2,000.Eg: 10k, 12k, 14k'
	              ],422);
	          }
	        
	        $status = Auth::user()->payment_status;
	        
	        switch ($status) {
	         	case null:
	         		if($aux->provide_helps($request->amount))
			  		{
			  			return response()->json([
			  				'success' => 'You have successfully Sowed please refresh your Browser to see your matched Partner.'
			  			]);
			  		}		
	         		break;
	         	case 'pay_new_pledge_receive_bonus':
	         		if ($aux->pay_to_get_bonus($request->amount)){
	         			return response()->json([
	         				'success' => 'You have successfully sowed please refresh your browser to see your matched Partner.'
	         			]);
	         		}
	         		break;
	         	default:
	         		return response()->json([
	                'error' => 'Sorry You Can\'t Donate Now '
	              ],500);
	         		break;
	         }
	        
	  			
	  	}


	  	protected function AddPlan(Request $req){

        $investId = $this->plan->findOrFail($req->id);

        $user =     User::findOrFail(\Auth::user()->id);
        
        $user->update([
                'plan'        => $investId->amount,
                'number_of_recycle' => Auth::user()->number_of_recycle + 1,                
        ]);
        
        $amount = $this->helper->explode_cash($user->plan);

        $recomit_amount = ($amount * config('app.recomit_pecentage')) + $amount ;

        $matched_amount = ($amount * config('app.recomit_pecentage'));
        
        $admin = AdminTable::inRandomOrder()->first();

            $matchuser = MatchedUser::create([
                'sponsor_user_id'               => $admin->user_id,
                'provider_user_id'              => $user->id,
                'amount'                        => $matched_amount,
                'payment_status'                => 'no',
                'recommit'                      => 'yes',
            ]);

            if($matchuser) 
            {
                Messages::create([

                    'user_id' => $user->id,
                    'message' => 'Hello '.$user->name.', you have changed your plan. You selected the NGN'.$user->plan.' Plan, you are required to pay a 50% upfront Donation of this plan you selected as Re-Commitment Charge. After two days you will be matched to donate a 100% of this same plan to your up liner or sponsor.The Fifty Percent is protecting you and other users. So the Total cash you will be paying is NGN '.$recomit_amount.''

                ]);
            }
            return 1;
		    }

		    
		    protected function recycle(Request $req){

		        $user =     User::findOrFail(\Auth::user()->id);

		        $newPH = new PH();

		        $newPH->create([
		            'user_id'               => $user->id,
		            'amount'                => $user->amount,
		           

		            ]);

		            $user->update([
		                'plan'        => $user->plan,    
		                'number_of_recycle' => Auth::user()->number_of_recycle + 1,
		                'payment_status'  => 'pay-pledge',            
		                ]);

		            return 1;
		    }
}
