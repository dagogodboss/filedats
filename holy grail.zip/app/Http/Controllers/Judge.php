<?php

namespace App\Http\Controllers;

use App\User;
use App\Messages;
use App\MatchedUser;
use App\Transaction;
use App\GetHelp;
use App\PurgeComplain;
use Illuminate\Http\Request;

class Judge extends Controller
{

    public function confirm_case(Request $request, PurgeComplain $purge, MatchedUser $list, User $user)
    {
    	
    	$user_to_confirm = $user->find($request->UserId);

    	$purge_details   = $purge->find($request->CaseId);
    	
    	$list_details    = $list->find($request->ListId);
    	
    	if($this->check_confirm_user_position($purge_details, $user_to_confirm, $list_details)){
    		return back()->with('success', 'The Confirmation Was Done Succesfully');
    	}else{
    	return back()->with('error',' The Server Encounter an Error Please Try again Later.');

    	}

    }

    public function purge_case(Request $request, PurgeComplain $purge, MatchedUser $list, User $user)
    {
    	$user_to_confirm = $user->find($request->UserId);
    	
    	$purge_details   = $purge->find($request->CaseId);
    	
    	$list_details    = $list->find($request->ListId);
    	
    	if($this->check_purge_user_position($purge_details, $user_to_confirm, $list_details)){
    		return back()->with('success', 'Purge process Completed');
    	}else{
    	return back()->with('error',' The Server Encounter an Error Please Try again Later.');
    		
    	}

    }

    private function check_confirm_user_position($details, $user, $match)
    {
    	($details->complainer_id == $user->id) ? $this->confirm_as_gh_user($details, $user, $match) : $this->confirm_as_ph_user($details, $user, $match) ;
    	return true;
    }

    private function confirm_as_ph_user($details, $user, $match)
    {
    	$data = Transaction::where('donation_list_id', $match->id)->get();
    	foreach ($data as $value) {
    		$value->upload_proof = 'yes';
    		$value->save();
    	}
    	$this->confirm_as_gh_user($details, $user, $match);
    }

    private function confirm_as_gh_user($details, $user, $match)
    {
    	$details->verdict  = 'judged';
    	$details->save();
    	$match->upload_proof = 'judged';
    	$match->save();
    	$user->user_account_state = null;
    	$user->save();
    	$donation_list = GetHelp::where('user_id', $user->id)->first();
    	if ($donation_list != null) {
    		$donation_list->amount =  $donation_list->amount + $match->amount;
    		$donation_list->save();
    		$this->message_user($user, config('app.win_case'));

    		return true;
    	}else{
    		if(GetHelp::create([
    			'user_name'  			=> $user->name,
    			'user_email' 			=> $user->email,
    			'amount'			=> $match->reserve_amount,
    			'user_id'			=> $user->id,
    			'bank_name'			=> $user->bank_name,
    			'phone_number'		=> $user->phone_number,
    			'account_number'	=> $user->account_number,
    		])){
    			$this->message_user($user, config('app.win_case'));

    			return true;
    		}
    	}
    }

    private function message_user($user, $msg)
    {
    	Messages::create([
    		'user_id' => $user->id,
    		'message' => $msg, 
    	]);

    	return true;
    }

    private function check_purge_user_position($details, $user, $match)
    {
    	($details->complainer_id == $user->id) ? $this->purge_user($details, $user, $match) : $this->purge_user($details, $user, $match) ;
    	return true;
    }

    private function purge_user($details, $user, $match)
    {
    	$details->verdict  = 'judged';
    	$details->save();
    	$match->upload_proof = 'judged';
    	$match->save();
    	$user->user_account_state = 'blocked';
    	$user->save();
    	if($this->message_user($user, config('app.lose_case'))){
    		return true;
    	}
    }

    public function Delete(Request $request, PurgeComplain $purge)
    {
        $purge->find($request->uuid)->delete();
        return back()->with('success', 'Delete Process Completed');
    }


    public function Delete_Match(Request $request, MatchedUser $list)
    {
        $list->find($request->uuid)->delete();
        return back()->with('success', 'Delete Process Completed');
    }

    
}
