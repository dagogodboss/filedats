<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use App\Get_Help_Admin_Table;

class Get_Help_Admin_TableController extends Controller
{
    public function index()
    {
        return view('admin.major.key.alert',[
            'users'     => User::all(),
            'get_help' => Get_Help_Admin_Table::where('user_id', '!=', 0)->paginate(15),
        ]);      
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'user_id' => 'required|numeric',
            'amount'  => 'required|numeric',
            ]);
        if(Get_Help_Admin_Table::create($request->all()))
        {
            return back()->with('success', 'Operation Completed :)');
        }else{
            return back()->with('success', 'What i Dont understand You (--)');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Get_Help_Admin_Table  $get_Help_Admin_Table
     * @return \Illuminate\Http\Response
     */
    public function show(Get_Help_Admin_Table $get_Help_Admin_Table, $id)
    {
       if($get_Help_Admin_Table->find($id)->delete()){
            return back()->with('success', 'User details deleted.');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Get_Help_Admin_Table  $get_Help_Admin_Table
     * @return \Illuminate\Http\Response
     */
    public function edit(Get_Help_Admin_Table $get_Help_Admin_Table)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Get_Help_Admin_Table  $get_Help_Admin_Table
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Get_Help_Admin_Table $get_Help_Admin_Table)
    {
        $data = $get_Help_Admin_Table->find($request->id);
        $input = $request->except([
            '_token',
            ]);
        $data->fill($input);
        $data->save();
        return redirect('/admin_backdoor')->with('success', 'The Editing was Successful');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Get_Help_Admin_Table  $get_Help_Admin_Table
     * @return \Illuminate\Http\Response
     */
    public function destroy(Get_Help_Admin_Table $get_Help_Admin_Table)
    {
        //
    }
}
