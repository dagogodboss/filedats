<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurgeComplain extends Model
{
    protected $fillable = [
		'matched_id',
		'payer_id',
		'payer_account_name',
		'payer_account_number',
		'payer_bank_name',
		'payer_phone_number',
		'amount',
		'complainer_id',
		'complanier_name',
		'complanier_account_number',
		'complanier_bank_name',
		'complanier_phone_number',
		'proof_of_payment',
		'mode_of_payment',
		'reason',
		'verdict',
    ];
}
