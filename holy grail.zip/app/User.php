<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{

    use Notifiable;

    protected $fillable = [
        'name', 
        'amount', 
        'verified',
        'gh_timer',
        'password',
        'bank_name',
        'phone_token',
        'recommitted',
        'paid_amount',
        'phone_number',
        'account_state',
        'amount_pledge',
        'account_number',
        'bonus_earnings',
        'payment_status',
        'complete_charge',
        'amount_collected',
        'bonus_to_receive',
        'amount_to_receive',
        'referral_earnings',
        'get_help_earnings',
        'commitment_charge',
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];

    public function roles()
    {
        return $this->belongsToMany(Role::class);
    }

    public function hasRole($role)
    {
        if(is_string($role))
        {
            return $this->roles->contains('name', $role);
        }

        return !! $role->intersect($this->roles)->count();

        return false;
    }

    public function assign($role)
    {
        if(is_string($role))
        {

                return $this->roles()->save(
                        Role::whereName($role)->firstOrFail()
                    );

        }
        
        return $this->roles()-save($role);
    }
    
    public function getReferrals()
    {
        return ReferralProgram::all()->map(function ($program) 
        {
            return ReferralLink::getReferral($this, $program);
        });
    }

    public function recommit()
    {
        return $this->hasOne('App\MatchedUser', 'provider_user_id');

    }

    public function recommitpayment()
    {
        return $this->hasOne('App\MatchedUser', 'sponsor_user_id');

    }
    
    public function gethelp()
    {
        return $this->hasOne('App\GetHelp', 'user_id');
    }
    
    public function provide_help()
    {
        return $this->hasOne('App\ProvideHelp', 'user_id');
    }

    public function messages()
    {
        return $this->hasOne('App\Messages');
    }
    
    public function DoantionToPay()
    {
        return $this->hasOne('App\MatchedUser', 'provider_user_id');
    }

    public function DonationToRecieve()
    {
        return $this->hasOne('App\MatchedUser', 'sponsor_user_id');   
    }

    public function referrals()
    {
        return $this->hasOne(ReferralRelationship::class, 'referree_user_id');
    }

    public function was_referred()
    {
        return $this->hasOne(ReferralRelationship::class);
    }

    public function receivetransaction()
    {
        return $this->hasOne('App\Transaction', 'r_user');
    }

    public function paidtransaction()
    {
        return $this->hasOne('App\Transaction', 'p_user');
    }

    public function complaincount()
    {
        return $this->hasOne('App\ComplainCount');
    }

    public function verification_count()
    {
        return $this->hasOne(Verification_Count::class);
    }

    public function admin_user()
    {
        return $this->hasOne(AdminTable::class);
    }

    public function waitingtimer()
    {
        return $this->hasOne(WaitingTimer::class);
    }

    public function get_help_admin_table()
    {
        return $this->hasOne(Get_Help_Admin_Table::class);   
    }
}
