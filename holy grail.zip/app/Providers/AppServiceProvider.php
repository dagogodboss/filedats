<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\View\Factory;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
         $site_config = DB::table('site_controls')->first();
            if ($site_config != null) 
            {
                view()->share('site_config', $site_config);
            }
    }

    /**
     * Register any application services.
     *
     * @return void
     */
   public function register()
        {
          //
        }
}
