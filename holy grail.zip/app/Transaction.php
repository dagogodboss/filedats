<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $fillable = [
      'p_user',
      'r_user',
      'amount',
      'matched_id',
      'payment_image',
      'payment_status',
    ];

    public function user()
    {
      return $this->belongTo('App\User');
    }
}
