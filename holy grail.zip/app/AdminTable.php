<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminTable extends Model
{
    protected $fillable = [
        'name',
    	'user_id',
    	'bank_name',
    	'phone_number', 
    	'amount_remain',
    	'account_number',
    	'amount_collected',
        'amount_to_receive',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
