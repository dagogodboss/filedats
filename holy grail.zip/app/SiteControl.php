<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SiteControl extends Model
{
    protected $fillable = [
    	'publish_match',
    ];
}
