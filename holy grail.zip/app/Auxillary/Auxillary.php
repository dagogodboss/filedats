<?php  
namespace App\Auxillary;

use App\User;
use App\GetHelp;
use App\Messages;
use Carbon\Carbon;
use App\AdminTable;
use App\MatchedUser;
use App\Transaction;
use App\ProvideHelp;
use App\PurgeComplain;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

class Auxillary 
{
	private $user,
            $get_help,
            $provide_help,
            $matched_user,
            $purge_complain,
            $user_complains,
            $admin_table,
            $messages;

    public function __construct(Request $request)
    {
        $this->user             = new User();
        $this->get_help         = new GetHelp();
        $this->messages         = new Messages();
        $this->admin_table      = new AdminTable();
        $this->provide_help     = new ProvideHelp();
        $this->matched_user     = new MatchedUser();
        $this->transaction      = new Transaction();
        $this->purge_complain   = new PurgeComplain(); 
        
    }
    public function recycle_user($gh_user)
    {
        $amount = ( $gh_user->re_commitment_fee * config('app.percent-growth')) + $gh_user->re_commitment_fee ;

        $gh_user->amount_pledge     = $gh_user->re_commitment_fee;
        $gh_user->ammount_to_paid   = null;
        $gh_user->amount_donated    = null;
        $gh_user->currently_receive = null;
        $gh_user->amount_to_recieve = $amount;
        $gh_user->donation_stage    = 'second';
        $gh_user->payment_status    = 'recycle'; 
        $gh_user->re_commitment_account = null;
        $gh_user->re_commitment_account = null;
        if($gh_user->save())
        {
            $this->send_message($gh_user, config('app.recycle_msg'));
            return true;
        }
    }

    public function pay_pledge($user, $details)
    {
        if($user->amount_pledge - $details->amount == 0) 
        {
            $this->re_commit_button($user);
        } 
        
        $user->amount_pledge       =  $user->amount_pledge     -  $details->amount;
        $user->brave_account       =  $user->brave_account     +  $details->amount;
        $user->ammount_to_paid     =  $user->ammount_to_paid   +  $details->amount;
        $user->amount_donated      =  $user->amount_donated    +  $details->amount;
        $user->total_amount_paid   =  $user->total_amount_paid +  $details->amount;
        $user->save();
        $this->Add_To_Transaction_table($details);
        
        if($this->Delete_Matched_User($details->id))
        {
           return true;
        }
    }
    
    public function insert_to_ph_table(){
        $this->provide_help->create([
            'user_id' => Auth::id(),
            'amount'  => Auth::user()->complete_charge,
        ]);
    }

    public function pay_to_get_bonus($amount){
        $Rcash = $amount * config('app.recomit_pecentage');
        $phCash = $amount * config('app.complete_percentage');
        Auth::user()->commitment_charge = $Rcash;
        Auth::user()->complete_charge   = $phCash;
        Auth::user()->bonus_to_receive  = Auth::user()->bonus_earnings;
        Auth::user()->bonus_earnings    = $amount * config('app.percentage');  
        Auth::user()->amount_pledge     = $amount;
        Auth::user()->gh_timer          = Carbon::now()->addDays(config('app.return_count'));
        if(Auth::user()->save() && $this->match_to_frontier($Rcash))
        {
            return true;
        }   
    }

    public function provide_helps($amount)
    {
        $Rcash = $amount * config('app.recomit_pecentage');
        $phCash = $amount * config('app.complete_percentage');
        Auth::user()->commitment_charge = $Rcash;
        Auth::user()->complete_charge   = $phCash;
        Auth::user()->bonus_earnings    = $amount * config('app.percentage');  
        Auth::user()->amount_pledge     = $amount;
        Auth::user()->gh_timer          = Carbon::now()->addDays(config('app.return_count'));
        if(Auth::user()->save() && $this->match_to_frontier($Rcash))
        {
            return true;
        }
    }

    public function match_to_frontier($amount)
    {
        $admin = $this->admin_table->inRandomOrder()->where('amount_to_receive', '>=', $amount)->where('user_id', '!=', Auth::id())->first();
        $this->matched_user->create([
            'sponsor_user_id' => $admin->user_id,
            'provider_user_id' => Auth::id(),
            'amount'            => $amount,
            'recommit'          => 'yes'
        ]);
            $admin->amount_to_receive = $admin->amount_to_receive - $amount;
            if($admin->save())
            {
                if ($admin->amount_to_receive <= 0) {
                    $this->send_admin_message($admin, 'You have completely receive your Frontier Benefit. Hence removed from the Table.');
                    if($admin->delete())
                    {
                        return true;
                    }
                }
                return true;
            }
    }
    
    public function send_admin_message($user, $message)
    {
         if ($this->messages->create([
                'user_id'   => $user->user_id,
                'name'      => $user->name,
                'message'   => $message,
                ])) {
                return true;
            } 
    }

    public function send_message($user, $message)
    {  
        if ($this->messages->create([
            'user_id'   => $user->id,
            'name'      => $user->name,
            'message'   => $message,
            ])) {
            return true;
        }
    }

    public function pay_recomit($user, $details)
    {
        if ($user->amount_pledge - $details->amount == 0 && $user->donation_stage == 'second') 
        {
            $this->add_to_get_help_list($user);        
        }
        $user->amount_pledge            =  $user->amount_pledge         -  $details->amount;
        $user->ammount_to_paid          =  $user->ammount_to_paid       +  $details->amount;
        $user->amount_donated           =  $user->amount_donated        +  $details->amount;
        $user->total_amount_paid        =  $user->total_amount_paid     +  $details->amount;
        $user->re_commitment_account    =  $user->re_commitment_account +  $details->amount;
        $user->save();
        $this->Add_To_Transaction_table($details);
        if($this->Delete_Matched_User($details->id))
        {
            return true;
        }
    }
    public function add_to_get_help_list($user)
    {
        $user->payment_status = 'receive-payment';
        $user->donation_stage = 'final';        
        $user->amount_donated =  null;
        $user->save();
        // check if the user is on the database
        if($this->get_help->findWith('user_id', $user->id)->first() != null)
        {
            $change_this_user = $this->get_help->findWith('user_id', $user->id)->first();
            $change_this_user->amount = $change_this_user->amount + $user->amount_to_recieve;
            $change_this_user->created_at = Carbon::now();
            $change_this_user->save();

            if($this->send_message($user, config('app.gh_add_msg'))){
                return true;
            }

        }
        else{
            $this->insert_to_gh($user);
            return true;
        }


    }
    public function insert_to_gh($user)
    {

                $user_permission = $user->hasRole('admin');
                
                if ($user_permission === true) {
                    $user_permission = 'admin';
                }
                else{
                    $user_permission = '';
                }

            if($this->get_help->create([
                    'user_id'               => $user->id,
                    'user_name'             => $user->name,
                    'user_email'            => $user->email,
                    'user_phone'            => $user->phone,
                    'user_bank_name'        => $user->bank_name,
                    'user_permission'       => $user_permission,
                    'user_account_name'     => $user->account_name,
                    'amount'                => $user->amount_to_recieve,
                    'user_account_number'   => $user->account_number,
                ]))
            {
                if($this->send_message($user, config('app.gh_add_msg'))){
                    return true;
                }
            }

    }
    public function re_commit_button($user)
    {
        $user->donation_stage = 're-commit-button';
        $user->save();
    }
    public function re_commit_user($user)
    {
        // create a message to the user that u have been re-committed   
        if($this->provide_help->findWith('user_id', '$user_id')->first() == null)
        {

                $re_commit_add = $this->provide_help->create([
                            'user_id'               => $user->id,
                            'user_name'             => $user->name,
                            'user_email'            => $user->email,
                            'user_phone'            => $user->phone,
                            'user_bank_name'        => $user->bank_name,
                            'user_account_name'     => $user->account_name,
                            'user_account_number'   => $user->account_number,
                            'amount'                => $user->re_commitment_fee,
                ]);
                if($re_commit_add)
                {
                    $re_commit_add->created_at = Carbon::now()->subDays(15);
                    $re_commit_add->save();
                    if($this->messages->create([
                        'user_id' => $user->id,
                        'name'    => $user->name,
                        'message' => 'You have been added to the Donation Table; To Pay your re-commitment Charges. Thanks for Your Co-operation',
                    ])){
                        $user->payment_status = 'pay-re-commitment';                
                        $user->donation_stage = 'second';
                        $user->amount_pledge = $user->brave_account;
                        $user->save();
                        return true;
                    }
                }  
        }
        return false; 
    }

    public function create_Purge_complain($persecutor, $plaintiff, $matched_details)
    {
    	$case_id = str_random(6); 

    	$this->purge_complain->create([
    		'case_id'						=> $case_id,
    		'matched_details_id'			=> $matched_details->id,
    		'persecutor_id'					=> $persecutor->id,
    		'persecutor_name'				=> $persecutor->name,
            'persecutor_email'              => $persecutor->email,
    		'persecutor_phone'				=> $persecutor->phone,
    		'persecutor_account_number'		=> $persecutor->account_number,
    		'plaintiff_id'					=> $plaintiff->id,
    		'plaintiff_name'				=> $plaintiff->name,
    		'plaintiff_email'				=> $plaintiff->email,
            'plaintiff_phone'               => $plaintiff->phone,
    		'plaintiff_account_number'		=> $plaintiff->account_number,
    		'amount'						=> $matched_details->amount,
    	]);

        return true;
    }

    public function revoke_To_gh($matched_data)
    {

        if($this->user->find($matched_data->sponsor_user_id))
        {
            $gh_user = $this->user->find($matched_data->sponsor_user_id);
           
            $user_permission = $gh_user->hasRole('admin');
                
            if ($user_permission === true) 
            {
                $user_permission = 'admin';
            }
            else
            {
                $user_permission = '';
            }
                if($this->get_help->findWith('user_id', $gh_user->id)->first() != null){
                    $newuser = $this->get_help->findWith('user_id', $gh_user->id)->first();
                    $newuser->amount = $newuser->amount + $matched_data->amount;
                    if($newuser->save()){

                    // if the ph has donated before if not delete all his matching 
                    $ph_user = $this->user->find(Auth::id());
                    if($ph_user->amount_donated == null)
                    {
                        $ph_user->amount_pledge = null;
                        $ph_user->re_commitment_fee = null;
                        
                        $ph_user->save(); 

                        $ph_user_matches = $this->matched_user->findWith('provider_user_id',$ph_user->id)->get();

                        if($ph_user_matches->isNotEmpty())
                        {
                            foreach ($ph_user_matches as $match_details) 
                            {
                                $gh_user = $match_details->sponsor_user_id;
    
                                $this->messages->create([
                                    'user_id' => $gh_user,
                                    'name'    => $match_details->sponsor_user_accont_name,
                                    'message' => $match_details->provider_user_account_name.' has Declined the payment to you, for reason best know to him.'
                                ]);
                                
                            }
                          $this->matched_user->where('provider_user_id',$ph_user->id)->delete();  
                        }

                    }
                    return true;
                    }
                }else{
                    $create = $this->get_help->create([
                        'user_id' => $gh_user->id,
                        'user_name' => $gh_user->name,
                        'user_email' => $gh_user->email,
                        'user_phone' => $gh_user->phone,
                        'amount' => $matched_data->amount,
                        'user_permission' => $user_permission,
                        'user_bank_name' => $gh_user->bank_name,
                        'user_account_name' => $gh_user->account_name,
                        'user_account_number' => $gh_user->account_number,
                        ]);

                if($create)
                {   
                    $create->created_at = Carbon::now()->subDays(15);
                    $create->save();
                    // if the ph has donated before if not delete all his matching 
                    $ph_user = $this->user->find(Auth::id());
                    if($ph_user->amount_donated == null)
                    {
                        $ph_user->amount_pledge = null;
                        $ph_user->re_commitment_fee = null;
                        
                        $ph_user->save(); 

                        $ph_user_matches = $this->matched_user->findWith('provider_user_id',$ph_user->id)->get();

                        if($ph_user_matches->isNotEmpty())
                        {
                            foreach ($ph_user_matches as $match_details) 
                            {
                                $gh_user = $match_details->sponsor_user_id;
    
                                $this->messages->create([
                                    'user_id' => $gh_user,
                                    'name'    => $match_details->sponsor_user_accont_name,
                                    'message' => $match_details->provider_user_account_name.' has Declined the payment to you, for reason best know to him.'
                                ]);
                                
                            }
                          $this->matched_user->where('provider_user_id',$ph_user->id)->delete();  
                        }

                    }
                    return true;
                } 
                }
                
            }
        
        return false;
    }
    
    public function revoke_To_gh_user($matched_data)
    {
       if($this->user->find($matched_data->sponsor_user_id))
            {
                $gh_user = $this->user->find($matched_data->sponsor_user_id);
               
                $user_permission = $gh_user->hasRole('admin');
                    
                    if ($user_permission === true) {
                        $user_permission = 'admin';
                    }
                    else{
                        $user_permission = '';
                    }
                if ($this->get_help->findWith('user_id', $gh_user->id)->first() != null) {
                    $newuser = $this->get_help->findWith('user_id', $gh_user->id)->first();
                    $newuser->amount = $newuser->amount + $matched_data->amount;
                    if ($newuser->save()) 
                    {
                       $this->messages->create([
                    'user_id' => $create->user_id,
                    'name'    => $create->user_name,
                    'message' => $matched_data->provider_user_account_name.' has Declined the payment to you, for reason best know to him.'
                                ]);
                        return true;
                    }
                }
                $create = $this->get_help->create([
                        'user_id' => $gh_user->id,
                        'user_name' => $gh_user->name,
                        'user_email' => $gh_user->email,
                        'user_phone' => $gh_user->phone,
                        'amount' => $matched_data->amount,
                        'user_bank_name' => $gh_user->bank_name,
                        'user_permission' => $user_permission,
                        'user_account_name' => $gh_user->account_name,
                        'user_account_number' => $gh_user->account_number,
                        ]);
            }
            if($create)
            {   
                $this->messages->create([
                    'user_id' => $create->user_id,
                    'name'    => $create->user_name,
                    'message' => $matched_data->provider_user_account_name.' has Declined the payment to you, for reason best know to him.'
                                ]);
                    $create->created_at = Carbon::now()->subDays(15);
                    $create->save();
                return true;
            }
        return false;
    }

    public function revoke_To_ph($matched_data)
    {
        $ph_user = $this->user->find($matched_data->provider_user_id);

        if ($this->provide_help->create([
                'user_id'                   => $ph_user->id,
                'user_name'                 => $ph_user->name,
                'user_email'                => $ph_user->email,
                'user_phone'                => $ph_user->phone,
                'amount'                    => $matched_data->amount,
                'user_bank_name'            => $ph_user->bank_name,
                'user_account_name'         => $ph_user->account_name,
                'user_account_number'       => $ph_user->account_number,
            ])) 
        {
            return true;
        }
            

        

        return false;     
    }

    public function check_user_account_state($user_account_status)
    {
            if($user_account_status->account_state !== 'tribunal' && $user_account_status->account_state !== 'blocked')
            {
                   switch ($user_account_status->account_state) {
                            case 'active':
                               $user_account_status->account_state = 'inactive';
                               $user_account_status->save();
                               return true;
                                break;
                            
                            default:
                               $user_account_status->account_state = 'active';
                               $user_account_status->save();
                               return true;
                                break;
                        }
               
                
                        
            }
            return false;
    }

    public function admin_confirm_the_user_add_to_gh($ph_user, $matched_details)
    {   
            $this->change_match_date($matched_details->sponsor_user_id);

            $this->change_match_date($matched_details->provider_user_id);
            
            switch ($ph_user->donation_stage) 
            {
                case 'first':
                    $this->pay_pledge_judge($ph_user, $matched_details);
                    break;
                
                case 'second':
                    $this->pay_recomit_judge($ph_user, $matched_details);
                    break;
            }
            
            $matched_details->payment_status = 'judged';

            $matched_details->provider_gives_proof = 'judged';

            if($matched_details->save())
            {
                return true;
            }
    }
    public function pay_pledge_judge($user, $details)
    {
        if($user->amount_pledge - $details->amount == 0) 
        {
            $this->re_commit_button($user);
        } 
        
        $user->amount_pledge       =  $user->amount_pledge     -  $details->amount;
        $user->brave_account       =  $user->brave_account     +  $details->amount;
        $user->ammount_to_paid     =  $user->ammount_to_paid   +  $details->amount;
        $user->amount_donated      =  $user->amount_donated    +  $details->amount;
        $user->total_amount_paid   =  $user->total_amount_paid +  $details->amount;
        $user->account_state       =  'active';
        $user->save();
        $this->Add_To_Transaction_table($details);
    }
    public function pay_recomit_judge($user, $details)
    {
        if ($user->amount_pledge - $details->amount == 0 && $user->donation_stage == 'second') 
        {
            $this->add_to_get_help_list($user);        
        }
        $user->amount_pledge            =  $user->amount_pledge         -  $details->amount;
        $user->ammount_to_paid          =  $user->ammount_to_paid       +  $details->amount;
        $user->amount_donated           =  $user->amount_donated        +  $details->amount;
        $user->total_amount_paid        =  $user->total_amount_paid     +  $details->amount;
        $user->re_commitment_account    =  $user->re_commitment_account +  $details->amount;
        $user->account_state       =  'active';
        $user->save();
        $this->Add_To_Transaction_table($details);
    }
    public function delete_user($user, $match_details)
    {
        $del_user = $this->user->find($user->id);
        $del_user->user_status = 'blocked';
        $del_user->account_state = 'blocked';
        $del_user->activate_account = 'blocked';
        $del_user->save();

        $match_details->payment_status = 'judged';
        $match_details->provider_gives_proof = 'judged';
        $match_details->save();
        return true;
    }
    
    public function admin_send_to_gh($gh_user, $matched_details)
    {
        if ($user_permission === true) {
                $user_permission = 'admin';
            }
            else{
                $user_permission = '';
            }
        
        if($this->get_help->findWith('user_id', $gh_user->id)->first() != null)
        {
            $newuser = $this->get_help->findWith('user_id', $gh_user->id)->first();
            $newuser->amount = $newuser->amount + $matched_details->amount;
            $newuser->save();  
            $matched_details->payment_status = 'judged';

            $matched_details->provider_gives_proof = 'judged';

            if($matched_details->save())
            {
                return true;
            }
        }
        else{

        $create_user = $this->gh_user->create([
            'user_id' => $gh_user->id,
            'user_name' => $gh_user->name,
            'user_email' => $gh_user->email,
            'user_phone' => $gh_user->phone,
            'amount'      => $matched_details->amount,
            'user_bank_name' => $gh_user->bank_name,
            'user_permission' => $user_permission,
            'user_account_name' => $gh_user->account_name,
            'user_account_number' => $gh_user->account_number,
        ]);
            if($create_user){
                $create_user->created_at = Carbon::now()->subDays(15);
                $this->gh_user->save();
            } 
        }
        
        $matched_details->payment_status = 'judged';

        $matched_details->provider_gives_proof = 'judged';

        if($matched_details->save())
        {
            return true;
        }
    }

    public function admin_confirm_the_ph_user_add_to_gh($ph_user, $matched_details)
    {
        $this->change_match_date($matched_details->sponsor_user_id);

        $this->change_match_date($matched_details->provider_user_id);

        $ph_user_current_amount = $ph_user->currently_recieve + $matched_details->amount;
        if(($ph_user->currently_paid/2)+$ph_user->currently_paid == $ph_user_current_amount)
        {
                $user_permission = $ph_user->hasRole('admin');
                
                if ($user_permission === true) {
                    $user_permission = 'admin';
                }
                else{
                    $user_permission = '';
                }
                if($this->get_help->create([
                        'user_id'               => $ph_user->id,
                        'user_name'             => $ph_user->name,
                        'user_email'            => $ph_user->email,
                        'user_phone'            => $ph_user->phone,
                        'user_bank_name'        => $ph_user->bank_name,
                        'user_permission'       => $user_permission,
                        'user_account_name'     => $ph_user->account_name,
                        'amount'                => $ph_user_current_amount,
                        'user_account_number'   => $ph_user->account_number,
                    ]))
                {
                    $ph_user->currently_recieve =  null;

                    $ph_user->currently_paid =  null;

                    $ph_user->account_state = 'active';
                    
                    $ph_user->save();
                    // the matched data to transaction table

                    $this->Add_To_Transaction_table($matched_details);

                    // find user to block in this case the sponsor_id
                    $block_this_user = User::find($matched_details->sponsor_user_id);
                    if ($block_this_user != null) 
                    {
                        $block_this_user->user_status = 'blocked';
                        $block_this_user->account_state = 'blocked';
                        $block_this_user->activate_account = 'blocked';
                        $block_this_user->save();
                    }
                    if($matched_details->delete())
                    {
                        return true;
                    }
                }
        }
        else
        {
            ($ph_user->currently_recieve == null) ? 
            
            $ph_user->currently_recieve = $matched_details->amount : 
            
            $ph_user->currently_recieve = $ph_user->currently_recieve + $matched_details->amount;

            $ph_user->account_state = 'active';

            if ($ph_user->save()) 
            {   
                $this->Add_To_Transaction_table($matched_details);

                // find user to block in this case the sponsor_id
                $block_this_user = User::find($matched_details->sponsor_user_id);
                if ($block_this_user != null) 
                {
                    $block_this_user->user_status = 'blocked';
                    $block_this_user->account_state = 'blocked';
                    $block_this_user->activate_account = 'blocked';
                    $block_this_user->save();
                }
                if($matched_details->delete())
                {
                    return true;
                }
            }
        }
        
    }

    public function admin_revoke_gh_delete_ph($gh_user, $matched_details)
    {
        //revoke gher and delete ph and delete the matched table

        $this->change_match_date($matched_details->sponsor_user_id);

        $this->change_match_date($matched_details->provider_user_id);

            if ($user_permission === true) {
                $user_permission = 'admin';
            }
            else{
                $user_permission = '';
            }


        $create_user = $this->gh_user->create([
            'user_id' => $gh_user->id,
            'user_name' => $gh_user->name,
            'user_email' => $gh_user->email,
            'user_phone' => $gh_user->phone,
            'amount'      => $matched_details->amount,
            'user_bank_name' => $gh_user->bank_name,
            'user_permission' => $user_permission,
            'user_account_name' => $gh_user->account_name,
            'user_account_number' => $gh_user->account_number,
        ]);
        if($create_user){

            $create_user->created_at = Carbon::now()->subDays(15);
            $this->gh_user->save();
        }
        $block_this_user = $this->user->find($matched_details->provider_user_id);
        if ($block_this_user != null) 
        {
            $block_this_user->user_status = 'blocked';
            $block_this_user->account_state = 'blocked';
            $block_this_user->activate_account = 'blocked';
            $block_this_user->save();
        }
        if($matched_details->delete())
        {
            return true;
        }
    }

    public function Add_To_Transaction_table($matched_details)
    {
        $user = $this->user->find($matched_details->sponsor_user_id);
        $user_two = $this->user->find($matched_details->provider_user_id);

        if($user != null and $user_two != null)
        {
            if($this->transaction->create([
                       'sponsor_user_id'                  => $matched_details->sponsor_user_id,
                       'sponsor_user_name'                => $matched_details->sponsor_user_accont_name,
                       'sponsor_user_email'               => $user->email,
                       'sponsor_user_phone'               => $matched_details->sponsor_user_phone,
                       'sponsor_user_account_number'      => $matched_details->sponsor_user_account_number,
                       'sponsor_user_bank_name'           => $matched_details->sponsor_user_bank_name,
                       'provider_user_id'                 => $matched_details->provider_user_id,
                       'provider_user_name'               => $matched_details->provider_user_account_name,
                       'provider_user_email'              => $user_two->email,
                       'provider_user_phone'              => $matched_details->provider_user_phone,
                       'provider_user_account_number'     => $matched_details->provider_user_account_number,
                       'provider_user_bank_name'          => $matched_details->provider_user_bank_name,
                       'amount'                           => $matched_details->amount,
                       'provider_gives_proof'             => $matched_details->provider_gives_proof,
                       'payment_status'                   => $matched_details->payment_status,
                   ]))
                {
                    return true;
                }
        }
    }

    public function change_match_date($user_id)
    {
        $gotten_data = $this->matched_user->where('provider_user_id', $user_id)->get();
        foreach ($gotten_data as $matched_details) 
        {
            $matched_details->created_at = Carbon::now()->addHours(2); 
            $matched_details->save();
        } 
        return true;
    }

    public function Delete_Matched_User($uuid)
    {
        if($this->matched_user->findWith('id', $uuid)->first()->delete()){
          return true;
        }
    }

}
