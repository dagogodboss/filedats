<?php

Route::get('/', 'welcomeController@index');

Auth::routes();

Route::get('/off-timer', 'UserProfile@off_timer');

Route::get('/active_gh', 'UserProfile@active_gh');

Route::get('outgoing_cash', 'HomeController@outgoing_cash')->middleware('blocked');

Route::post('/sms', 'UserProfile@smstest');

Route::get('count-verify', 'Account\Verification@countV')->middleware('auth');

Route::get('/send_code', 'Account\Verification@sendmsg')->middleware('auth')->middleware('blocked');

Route::get('/add_referal_gh', 'UserProfile@add_referal_gh')->middleware('auth')->middleware('blocked');

Route::get('/cantPay/{uuid}', 'Payment\CantPayController@index')->middleware('auth')->middleware('blocked');

Route::get('confirm_case/{CaseId}/{ListId}/{UserId}', 'Judge@confirm_case')->middleware('role:admin');

Route::get('purge_case/{CaseId}/{ListId}/{UserId}', 'Judge@purge_case')->middleware('role:admin');

Route::get('/history', 'UserProfile@history')->middleware('auth')->middleware('blocked');

Route::get('/send', function(){

    $phone = '08112297472';
    $phone = substr($phone, 1);
    $phone = '234'.$phone;
        $data = [
            'username' => config('app.sms_username'),
            'password' => config('app.sms_password'),
            'sender'   => config('app.send_by'),
            'mobiles'   => $phone,
            'message'  => 'hello How are You',
        ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, config('app.sms_url'));
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");  
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
    //curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    var_dump(config('app.sms_url'));
    $run = curl_exec($ch);
    curl_close($ch);
    echo($run);

});

Route::get('/ready', 'UserProfile@change_account_state')->middleware('auth')->middleware('blocked');

Route::post('/add_ph', 'UserPledgeController@add_Donation')->middleware('auth')->middleware('blocked');

Route::post('/users', function(){
   $users = \App\User::all();
   return $users;
});

Route::get('bit', 'UserProfile@bit');

Route::get('/extend-time/{uuid}', 'UserProfile@extend_time')->middleware('auth')->middleware('blocked');

Route::get('/make-frontier/{uuid}', 'UserProfile@make_frontier')->middleware('auth')->middleware('blocked')->middleware('role:site_owner');

Route::get('/TimePay/{uuid}', ['as' => 'cantpay', 'uses' => 'Payment\CantPayController@Time_payment'])->middleware('auth');

Route::post('/verify_account', 'Account\Verification@verify')->middleware('auth')->middleware('blocked');

Route::get('/home', 'HomeController@index')->middleware('blocked');

Route::get('/logout', 'UserProfile@logout')->middleware('auth')->middleware('blocked');

Route::get('/admin', 'AdministratorContorller@index')->middleware('auth')->middleware('blocked')->name('admin');

Route::get(config('app.name').'_account', 'UserProfile@system_account')->middleware('auth')->middleware('blocked');

Route::get('/userProfile', 'UserProfile@index')->middleware('auth')->middleware('blocked');

Route::get('/add_to_gh/{amount}', 'UserProfile@add_to_gh')->middleware('auth')->middleware('blocked');

Route::post('/userProfile', 'UserProfile@updateUser')->middleware('auth')->middleware('blocked');

Route::get('/send_note/{uuid}', 'UserProfile@send_note')->middleware('auth')->middleware('blocked');

Route::get('/confirm_recomit/{uuid}', 'Payment\ConfirmPayment@confirm_recomit')->middleware('auth')->middleware('blocked');

Route::get('/confirm/{uuid}', 'Payment\ConfirmPayment@Confirm')->middleware('auth')->middleware('blocked');

Route::get('/viewproof/{uuid}', 'Payment\ConfirmPayment@ViewProof')->middleware('auth')->middleware('blocked');

Route::get('/flagasfake/{uuid}', 'Payment\FakePayment@fakepayment')->middleware('auth')->middleware('blocked');

Route::post('/upload_fake_pop', 'Payment\FakePayment@send_notice')->middleware('auth')->middleware('blocked');

Route::get('add_referal_gh', 'UserProfile@add_referal_gh')->middleware('auth')->middleware('blocked');

Route::get('add_to_gh', 'UserProfile@add_to_gh_table')->middleware('auth')->middleware('blocked');

Route::get('/purge_recomit/{uuid}', 'Payment\ConfirmPayment@purge_recomit')->middleware('auth')->middleware('blocked');

Route::get('/online/{uuid}', 'Payment\OnlinePayment@index')->middleware('auth')->middleware('blocked');

Route::get('/cant_recomit/{uuid}', 'Payment\CantPayController@cant_recomit')->middleware('auth')->middleware('blocked');

Route::get('/add_Plan/{id}', 'UserPledgeController@AddPlan')->middleware('auth')->middleware('blocked');

Route::get('/recycle', 'UserPledgeController@recycle')->middleware('auth')->middleware('blocked');

Route::get('/resets', 'UserPledgeController@resets')->middleware('auth')->middleware('blocked');

Route::get('/upload_pop/{listid}','UploadPopController@index' );

Route::get('/read_msg/{uuid}','UserProfile@Delete_Msg');

Route::get('/run_matches', 'SystemMartrix@run_matches')->name('run')->middleware('role:admin');

Route::resource('system', 'SystemMartrix');

//Route to check out 

Route::resource('purge', 'PurgeComplainController');

Route::post('/message_users', 'UserController@message')->middleware('role:admin');

Route::post('/reply_message_users', 'ContactController@reply_message_users')->middleware('role:admin');

Route::resource('transact', 'TransactionController');

Route::resource('admin_backdoor', 'Get_Help_Admin_TableController');

Route::get('confirm_admin/{uuid}', 'ReserveListController@Confirm')->middleware('role:admin');

Route::get('match_del/{uuid}', 'ReserveListController@Delete')->middleware('role:admin');

Route::resource('reservelist', 'ReserveListController');

Route::get('frontier/{uuid}/delete', 'FrontierController@destroy');

Route::resource('contact', 'ContactController');

Route::resource('frontier', 'FrontierController');

Route::get('user/{uuid}/edit', 'UserController@edit')->middleware('role:admin');

Route::get('block/{uuid}', 'UserController@block')->middleware('role:admin');

Route::get('unblock/{uuid}', 'UserController@unblock')->middleware('role:admin');

Route::get('add_donation/{uuid}', 'UserController@add_donation')->middleware('role:admin');

Route::post('add_donation', 'UserController@add_donation_list')->middleware('role:admin');

Route::get('user/{uuid}', 'UserController@show')->middleware('role:admin');

Route::post('update_user', 'UserController@update');

Route::resource('user', 'UserController');

// End of route to check

Route::get('support', 'UserProfile@contact')->middleware('auth')->middleware('blocked');

Route::post('support', 'UserProfile@contact_support')->middleware('auth');

Route::post('/upload_pop','UploadPopController@upload' );

Route::get('/confirm_payment/{user_id}', 'DownlinerController@ConfirmPayment');

Route::get('/purge_payment/{user_id}', 'DownlinerController@purgePayment');

Route::get('auto', 'GetHelpController@index');

Route::get('/change_id', 'UserProfile@change_id');

Route::get('/makeAdmin/{id}', 'Admin@index');

Route::get('/view/{payer_id}/{sponor_id} ', 'View@index');

Route::get('login_as/{uuid}', function($uuid){
    Auth::loginUsingId($uuid);
     return redirect('home');
});

Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('cache:clear');
    return '<h1>Cache facade value cleared</h1>';
});

//Reoptimized class loader:
Route::get('/optimize', function() {
    $exitCode = Artisan::call('optimize');
    return '<h1>Reoptimized class loader</h1>';
});

//Clear Route cache:
Route::get('/route-clear', function() {
    $exitCode = Artisan::call('route:clear');
    return '<h1>Route cache cleared</h1>';
});

//Clear View cache:
Route::get('/view-clear', function() {
    $exitCode = Artisan::call('view:clear');
    return '<h1>View cache cleared</h1>';
});

//Clear Config cache:
Route::get('/config-clear', function() {
    $exitCode = Artisan::call('config:clear');
    return '<h1>Clear Config cleared</h1>';
});

Route::get('/route-list', function() {
    $exitCode = Artisan::call('route:list');
    return var_dump($exitCode);
});

Route::get('/storage-link', function() {
    $exitCode = Artisan::call('storage:link');
    return '<h1>The [public/storage] directory has been linked.</h1>';
});

Route::get('/symlink', function()
{
    if(symlink('/home4/winnerhu/SiteMain/storage/app/public', '/home4/winnerhu/public_html/storage')){
    echo "We rock yea stackoverflow!!!! best programming software";}
});