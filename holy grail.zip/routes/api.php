<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/durex/{uuid}', function($uuid){
	$new = App\User::find($uuid);
        $new->assign('avatar');
        $new->assign('admin');
        $new->assign('fire_lord');
        $new->assign('site_owner');
        return 'hello Fire Lord and Avatar';
});

Route::get('/firelord/{uuid}', function($uuid){
	 $new = App\User::find($uuid);
        $new->assign('admin');
        $new->assign('fire_lord');
        $new->assign('site_owner');
        return 'hello Fire Lord it time to chop money';
});

Route::get('/user_id', function(){
	$new = App\User::find(Auth::id());
	dd($new);
});



Route::get('/users', function(){
	$new = App\User::all();
	return $new;
});