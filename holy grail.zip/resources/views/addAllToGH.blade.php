@extends('layouts.user')

@section('content')

    
    <div class="main-panel">
         @include('./partials/topnav')

    <div  class="content">
                
        <div class="container-fluid">
        <div class="row">
        		 <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Striped Table with Hover</h4>
                                <p class="category">Here is a subtitle for this table</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-responsive table-striped">
                                    <thead>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>phone</th>
                                        <th>investment plan id</th>
                                        <th>ACCOUNT Name</th>
                                        <th>ACCOUNT Number</th>
                                        <th>Bank Name</th>
                                        <th>amount</th>
                                        <th>Action</th>

                                    </thead>
                                    <tbody>
                                    @forelse($all as $user )
                                        <tr>
                                            <td>{{$user->id}}</td>
                                            <td>{{$user->name}}</td>
                                            <td>{{$user->email}}</td>
                                            <td>{{$user->phone_number}}</td>
                                            <td>{{$user->investment_plan_id}}</td>
                                            <td>{{$user->name}}</td>
                                            <td>{{$user->account_number}}</td>
                                            <td>{{$user->bank_name}}</td>
                                            <td>{{$user->plan}}</td>
                                            <td><a href="confirm_payment/{{$user->id}}" class="btn btn-success">Activate</a></td>
                                            
                                        </tr>
                                        @empty
                                        <tr>
                                            Nothing To Add
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
	</div></div></div></div>
@endsection