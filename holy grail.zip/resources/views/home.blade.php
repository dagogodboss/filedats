@extends('layouts.user')

@section('content')


    <div class="main-panel">
         @include('./partials/topnav')

    <div  class="content">
        <div class="container-fluid">
                <div class="row">                    
                @if(Auth::user()->waitingtimer()->first()!= null && Auth::user()->waitingtimer()->first()->created_at < Carbon\Carbon::now()->subDays(14))
                        <div class="col-md-12" style="margin:10px;">
                            <a href="{{ url('/active_gh') }}" class="btn reap btn-fill btn-lg bg-green">I want To Reap </a>
                        </div>
                    @else
                        <div class="col-md-12" style="margin:10px;">
                            <button disabled="disabled" href="#" class="btn btn-disabled btn-fill btn-lg bg-green fake-reap">I want To Reap </button>
                        </div>
                    @endif
                    @if(Auth::user()->hasRole('admin') || Auth::user()->hasRole('pioneer') || Auth::user()->hasRole('site_owner'))
                        @include('partials.superuser.panel')
                    @else
                        @include('partials.user.panel')
                    @endif
            </div>            


        </div>
    </div>
        @include('partials.footer')
    </div>
@include('partials/imagelightbox')
@include('partials/fakePopForm')
@endsection
