@extends('layouts.user')

@section('content')

    
    <div class="main-panel">
         @include('./partials/topnav')

    <div  class="content">
                
        <div class="container-fluid">
		
		 <form action="{{ url('/addToGH') }}" method="post">
            
         
                                 {{ csrf_field() }}
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>User ID </label>
                                                <input type="text" name="user_id" class="form-control"  placeholder="ID of the USer">
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Phone Number</label>
                                                <input type="text" name="user_phone"  class="form-control" placeholder="Phone Number" >
                                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input name="user_email"  type="text" class="form-control" placeholder="" 
                                                >
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Bank Name</label>
                                                <input name="bank_name"  type="text" class="form-control" placeholder="Your Bank Name">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Account Name & Name of User</label>
                                                <input name="user_name"  type="text" class="form-control" placeholder="" 
                                                >
                                            </div>
                                        </div>

                                        <div class="col-md-6">


                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Investment Plan ID</label>
                                                <input name="investment_plan_id"  type="text" class="form-control" placeholder="" 
                                                >
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Investment Plan Name</label>
                                                <input name="investment_plan_name"  type="text" class="form-control" placeholder="Your Bank Name">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Account Number</label>
                                                <input name="account_number"  type="text" class="form-control" placeholder="" 
                                                >
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>User Phone</label>
                                                <input name="user_phone" type="text" class="form-control" placeholder="Home Address">
                                                 
                                    			<
                               					
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Amount</label>
                                                <input name="amount"  type="text" class="form-control" placeholder="Home Address" 
                                                >
                                                
                                    			<span class="help-block">
                                        		<strong></strong>
                                   				</span>
                                				
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add To Be Paid</button>
                                    <div class="clearfix"></div>
                                </form>
	</div></div></div>
@endsection