@extends('layouts.user')

@section('content')
    
    <div class="main-panel">
         @include('./partials/topnav')
         <div class="app">
        <div  class="content content-app" style="padding: 15px;
min-height: calc(100% - 123px);">

       <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Edit Profile</h4>
                            </div>
                            <div class="content">
                            <form action="{{ url('/update_user') }}" method="POST" role="form">
                                 {{ csrf_field() }}
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Email Address (disabled)</label>
                                                <input type="text" name="email" class="form-control" readonly="readonly" placeholder="Company" value="{{ $user->email }}">
                                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Phone Number</label>
                                                <input type="text" name="phone_number" class="form-control" placeholder="Phone Number" value="{{ $user->phone_number }}">
                                                @if ($errors->has('phone_number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('phone_number') }}</strong>
                                    </span>
                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Full Name</label>
                                                <input  disabled="true" type="text" class="form-control" placeholder="" value="{{ $user->name }}">
                                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Bank Name</label>
                                                <input name="bank_name"  type="text" class="form-control" placeholder="Your Bank Name" value="{{ $user->bank_name }}">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Account Name</label>
                                                <input name="name" type="text" class="form-control" placeholder="Home Address"
                                                 value="{{ $user->name }}">
                                                  @if ($errors->has('name'))
                                                <span class="help-block">
                                                <strong>{{ $errors->first('name') }}</strong>
                                                </span>
                                                 @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Account Number</label>
                                                <input name="account_number"  type="text" class="form-control" placeholder="Home Address" 
                                                value="{{ $user->account_number }}">
                                                 @if ($errors->has('account_number'))
                                                <span class="help-block">
                                                <strong>{{ $errors->first('account_number') }}</strong>
                                                </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                        <input type="hidden" name="id" value="{{$user->id}}">
                                    <button type="submit" class="btn btn-info btn-fill">Update Profile</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                                <img src="{{ asset('img/background.jpg') }}" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                     <a href="#">
                                    <img class="avatar border-gray" src="{{ asset('img/faces/face.png') }}" alt="..."/>

                                      <h4 class="title">{{ $user->name }}<br />
                                         <small>{{ $user->email }}</small>
                                      </h4>
                                    </a>
                                </div>
                                <p class="description text-center"> 
                                "{{ $user->phone_number }}"
                                <h4 class="text-center title">{{ $user->bank_name }}<br />
                                         <small>Bank</small>
                                      </h4>

                                <h5 class="text-center title">{{ $user->account_number }}<br />
                                         <small>Account Number</small>
                                      </h5>
                                </p>
                            </div>
                            <hr>
                            <div class="text-center">
                                <small><em>To Change Your Data Please use the form beside you.</em></small>

                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>
        </div>
        </div>
        @include('./partials/footer')

@endsection