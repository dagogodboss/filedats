@extends('layouts.user')

@section('content')
    
    <div class="main-panel">
         @include('./partials/topnav')
         <div class="app">
        <div  class="content content-app" style="padding: 15px;
min-height: calc(100% - 123px);">

       <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Edit Profile</h4>
                            </div>
                            <div class="content">
                            <form action="{{ url('/add_donation') }}" method="POST" role="form">
                                 {{ csrf_field() }}
                                 <input type="hidden" name="user_id" value="{{ $user->id}}">
                             
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Amount</label>
                                                <input  name="amount" type="text" class="form-control" placeholder="Amount To Receive " >
                                                @if ($errors->has('amount'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('amount') }}</strong>
                                    </span>
                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Account Name</label>
                                                <input type="text" class="form-control" placeholder="Home Address"
                                                 value="{{ $user->name }}">
                                                  @if ($errors->has('name'))
                                                <span class="help-block">
                                                <strong>{{ $errors->first('name') }}</strong>
                                                </span>
                                                 @endif
                                            </div>
                                        </div>
                                    </div>
                                        <input type="hidden" name="id" value="{{$user->id}}">
                                    <button type="submit" class="btn btn-info btn-fill">Add Donation</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>
        </div>
        </div>
        @include('./partials/footer')

@endsection