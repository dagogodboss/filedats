@extends('layouts.user')

@section('content')
	<div class="main-panel">
         @include('./partials/topnav')
         <div class="content">
         <div class="container-fluid">
         	 <div class="row">
	        	<div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Transaction Table</h4>
                                <p class="category">All the Transaction Details</p>
                            </div>
                            <div  class="content table-responsive">
                                <table id=""cellspacing="0" width="100%" class="display table table-striped table-hover">
                                    <thead>
                                    	<th>Payer Name</th>
                                    	<th>Receiver Name</th>
                                    	<th>Amount</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                    	<th>Action</th>
                                    </thead>
                                    <tbody>
                                    	@if(isset($transactions))
                                    	@forelse($transactions as $transaction)
                                        @php
                                            if($transaction != null):
                                            $data = \App\User::find($transaction->p_user);
                                            $data2 = \App\User::find($transaction->r_user);
                                            endif
                                        @endphp
                                        <tr>
                                        	<td>@if($data != null){{ $data->name}} @endif</td>
                                            <td>@if($data2 != null){{ $data2->name}} @endif</td>
                                        	<td>{{ $transaction->amount}} </td>
                                            <td>{{ $transaction->created_at}} </td>
                                        	<td>{{ $transaction->payment_status}} </td>
                                            <td> 
                                            @role('site_owner')
                                            <a class="btn btn-danger btn-fill" href="{{url('transact/'.$transaction->id)}}">Delete</a>
                                            @endrole
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>No Data Available</tr>
                                        @endforelse
                                        @endif
                                    </tbody>
                                </table>

                            </div>

                        </div>
                        {{ $transactions->links() }}
                    </div>
		        </div> 	
         	</div>
         </div>
    </div>
@endsection