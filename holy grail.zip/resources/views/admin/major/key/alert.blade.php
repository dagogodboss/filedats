@extends('layouts.user')

@section('content')
	<div class="main-panel">
         @include('./partials/topnav')
         <div class="content">
         <div class="container-fluid">
         	 <div class="row">
             <div class="col-md-6 col-sm-12">
                 <div class="card">
                     <div class="content">
                         <form action="{{route('admin_backdoor.index')}}" method="post" class="form" role="form">
                            {{ csrf_field() }}
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <select class="form-control" name="user_id" placeholder="User Name">
                                        <option></option>
                                        @if(isset($users))
                                        @forelse($users as $user)
                                            <option value="{{ $user->id }}">{{ $user->name}}</option>
                                        @empty
                                            <option>No User</option>
                                        @endforelse
                                        @endif
                                    </select>
                                    @if ($errors->has('user_id'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('user_id') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="col-md-6 form-group">
                                        <input class="form-control" type="text" name="amount" placeholder="Amount ">
                                    @if ($errors->has('amount'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('amount') }}</strong>
                                        </span>
                                    @endif
                                </div>

                            </div>
                            <button class="btn-fill btn-info btn">Submit</button>
                         </form>
                     </div>
                 </div>
             </div>
	        	<div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Major! This is Major</h4>
                                <p class="category">This are all the Major key alert members</p>
                            </div>
                            <div  class="content table-responsive">
                                <table id="adminListTable" cellspacing="0" width="100%" class="display table table-striped table-hover">
                                    <thead>
                                    	<th>Name</th>
                                    	<th>Phone</th>
                                        <th>Bank Name</th>
                                        <th>Acc Number</th>
                                        <th>Amount</th>
                                        <th>Just Use</th>
                                    	<th>Action</th>
                                    </thead>
                                    <tbody>
                                    	@if(isset($get_help))
                                        @forelse($get_help as $gh_details)
                                        @php
                                            if($gh_details != null):
                                            $data = \App\User::find($gh_details->user_id);
                                            endif
                                        @endphp
                                        <tr>
                                            <td>@if($data != null){{ $data->name}} @endif</td>
                                            <td>@if($data != null){{ $data->phone_number}} @endif</td>
                                            <td>@if($data != null){{ $data->bank_name}} @endif</td>
                                            <td>@if($data != null){{ $data->account_number}} @endif</td>
                                            <td>{{ $gh_details->amount}} </td>
                                            <td>{{ $gh_details->just_use}} </td>
                                            <td> 
                                            @role('site_owner')
                                            <a 
                                            id="{{ $gh_details->id }}" 
                                            data-user-name="{{$data->name}}" 
                                            data-amount="{{ $gh_details->amount}}" 
                                            data-just_use="{{ $gh_details->just_use }}" 
                                            data-url="{{ url('/admin_backdoor/'.$gh_details->id) }}"
                                            data="{{$gh_details->user_id}}" 
                                            class="btn btn-info btn-fill  msg-btn" 
                                            href="#@">Edit</a>

                                            <a class="btn btn-danger btn-fill" href="{{url('admin_backdoor/'.$gh_details->id)}}">Delete</a>
                                            @endrole
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>No Data Available</tr>
                                        @endforelse
                                        @endif
                                    </tbody>
                                </table>

                            </div>

                        </div>
                        {{ $get_help->links() }}
                    </div>
		        </div> 	
         	</div>
         </div>
    </div>
    <div class="modal fade" id="msg-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <form action="{{route('admin_backdoor.index')}}" class="form-edit" method="POST" role="form">
                        {{ csrf_field() }}
                        {{ method_field('PATCH')}}
                        <div class="form-group">
                            <p class="user-name">Ilamini Ayebatonye</p>
                        </div>
                        <div class="form-group">
                        <input class="form-control amount" type="text" value="" name="amount" placeholder="Amount ">
                            <input type="hidden" class="id" name="id" value="">
                        </div>
                        <div class="form-group">
                        <label>Has Been Used</label>
                        <input class="form-control just_use" type="text" value="" name="just_use" placeholder="Has Been Used ">
                            <input type="hidden" class="user_id" name="user_id" value="">
                        </div>
                        <button type="submit" class="btn btn-primary btn-fill">Edit</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" style="color: #000;" class="btn btn-default btn-fill" data-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div>
    </div>
    <!-- /.modal -->
<script type="text/javascript">
    $('a.msg-btn').click(function(e) 
    {
        e.preventDefault()
        var id          = $(this).attr('id');
        var user_id     = $(this).attr('data');
        var action      = $(this).attr('data-url');
        var amount      = $(this).attr('data-amount');
        var just_use    = $(this).attr('data-just_use');
        var name        = $(this).attr('data-user-name');
        
        $('#msg-modal').modal('show');

        $('p.user-name').html(name);
        $('input.id').attr('value', id);
        $('input.amount').attr('value', amount);
        $('input.user_id').attr('value', user_id);
        $('form.form-edit').attr('action', action)
        $('input.just_use').attr('value', just_use);
    })
</script>
@endsection

