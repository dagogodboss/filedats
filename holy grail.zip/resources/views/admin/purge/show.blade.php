@extends('layouts.user')

@section('content')
    <div class="main-panel">
         @include('./partials/topnav')
         <div class="content">
            <div class="container-fluid">
                <div class="row">
            <div class="col-md-4">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">{{ $detials->complanier_name }}</h4>
                                <p class="category">Account Number : {{ $detials->complanier_account_number }}</p>
                            </div>
                            <div class="content">
                                <img class="thumbnail img-responsive" src="{{asset('storage/'.$detials->proof_of_payment)}}">
                                 <small> 
                               <small class="legend">
                                    <i class="fa fa-circle text-success"></i> Mode : <em>{{ $detials->mode_of_payment }}</em>
                                    <i class="fa fa-circle text-success"></i> Identification : <em>{{ $detials->identification_number }}</em>
                                </small>
                                </small>
                                <div class="footer">
                                    <div class="legend">
                                        <i class="fa fa-circle text-info"></i> Phone : {{ $detials->complanier_phone_number }}
                                        <i class="fa fa-circle text-danger"></i> Bank Name : {{ $detials->complanier_bank_name }}
                                        <i class="fa fa-circle text-warning"></i> Amount : {{ $detials->amount }}
                                    </div>
                                    <hr>
                                    <div class="stats">
                                       <a class="text-success"  href="{{url('confirm_case/'.$detials->id.'/'.$detials->reserve_list_id.'/'.$detials->complainer_id)}}"> <i class="fa fa-check"></i> Confirm This User</a>

                                       <a class="text-danger" href="{{url('purge_case/'.$detials->id.'/'.$detials->reserve_list_id.'/'.$detials->complainer_id)}}"> <i class="fa fa-check"></i> Purge This User</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card col-sm-5 col-md-2 btn btn-round btn-warning"><h2>VS</h2></div>
                    <div class="col-md-4">
                                                <div class="card">
                            <div class="header">
                                <h4 class="title">{{ $detials->payer_account_name }}</h4>
                                <p class="category">Account Number : {{ $detials->payer_account_number }}</p>
                            </div>
                            <div class="content">
                                <img class="thumbnail img-responsive" src="@if(isset($reserve) && $reserve != null){{asset('storage/'.$reserve->proof_image)}}@else {{ asset('storage/'.$detials->proof_of_payment) }} @endif">
                               <small> 
                               <small class="legend">
                                    <i class="fa fa-circle text-success"></i> Mode : <em>{{ $detials->mode_of_payment }}</em>
                                    <i class="fa fa-circle text-success"></i> Identification : <em>{{ $detials->identification_number }}</em>
                                </small>
                                </small>
                                <div class="footer">
                                    <div class="legend">
                                        <i class="fa fa-circle text-info"></i> Phone : {{ $detials->payer_phone_number }}
                                        <i class="fa fa-circle text-danger"></i> Bank Name : {{ $detials->payer_bank_name }}
                                        <i class="fa fa-circle text-warning"></i> Amount : {{ $detials->amount }}
                                    </div>
                                    <hr>
                                    <div class="stats">
                                       <a class="text-success"  href="{{url('confirm_case/'.$detials->id.'/'.$detials->reserve_list_id.'/'.$detials->payer_id)}}"> <i class="fa fa-check"></i> Confirm This User</a>

                                       <a class="text-danger" href="{{url('purge_case/'.$detials->id.'/'.$detials->reserve_list_id.'/'.$detials->payer_id)}}"> <i class="fa fa-check"></i> Purge This User</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
            <div class="row">
                @forelse($images as $image)
                <div class="card hoverd col-md-3 " style="padding: 7px;margin:5px; height: 220px; overflow: hidden;">
                    <img class="thumbnail img-responsive" src="@if($image->proof_image != null){{asset('storage/'.$image->proof_image)}}@endif">
                </div>
                @empty
                    @if($reserve != null)
                <div class="card hoverd col-md-3 " style="padding: 7px;">
                    <img class="thumbnail img-responsive" src="@if($reserve->proof_image != null){{asset('storage/'.$reserve->proof_image)}}@endif">
                </div>   
                    @endif             
                @endforelse
            </div>
         </div>
            </div>
         </div>
    </div>
@endsection