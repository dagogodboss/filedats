@extends('layouts.user')

@section('content')
	<div class="main-panel">
         @include('./partials/topnav')
         <div class="content">
         <div class="container-fluid">
         	 <div class="row">
	        	<div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Purge Cases</h4>
                                <p class="category">List of all the People to receive donation</p>
                            </div>
                            <div  class="content table-responsive">
                                <table id="adminListTable"cellspacing="0" width="100%" class="display table table-striped table-bordered">
                                    <thead>
                                        <th>ID</th>
                                    	<th>Payer Name</th>
                                    	<th>Complainer Name</th>
                                    	<th>Amount</th>
                                    	<th>Action</th>
                                    </thead>
                                    <tbody>
                                    	@if(isset($purges))
                                    	@forelse($purges as $purgedetails)
                                        <tr>
                                        	<td>{{ $purgedetails->id }}</td>
                                        	<td>{{ $purgedetails->payer_account_name}} </td>
                                        	<td>{{ $purgedetails->complanier_name}} </td>
                                        	<td>{{ $purgedetails->reserve_amount}} </td>
                                            <td> 
                                            <a class="btn btn-success" href="{{url('purge/'.$purgedetails->id)}}">View Purge</a>  
                                            <a  class="btn btn-danger" href="{{url('case_del/'.$purgedetails->id)}}" >Delete Case</a>
                                            <a  class="btn btn-info" href="{{url('match_del/'.$purgedetails->reserve_list_id)}}" >Delete Matching</a>
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>No Data Available</tr>
                                        @endforelse
                                        @endif
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
		        </div> 	
         	</div>
         </div>
    </div>
@endsection