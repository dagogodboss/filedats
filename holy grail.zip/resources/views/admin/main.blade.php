@extends('layouts.user')

@section('content')
	<div class="main-panel">
         @include('./partials/topnav')

	    <div  class="content">
	                
	        <div class="container-fluid">
	        <div class="row">
	        	<a href="{{route('purge.index')}}" >
                    <div style="margin-left: 4px;" class="card btn btn-success btn-fill col-sm-12 col-md-2">
                            View Cases
                    </div>
                </a>

                <a href="{{route('reservelist.index')}}" >
                    <div style="margin-left: 4px;" class="card btn btn-info btn-fill  col-sm-12 col-md-2">
                            View Matches
                    </div>
                </a>


                <a href="{{route('transact.index')}}" >
                    <div style="margin-left: 4px;" class="card btn btn-danger btn-fill  col-sm-12 col-md-2">
                            View Transaction List
                    </div>
                </a>


                <a href="{{route('user.index')}}" >
                    <div style="margin-left: 4px;" class="card btn btn-warning btn-fill  col-sm-12 col-md-2">
                            View User List
                    </div>
                </a>

                <a href="{{route('contact.index')}}" >
                    <div style="margin-left: 4px;" class="card btn bg-teal btn-fill  col-sm-12 col-md-2">
                            Contact Manager
                    </div>
                </a>
                @role('site_owner')
                <a href="{{route('admin_backdoor.index')}}" >
                    <div style="margin-left: 4px;" class="card btn bg-purple btn-fill  col-sm-12 col-md-2">
                        Add User To Back Door 
                    </div>
                </a>
                @endrole
            </div>
            <div class="row">
        	<div class="">
            @role('site_owner')
	        	<div class="card col-md-5 col-sm-12">
                    <a href="{{ route('run') }}" class="btn btn-success btn-fill">Run Matches</a>
                    <a href="{{ route('frontier.index') }}" class="btn bg-light-blue btn-fill">Run Edit Frontier</a>
	        	</div>
            @endrole
        	</div>
	        </div>
	        </div>

	    </div>

 	</div>
@endsection