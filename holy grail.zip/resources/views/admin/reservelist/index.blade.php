@extends('layouts.user')

@section('content')
	<div class="main-panel">
         @include('./partials/topnav')
         <div class="content">
         <div class="container-fluid">
         	 <div class="row">
	        	<div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Reserve List</h4>
                                <p class="category">List of all the People to receive donation</p>
                            </div>
                            <div  class="content table-responsive">
                                <table id=""cellspacing="0" width="100%" class="display table table-striped table-hovered">
                                    <thead>
                                    	<th>Payer Name</th>
                                    	<th>Receiver Name</th>
                                    	<th>Amount</th>
                                        <th>Status</th>
                                    	<th>Action</th>
                                    </thead>
                                    <tbody>
                                    	@if(isset($matches))
                                    	@forelse($matches as $matchdetails)
                                        @php
                                            if($matchdetails != null):
                                            $data = \App\User::find($matchdetails->provider_user_id);
                                            $data2 = \App\User::find($matchdetails->sponsor_user_id);
                                            endif
                                        @endphp
                    
                                        <tr>
                                        	<td>@if($data != null){{ $data->name}} @endif</td>
                                            <td>@if($data2 != null){{ $data2->name}} @endif</td>
                                        	<td>{{ $matchdetails->amount}} </td>
                                            <td>{{ $matchdetails->payment_status}} </td>
                                            <td> 
                                            <a class="btn btn-warning btn-fill" href="{{url('reservelist/'.$matchdetails->id)}}">Purge</a>  
                                            <a class="btn btn-success  btn-fill" href="{{url('confirm_admin/'.$matchdetails->id)}}">Confirm</a>
                                            @role('avatar')<a class="btn btn-info  btn-fill" href="{{url('reservelist/'.$matchdetails->id.'/edit')}}" >Edit </a>@endrole
                                            <a class="btn btn-danger  btn-fill" href="{{url('match_del/'.$matchdetails->id)}}">Delete</a>
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>No Data Available</tr>
                                        @endforelse
                                        @endif
                                    </tbody>
                                </table>

                            </div>

                        </div>
                        {{ $matches->links() }}
                    </div>
		        </div> 	
         	</div>
         </div>
    </div>
@endsection