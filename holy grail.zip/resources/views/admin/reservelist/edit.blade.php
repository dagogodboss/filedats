@extends('layouts.user')

@section('content')
		
		<div class="main-panel">
         @include('./partials/topnav')
         	<div class="content">
         		<div class="container-fluid">
         			
		        <div class="row">
		        	<div class="col-md-10 col-sm-12">
		        		<div class="card">
		        			<div class="header">
		        				<h4>Edit Match Details </h4>
		        			</div>
		        			<div class="content">
		        				<form action="{{ url('/reservelist/'.$reservelist->id) }}" method="POST" role="form">
                                 {{ csrf_field() }}
                                 {{ method_field('PATCH')}}
                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Receiver Full Name / Account Name</label>
                                                <input type="text" name="sponsor_user_id" class="form-control" placeholder="John Micheal" value="{{ $reservelist->sponsor_user_id }}">
                                                @if ($errors->has('name'))
			                                    <span class="help-block">
			                                        <strong>{{ $errors->first('name') }}</strong>
			                                    </span>
			                                	@endif
                                            </div>
                                        </div>

                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Payer Full Name / Account Name</label>
                                                <input type="text" name="provider_user_id"="true" class="form-control" placeholder="Phone Number" value="{{ $reservelist->provider_user_id }}">
                                                @if ($errors->has('payer_account_name'))
			                                    <span class="help-block">
			                                        <strong>{{ $errors->first('payer_account_name') }}</strong>
			                                    </span>
			                                	@endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label>Amount Of Money</label>
                                                <input name="amount"  type="text" class="form-control" placeholder="Amount of Money in Numbers" value="{{ $reservelist->amount }}">
                                                @if ($errors->has('amount'))
                                    			<span class="help-block">
                                        		<strong>{{ $errors->first('amount') }}</strong>
                                    			</span>
                               					 @endif
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="id" value="{{ $reservelist->id}}">
                                    <button type="submit" class="btn btn-info btn-fill">Edit Details To List</button>
                                    <div class="clearfix"></div>
                                </form>
		        			</div>
		        		</div>
		        	</div>	
		        </div>
         		</div>
         	</div>
		</div>

@endsection