@extends('layouts.user')

@section('content')
	<div class="main-panel">
         @include('./partials/topnav')

	    <div  class="content">
	                
	        <div class="container-fluid">
	        			        <div class="row">
		        	<div class="col-md-10 col-sm-12">
		        		<div class="card">
		        			<div class="header">
		        				<h4>Fill in the Form</h4>
		        			</div>
		        			<div class="content">
		        				<form action="{{ url('/editList') }}" method="post" role="form">
                                 {{ csrf_field() }}
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Full Name / Account Name</label>
                                                <input type="text" name="name" class="form-control" placeholder="John Micheal" value="{{ $donationDetials->name }}">
                                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Phone Number</label>
                                                <input type="text" name="phone_number"="true" class="form-control" placeholder="Phone Number" value="{{ $donationDetials->phone_number }}">
                                                @if ($errors->has('phone_number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('phone_number') }}</strong>
                                    </span>
                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Amount Of Money</label>
                                                <input name="amount"  type="text" class="form-control" placeholder="Amount of Money in Numbers" value="{{ $donationDetials->amount }}">
                                                @if ($errors->has('amount'))
                                    			<span class="help-block">
                                        		<strong>{{ $errors->first('amount') }}</strong>
                                    			</span>
                               					 @endif
                                            </div>
                                        </div>

                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Bank Name</label>
                                                <input name="bank_name"  type="text" class="form-control" placeholder="Your Bank Name" value="{{ $donationDetials->bank_name }}">
                                                @if ($errors->has('bank_name'))
                                    			<span class="help-block">
                                        		<strong>{{ $errors->first('bank_name') }}</strong>
                                    			</span>
                               					 @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Email Address</label>
                                                <input name="email"  type="text" class="form-control" placeholder="Email Of the user" value="{{ $donationDetials->email }}">
                                                @if ($errors->has('email'))
                                    			<span class="help-block">
                                        		<strong>{{ $errors->first('email') }}</strong>
                                    			</span>
                               					 @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Account Number</label>
                                                <input name="account_number" type="text" class="form-control" placeholder="Account Number Of the User" value="{{ $donationDetials->account_number }}">
                                                  @if ($errors->has('account_number'))
                                    			<span class="help-block">
                                        		<strong>{{ $errors->first('account_number') }}</strong>
                                    			</span>
                               					 @endif
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Date </label>
                                                <input name="created_at"  type="text" class="form-control" placeholder="Home Address" value="{{ $donationDetials->created_at }}">
                                                 @if ($errors->has('created_at'))
                                    			<span class="help-block">
                                        		<strong>{{ $errors->first('created_at') }}</strong>
                                   				</span>
                                				@endif
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="uuid" value="{{$donationDetials->id}}">
                                    <button type="submit" class="btn btn-info btn-fill">Edit Donation Details</button>
                                    <div class="clearfix"></div>
                                </form>
		        			</div>
		        		</div>
		        	</div>	
		        </div>
	        </div>
	    </div>
	</div>
@endsection