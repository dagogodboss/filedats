@extends('layouts.user')

@section('content')
	<div class="main-panel">
         @include('./partials/topnav')
         <div class="content">
         <div class="container-fluid">
         	 <div class="row">
	        	<div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Users On The Database</h4>
                                <p class="category">List of all the People on the System</p>
                            </div>
                            <div  class="content table-responsive">
                                <table id="adminListTable" cellspacing="0" width="100%" class="display table table-striped table-hover">
                                    <thead>
                                    	<th>Name</th>
                                    	<th>Phone</th>
                                        <th>Bank Name</th>
                                        <th>Acc Number</th>
                                    	<th>Action</th>
                                    </thead>
                                    <tbody>
                                    	@if(isset($users))
                                    	@forelse($users as $user)
                                        <tr>
                                        	<td>{{ $user->name}} </td>
                                        	<td>{{ $user->phone_number}} </td>
                                            <td>{{ $user->bank_name}} </td>
                                        	<td>{{ $user->account_number}} </td>
                                            <td> 
                                            <a class="btn btn-info btn-fill" href="{{url('frontier/'.$user->id.'/edit')}}"><i class="pe-7s-pen"></i> Edit</a>
                                            <a class="btn btn-success btn-fill msg-btn" data="{{$user->id}}" href="#"><i class="pe-7s-chat"></i> Message</a>
                                            <a class="btn btn-danger btn-fill" href="{{url('frontier/'.$user->id.'/delete')}}"><i class="pe-7s-lock"></i> Delete</a>

                                            </td>
                                        </tr>
                                        @empty
                                        <tr>No Data Available</tr>
                                        @endforelse
                                        @endif
                                    </tbody>
                                </table>

                            </div>

                        </div>
                        {{ $users->links() }}
                    </div>
		        </div> 	
         	</div>
         </div>
    </div>
    <div class="modal fade" id="msg-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <form action="{{url('/message_users')}}" method="POST" role="form">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <textarea name="message" style="height: 300px;"  class="form-control" placeholder="Type In the Message you want to send to the admin"></textarea>
                            <input type="hidden" class="user_id" name="user_id" value="">
                        </div>
                        <button type="submit" class="btn btn-primary btn-fill">Send Message</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-fill" data-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div>
    </div>
    <!-- /.modal -->
<script type="text/javascript">
    $('a.msg-btn').click(function(e) 
    {
        e.preventDefault()
        var user_id = $(this).attr('data')
        
         $('#msg-modal').modal('show')

         $('input.user_id').attr('value', user_id)
    })
</script>
@endsection

