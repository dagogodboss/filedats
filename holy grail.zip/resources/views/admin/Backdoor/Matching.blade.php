@extends('layouts.user')

@section('content')
		
		<div class="main-panel">
         @include('./partials/topnav')
         	<div class="content">
         		<div class="container-fluid">
         			
		        <div class="row">
		        	<div class="col-md-10 col-sm-12">
		        		<div class="card">
		        			<div class="header">
		        				<h4>Edit Match Details </h4>
		        			</div>
		        			<div class="content">
		        				<form action="{{ url('/admin_priv_match') }}" method="POST" role="form">
                                 {{ csrf_field() }}
                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Receiver id</label>
                                                <select class="form-control receiver_id" name="owner_id" >
                                                <option>Users and their ID</option>
                                                @forelse($users as $theuser)
                                                    <option value="{{ $theuser->id }}">
                                                    {{ $theuser->name }} ID is {{$theuser->id}} 
                                                    </option>
                                                @empty
                                                <option>No User On The DataBase</option>

                                                @endforelse
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Payer id</label>
                                                <select class="form-control payer_id" name="user_id" >   
                                                <option>Users and their ID</option>
                                                @forelse($users as $theuser)
                                                    <option value="{{ $theuser->id }}">
                                                    {{ $theuser->name }} ID is {{$theuser->id}} 
                                                    </option>
                                                @empty
                                                <option>No User On The DataBase</option>

                                                @endforelse
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Receiver Full Name / Account Name</label>
                                                 <input type="text" class="receiver_name form-control" name="account_name"  placeholder="John Micheal" value="">
                                            </div>
                                        </div>

                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Payer Full Name / Account Name</label>
                                                <input type="text" class="form-control payer_name" name="payer_account_name"="true" placeholder="Phone Number" value="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Receiver Phone Number</label>
                                                <input type="text" class="form-control receiver_phone" name="phone_number"="true" placeholder="Phone Number" value="">
                                                
                                            </div>
                                        </div>


                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Payer Phone Number</label>
                                                <input type="text" class="form-control payer_phone" name="payer_phone_number"  placeholder="Phone Number" value="">
                                                
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Amount Of Money</label>
                                                <input name="amount"  type="text" class="form-control" placeholder="Amount of Money in Numbers" value="">
                                            </div>
                                        </div>

                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Payemnt Status</label>
                                                <input name="upload_proof"  type="text" class="form-control" placeholder="Yes No Judged" value="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">

                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Receiver Bank Name</label>
                                                <input name="bank_name"  type="text" class="form-control receiver_bank" placeholder="Your Bank Name" value="">
                                               
                                            </div>
                                        </div>

                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Payer Bank Name</label>
                                                <input name="payer_bank_name" type="text" class="form-control payer_bank" placeholder="Your Bank Name" value="">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        
                                        <div class="col-sm-12 col-md-8">
                                            <div class="form-group">
                                                <label>Amount To Reserve</label>
                                                <input name="reserve_amount" type="text" class="form-control" placeholder="How Much Do you want" value="">
                                            </div>
                                        </div>
                                        
                                        <div class="col-sm-12 col-md-3">
                                            <div class="form-group">
                                                <label>Donation List Id</label>
                                                <input name="donation_lists_id" type="text" class="form-control" placeholder="ID of the Donation List" value="">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Receiver Account Number</label>
                                                <input name="account_number" type="text" class="form-control receiver_account_number" placeholder="Account Number Of the User" value="">
                                            </div>
                                        </div>

                                        <div class="col-sm-12 col-md-6">
                                            <div class="form-group">
                                                <label>Payer Account Number </label>
                                                <input name="payer_account_number" type="text" class="form-control payer_account_number" placeholder="Home Address" value="">
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="proof_image" value="null">
                                    <button type="submit" class="btn btn-info btn-fill">Add To List</button>
                                    <div class="clearfix"></div>
                                </form>
		        			</div>
		        		</div>
		        	</div>	
		        </div>
         		</div>
         	</div>
		</div>

@endsection