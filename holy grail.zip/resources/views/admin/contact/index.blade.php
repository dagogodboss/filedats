@extends('layouts.user')

@section('content')
	<div class="main-panel">
         @include('./partials/topnav')
         <div class="content">
         <div class="container-fluid">
         	 <div class="row">
	        	<div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Support Tickets</h4>
                                <p class="category">All the Messages Send By User</p>
                            </div>
                            <div  class="content table-responsive">
                                <table id=""cellspacing="0" width="100%" class="display table table-striped table-hover">
                                    <thead>
                                    	<th>Sender Name</th>
                                    	<th>Message</th>
                                        <th>Time</th>
                                    	<th>Action</th>
                                    </thead>
                                    <tbody>
                                    	@if(isset($contact))
                                    	@forelse($contact as $contact_details)
                                        @php
                                            if($contact_details != null):
                                            $data = \App\User::find($contact_details->user_id);
                                            endif
                                        @endphp
                                        <tr>
                                        	<td>@if($data != null){{ $data->name}} @endif</td>
                                        	<td>{{ $contact_details->message}} </td>
                                            <td>{{ $contact_details->created_at}} </td>
                                            <td> 
                                            <a id="{{ $contact_details->id }}" class="btn btn-info btn-fill  msg-btn" data="{{$contact_details->user_id}}" href="#@">Reply</a>
                                            @role('site_owner')
                                            <a class="btn btn-danger btn-fill" href="{{url('contact/'.$contact_details->id)}}">Delete</a>
                                            @endrole
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>No Data Available</tr>
                                        @endforelse
                                        @endif
                                    </tbody>
                                </table>

                            </div>

                        </div>
                        {{ $contact->links() }}
                    </div>
		        </div> 	
         	</div>
         </div>
    </div>


    <div class="modal fade" id="msg-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <form action="{{url('/reply_message_users')}}" method="POST" role="form">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <textarea name="message" style="height: 300px;"  class="form-control" placeholder="Type In the Message you want to send to the admin"></textarea>
                            <input type="hidden" class="user_id" name="user_id" value="">
                            <input type="hidden" class="id" name="id" value="">
                        </div>
                        <button type="submit" class="btn btn-primary btn-fill">Send Message</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-fill" data-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div>
    </div>
    <!-- /.modal -->
<script type="text/javascript">
    $('a.msg-btn').click(function(e) 
    {
        e.preventDefault()
        var user_id = $(this).attr('data')
        var id = $(this).attr('id')
        
         $('#msg-modal').modal('show')

         $('input.user_id').attr('value', user_id)
         $('input.id').attr('value', id)
    })
</script>
@endsection