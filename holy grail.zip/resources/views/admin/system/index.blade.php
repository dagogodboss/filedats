@extends('layouts.user')

@section('content')



    <div class="main-panel">
         @include('./partials/topnav')

    <div  class="content">
        <div class="container-fluid">
                <div class="row">
                <a href="{{ route('run') }}" class="btn btn-success btn-fill">Run Matches</a>
                </div>

       </div>
    </div>

    </div>
@endsection