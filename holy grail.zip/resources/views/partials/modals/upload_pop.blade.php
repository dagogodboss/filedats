<div class="modal fade bs-example-modal-sm"  role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel2">Upload Poof Of Payment</h4>
                        </div>
                        <div class="modal-body">
                          <h6>Click the Box Below Or Drag and Drop Your Proof in the Box</h6>
                          <p>
                          <form action="{{ url('/uplaod_pop') }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}

                          </form></p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          <button type="button" class="btn btn-primary">Save changes</button>
                        </div>

                      </div>
                    </div>
                  </div>
                  <!-- /modals -->
               