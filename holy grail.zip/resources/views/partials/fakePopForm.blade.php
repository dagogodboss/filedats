 <div class="modal fade" id="pop-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content card">
<div class="header">
    <h4 class="title">Upload the Fake Payment Proof To Admin for verification</h4>
</div>
<div class="content">
    <form action="{{ url('/upload_fake_pop') }}" method="post" class="form-pop" role="form" enctype="multipart/form-data">
     {{ csrf_field() }}
     <div class="row">
        <div class="col-md-6">
        <div class="form-group{{ $errors->has('mode_of_payment') ? ' has-error' : '' }}">
            <label>Mode Of Payment</label>
        <select class="form-control" name="mode_of_payment">
          <optgroup>Mode Of Payment</optgroup>
          <option value="Online Transfer">Online Transfer</option>
          <option value="USSD">USSD</option>
          <option value="Bank Payment">Bank Payment</option>
          <option value="Mobile Banking">Mobile Banking</option>
          @if ($errors->has('mode_of_payment'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('mode_of_payment') }}</strong>
                                    </span>
                                @endif
        </select>
             
        </div>
        </div>

        <div class="col-md-6">
        <div class="form-group{{ $errors->has('identification_number') ? ' has-error' : '' }}">
            <label>Reason</label>
            <input required="required" type="text" class="form-control" name="identification_number" placeholder="The Reason :>  The Payment is Fake" minlength="6">
             @if ($errors->has('identification_number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('identification_number') }}</strong>
                                    </span>
                                @endif
        </div>
        </div>
     </div>
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="form-group">
                    <label>Select the POP</label>
                    <button  type="button" class="btn btn-info btn-fill btn-block">Select Image <i style="font-size: 32px;" class="pe-7s-id"></i></button>
                    <input type="file" name="proof_of_payment" class="upload-button" style="cursor: pointer; width: 100%;height: 51px;position: relative;top: -53px;opacity: 0;">

                   
                </div>
            </div>
        </div>
       <input type="hidden" value="" name="uuid" class="uuid">
        <button type="submit" class="btn btn-info btn-fill pull-right">Upload Proof</button>
        <div class="clearfix"></div>
    </form>
</div>
                <div class="">
                    <button type="button" style="margin: 10px;" class="btn btn-danger btn-fill" data-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div>
    </div>