<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 pull-left ">
                    <div class="card  bg-cyan card-dagogo same-height">
                        <div class="content" style="font-size: large;">
                        @if(Auth::user()->account_state == 'intro')
                            Welcome, I can see you are new please click on How things work to see detailed and concise instruction on how to operate on our platform <br>
                            <a href="#" class="btn bg-green waves-effect btn-fill how-it-works" style="opacity: 1">Read How it Work</a> 
                        @else
                        	Do You have any Question please read the FAQs or something is not right with your account view or details please feel free to contact Admin
                        	<br>
                            <a href="{{ url('/support') }}" class=" btn-fill btn bg-orange waves-effect"  style="opacity: 1">Contact Admin</a>
                        @endif

                        </div>
                    </div>
                </div>