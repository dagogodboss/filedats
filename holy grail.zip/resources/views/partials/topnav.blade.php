        <nav class="navbar navbar-default navbar-fixed" style="background:#2c3e50;color:#fff !important;">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" style="color: #fff;" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar" style="background-color: #fff;"></span>
                        <span class="icon-bar" style="background-color: #fff;"></span>
                        <span class="icon-bar" style="background-color: #fff;"></span>
                    </button>
                    <a style="color:#fff !important;" class="navbar-brand" href="{{ url('home') }}">
                    @if(Auth::user()->hasRole('participant'))
                        Hello My Faithful User
                    @elseif(Auth::user()->hasRole('avatar'))
                        Hello! Avatar 
                    @elseif(Auth::user()->hasRole('site_owner'))
                        Hello! Boss 
                    @elseif(Auth::user()->hasRole('pioneer'))
                        Hello Frontiers
                    @elseif(Auth::user()->hasRole('admin'))
                        Hello! Moderator 
                    @endif            
                    </a>
                    <a href="" class="navbar-brand how-it-works">How It Works</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a style="color:#fff !important;"  href="{{ url('/outgoing_cash')}}">
                               My Match Users
                               <span class="notification">{{
                               Auth::user()->DoantionToPay()->whereNull('recommit')->get()->count()
                               }}</span>
                            </a>
                        </li>
                        <li>
                            <a  style="color:#fff  !important;" href="{{ url('/logout') }}">
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        @if(Auth::user()->account_state == 'verified')
        <div class="col-md-3 col-sm-12  col-xs-12 pull-right">
            <div class="card">
            <div class="content">
                <h3 class="text-center text-success"> <span class="text-center pe-7s-medal"></span><br>Verified Account</h3>
            </div>
            </div>
        </div>
        <div class="clear-mobile"></div>
        @endif