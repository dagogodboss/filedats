<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 ">
                    <div class="card same-height bg-teal ">
                        <div class="content ">
                            <p> Your Referral Link : 
                                <p>
                            <code>
                                @foreach(Auth::user()->getReferrals() as $ref) {{ $ref->link }} @endforeach
                            </code>
                                </p>
                            </p>
                            <big>
                            <h3>Total Referrals: 
                                @foreach(Auth::user()->getReferrals() as $ref) 
                                     
                                     {{ $ref->relationships()->count() }}

                                     @endforeach
                                      </h3>
                            </big>
                        </div>
                    </div>
                </div>