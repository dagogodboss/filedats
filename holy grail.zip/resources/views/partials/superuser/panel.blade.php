    
    @role('pioneer')
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                    <div class="card  bg-mix card-dagogo">
                        <div class="content">
                            <b>
                            Total Cash : &#8358;@if( Auth::user()->admin_user()->first() != null) 
                            {{ Auth::user()->admin_user()->first()->amount_to_receive}}
                            @endif
                            </b>
                        </div>
                    </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                    <div class="card  bg-mix card-dagogo">
                        <div class="content">
                            <b>
                            Collected: 
                            @if( Auth::user()->admin_user()->first() != null) 
                            @if(Auth::user()->admin_user()->first()->amount_collected != null)
                                &#8358;{{ Auth::user()->admin_user()->first()->amount_collected}}
                            @else
                                &#8358;0
                            @endif
                            @endif
                            </b>
                        </div>
                    </div>
          
        </div>
        @if(Auth::user()->admin_user()->first() != null)
          @if(Auth::user()->admin_user()->first()->created_at <  Carbon\Carbon::now()->subDays(14))
                <a href="{{ url('add_to_gh/'.Auth::user()->admin_user()->first()->amount_to_receive)}}" class="btn btn-fill btn-success pull-right">Withdraw my Frontier Cash</a>
            @endif
        @endif
    </div>
    @endrole

    @role('admin')

    @endrole
    @include('partials.site_news')
    @include('partials.donation')
    @include('partials.special_box')
    @include('partials.timer')
<div class="clearfix"></div>
<div class="row">
<div class="clearfix"></div>
@if($Donation_To_Pay->isNotEmpty())
                    @forelse($Donation_To_Pay as $Topay)
                        @php

                            $sponsor = \App\User::find($Topay->sponsor_user_id);
                        @endphp
                        
                            <div class="col-md-4 col-sm-12 col-sm-12">
                            <div class="card card-user "  style="color: #fff;">
                                <div class="image">
                                    <img src="{{ asset('img/sidebar-3.jpg') }}" alt="..."/>
                                </div>
                                <div class="content">
                                    <div class="author">
                                         <a href="#">
                                        <img class="avatar" src="{{ asset('images/avatar04.png') }}" alt="..."/>

                                          <h4 style="text-transform: capitalize;" class="title">Account Name: {{ $sponsor->name }}<br />
                                             <small>Phone: {{ $sponsor->phone_number }}</small>
                                          </h4>

                                          <h4 class="title">Bank: {{ $sponsor->bank_name }}<br />
                                             <small>Amount: &#8358;{{ $Topay->amount }}</small><br>
                                            <br>

                                          </h4>

                                        </a>
                                    </div>
                                    <div  data-time="{{ $Topay->created_at->addHours(config('app.timer')) }}" data-uri="{{ url('/TimePay/'.$Topay->id)}}" style="text-align: center;font-weight: bold;font-size: 22px;text-decoration: #799979 overline dashed; color: tomato"></div>
                                    <p class="description text-center"> <h4 class="text-center text-muted">Account Number: "{{ $sponsor->account_number }}"</h4>
                                    </p>
                                    @if($Topay->payment_status == 'yes')
                                            <p class="text-center text-muted"> Your Payment status is noted. Please wait for the other User To Confirm you</p>
                                    @else
                                      <div class="text-center">
                                      <a href="{{url('/upload_pop/'. $Topay->id )}}" class="btn-sm btn-fill btn btn-success"> I Have Provided Help</a>
                             <a href="{{url('/cantPay/'. $Topay->id)}}" class="cant btn-sm btn btn-fill btn-danger">I Can't Provided Help</a>
                                    @endif
                                </div>
                                </div>
                            </div>
                        </div>
                        
                      @empty

                <div class="row">
                     <div class="col-md-4 col-sm-12">
                        <div class="card">
                            <div class="header">
                            <h4 class="title">You Have not Matched Now</h4>

                            <p class="category">Check Back </p>
                            </div>
                            
                            <div class="content">
                                
                            
                            <div class="footer">
                                    <div class="legend">
                                        <i class="fa fa-circle text-info"></i> Open
                                        <i class="fa fa-circle text-danger"></i> Bounce
                                        <i class="fa fa-circle text-warning"></i> Unsubscribe
                                    </div>
                                    <hr>
                                    <div class="stats">
                                        <i class="fa fa-clock-o"></i> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    @endforelse
                  @endif

                  @if($Donation_To_Receive->isNotEmpty())
                      @forelse($Donation_To_Receive as $ToReceive)
                        @php
                            $provider = \App\User::find($ToReceive->provider_user_id);
                        @endphp
                        
                            <div class="col-md-4 col-sm-12 col-sm-12">
                            <div class="card card-user bg-green">
                                <div class="image">
                                    <img src="{{ asset('img/sidebar-2.jpg') }}" alt="..."/>
                                </div>
                                @if($ToReceive->payment_status == 'not-paid')
                                <button class="pull-right btn bg-lime btn-fill extend-time" href="{{url('extend-time/'.$ToReceive->id)}}">Extend Time</button>
                                @endif
                                <div class="content" >
                                    <div class="author">
                                         <a href="#">
                                        <img class="avatar" src="{{ asset('images/avatar04.png') }}" alt="..."/>

                                          <h4 style="text-transform: capitalize;color: #fff;font-weight: bold" class="title">Account Name: {{ $provider->name }}<br />
                                             <small style="color: #eee">Phone: {{ $provider->phone_number }}</small>
                                          </h4>

                                          <h4 class="title" style="color: #fff; font-weight: bold">Bank: {{ $provider->bank_name }}<br />
                                             <small style="color: #eee">Amount: &#8358;{{ $ToReceive->amount }}</small>
                                          </h4>
                                        </a>
                                    </div>
                                    <p class="description text-center"> <h4 class="text-center" style="color: #fff">Account Number: "{{ $provider->account_number }}"</h4>
                                    </p>
                                <div class="text-center">
                                
                                @if($ToReceive->payment_status == 'yes')
                                    <button data-url="{{url('/confirm/'.$ToReceive->id )}}" class="btn-sm btn-fill btn btn-success confirm-help">Confirm
                                    </button>
                                    
                                    <button data-url="{{url('/viewproof/'.$ToReceive->id )}}"  class="btn-sm btn-fill btn btn-info view-help">View Proof </button>

                                    <button data-url="{{url('/flagasfake/'.$ToReceive->id)}}" class="btn-sm btn-fill btn btn-danger pull-right fake-help"> 
                                        Invalid Payment
                                    </button>                            
                                @else
                                    <button class="btn-sm btn-fill btn btn-success confirm-help">Confirm User even as he has Not Click Paid</button>
                                @endif
                                </div>
                                </div>
                            </div>
                        </div>
                        
                      @empty
                      

                <div class="row">
                     <div class="col-md-4 col-sm-12">
                        <div class="card">
                            <div class="header">
                            <h4 class="title"></h4>

                            <p class="category">Check Back </p>
                            </div>
                            
                            <div class="content">
                                
                            
                            <div class="footer">
                                    <div class="legend">
                                        <i class="fa fa-circle text-info"></i> Open
                                        <i class="fa fa-circle text-danger"></i> Bounce
                                        <i class="fa fa-circle text-warning"></i> Unsubscribe
                                    </div>
                                    <hr>
                                    <div class="stats">
                                        <i class="fa fa-clock-o"></i> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                                          
                    @endforelse
                  @endif
</div>