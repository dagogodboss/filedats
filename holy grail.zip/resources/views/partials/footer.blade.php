<footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                   <ul>
                   <li>
                       <p><a href="#">Always Keep It in mind that we got your interest in heart</a></p>
                   </li>
                   </ul> 
                </nav>
                <p class="copyright pull-right">
                    &copy; 2017 <a href="">{{config('app.name', 'Laravel')}} </a>, made with <i style="font-size: 17px; color: burlywood" class="fa fa-like"></i>  for a better web
                </p>
            </div>
        </footer>