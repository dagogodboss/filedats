<div class="sidebar" style="background: #84d52b" data-color="grey">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="{{ url('/') }}" class="simple-text">
                    {{ config('app.name', 'Laravel') }}
                </a>
            </div>

            <ul class="nav">
                <li class="inactive">
                    <a href="{{ url('/home') }}">
                        <img style="width: 80%; border-radius: 10%;" src="{{ url('/images/avp.png')}}">
                    </a>
                </li>
                <li class="">
                    <a href="{{ url('/home') }}">
                        <i class="pe-7s-graph"></i>
                        <p> {{ Auth::user()->name }} </p>
                    </a>
                </li>
                <li>
                    <a href="{{ url('/userProfile') }}">
                        <i class="pe-7s-user"></i>
                        <p>User Profile</p>
                    </a>
                </li>
                <li>
                    <a href="{{ url('/history') }}">
                        <i class="pe-7s-pin"></i>
                        <p>
                        Transaction History
                        </p>
                    </a>
                </li>
                <li>
                    <a href="{{ url(config('app.name').'_account') }}">
                        <i class="pe-7s-cash"></i>
                        <p>{{ config('app.name')}} Wallet</p>
                    </a>
                </li>
                @role('admin')
                <li>
                    <a href="{{ url('/admin')}}">
                        <i class="pe-7s-magic-wand"></i>
                        <p>Administrator</p>
                    </a>
                </li>
                @endrole

                <li>
                    <a href="{{ url('/support') }}">
                        <i class="pe-7s-bell"></i>
                        <p>Support</p>
                    </a>
                </li>
            </ul>
        </div>
          </div>