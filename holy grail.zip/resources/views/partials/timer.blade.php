@if(Auth::user()->gh_timer != null)
<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 ">

                    <div class="card same-height">
                    <div class="header bg-grey text-center"><h5>You will be able to Reap After:</h5></div>
                        <div class="content">
                        	@if(Auth::user()->gh_timer != null)
                            <div  id="recomit-clock" data-uri="{{ url('/off-timer')}}" 
                            data-time="@if(Auth::user()->gh_timer != null){{Auth::user()->gh_timer}}@endif" 
                            style="padding-top:10px;text-align: center;font-size: x-large;color: tomato;text-transform: full-width;">
                            </div>
                            @else
                            	<div style="text-align: center;font-size: large;color: tomato;">
	                            	Your Count down timer to receive your cash has elapsed.
                            	</div>
                            @endif
                        </div>
                    </div>
</div>
<div class="clearfix"></div>
@endif