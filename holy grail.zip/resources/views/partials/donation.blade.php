<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 ">
                    <div class="card same-height" style="background-color: #951EE9 !important;">
                        <div class="donation-form-box header"> 
                        @if(Auth::user()->account_state == 'intro')
                        	<a class=" col-xs-12 col-sm-12 col-md-12 btn btn-danger btn-fill ready" href="{{ url('ready') }}">
                                I am Ready To Sow
                            </a>
                        @else
                        	@if(Auth::user()->provide_help()->get()->count() >= 2 )
                        	<a href="#" class=" col-xs-12 col-sm-12 col-md-12  btn btn-success btn-fill">Sorry You can't Sow Anymore</a>
                        	@else
                        	<a href="#" class=" col-xs-12 col-sm-12 col-md-12  btn btn-success btn-fill donation-form-link">I Want To Sow</a>
                        	@endif	
                        @endif
                        </div>
                        <div class="body" style="color: #fff;">                        
                        	<form class="form-donation hide" action="{{url('add_ph')}}" method="post">
                        			{{csrf_field()}}
                        		<div class="input-group">
                                        <div class="form-line">
                                            <input name="amount" class="form-control" placeholder="Enter Your Desire Amount" style="outline: none !important;border: none;background: inherit;color: #fff;" type="text">
                                        </div>
                                    </div>
                                    <div class="input-group">
                                    	<button class="btn btn-fill bg-green">Submit </button>
                                    </div>
                        	</form>
                        	<p class="donation-info">
                                    Please understand that we Believe that you have read the "How it Works". 
                                    Amount Donated can only be in thousands and a multiple of &#8358;2,000 with a minimum amount of &#8358;6,000
                              </p>
                        </div>
                    </div>
                </div>