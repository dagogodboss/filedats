@extends('layouts.user')

@section('content')
		
		 <div class="main-panel">
         @include('./partials/topnav')

    		<div  class="content">
        		<div class="container-fluid">
        		<div class="row">
        		 <div class="card card-user">
                            <div class="">
                                <img src="{{ asset($data)}}" alt="..."/>
                            </div>
                            </div>
        		</div>
        		</div>
        		</div>
        		</div>

		
@endsection
