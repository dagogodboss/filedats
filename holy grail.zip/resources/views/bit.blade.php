@extends('layouts.user')

@section('content')
	
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
	<script type="text/javascript" src="https://blockchain.info/Resources/js/pay-now-button.js"></script>
	    <div class="main-panel">
         @include('./partials/topnav')

    <div  class="content">
        <div class="container-fluid">
                <div class="row">
                



	<div style="font-size:16px;margin:0 auto;width:300px" class="blockchain-btn"
     data-address="13E36aV2VyE1Hs6Hs7n62VxuCWaoqVMrtJ"
     data-shared="false">
    <div class="blockchain stage-begin">
        <img src="https://blockchain.info/Resources/buttons/donate_64.png"/>
    </div>
    <div class="blockchain stage-loading" style="text-align:center">
        <img src="https://blockchain.info/Resources/loading-large.gif"/>
    </div>
    <div class="blockchain stage-ready">
         <p align="center">Please Donate To Bitcoin Address: <b>[[address]]</b></p>
         <p align="center" class="qr-code"></p>
    </div>
    <div class="blockchain stage-paid">
         Donation of <b>[[value]] BTC</b> Received. Thank You.
    </div>
    <div class="blockchain stage-error">
        <font color="red">[[error]]</font>
    </div>
</div>
</div>
</div>
</div>
</div>
@endsection