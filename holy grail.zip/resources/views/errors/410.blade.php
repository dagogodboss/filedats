@extends('layouts.verify')
@section('content')
        <div class="logo">
            <a href="javascript:void(0);"><b>{{ config('app.name',' Laravel')}}</b></a>
            <small>Account Verification</small>
        </div>
        <div class="card">
            <div class="body">
                <form id="forgot_password" method="POST" action="{{ url('/verify_account')}}">
                    {{ csrf_field() }}
                    <div class="msg">

                        Enter the Short code sent to Your Moblie Number. <code class="bg-blue">{{ Auth::user()->phone_number }}</code>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">code</i>
                        </span>
                        <div class="form-line">
                            <input type="text" class="form-control" name="phone_token" placeholder="Verification Code" required autofocus maxlength="6">
                        </div>
                    </div>

                    <button class="btn btn-block btn-lg bg-pink waves-effect" type="submit">Verify My Account</button>

                    <div class="row m-t-20 m-b--5 align-center">
                        <a href="{{ url('send_code') }}" class="btn bg-blue waves-effect send-code">Request For Another Code. <i class="material-icons">refresh</i></a>
                    </div>
                </form>
            </div>
        </div>
@endsection
