@extends('layouts.user')

@section('content')

    <div class="main-panel">
         @include('./partials/topnav')

        <div  class="content">
        
        <div class="container-fluid">
                <div class="row">

                <div class="col-md-4 col-sm-12">
                        <div class="card">
                            <div class="header">
                            <h4 class="text-center text-muted plan title">{{Auth::user()->name}}</h4>

                            <p class="category"><big>You have completed a cycle and you are now ready to recycle. You can Continue with the same amount or you can change it by clicking the button below that describe your option</big></p>
                            </div>
                            
                            <div class="content text-center">
                               
                               <h3 class="text-info">Amount: NGN {{Auth::user()->plan}}</h3>
                            
                            <div class="footer">
                                        <a href="{{ url('recycle')}}" data-text="You have chosen to Re-cycle your Plan which is {{ Auth::user()->plan }} naira, you will be matched after two days. " class="add-plan btn btn-default btn-fill pull-left">Recycle</a>
                                        <a href="{{ url('resets') }}" data-text="Please Note that, a modification of your plan will incure a re-comittment charge which is 50% of the plan you will select." class="pull-right add-plan btn btn-warning btn-fill">Change Plan</a>
                                    <div class="stats">
                                        <i class="fa fa-clock-o"></i> Always call your sponsor once paired.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
        </div>

        </div>
    </div>
@endsection