@extends('layouts.app')

@section('content')
			<div class="container">
				
					<div class="row">
						<div class="col-lg-12">
								<div class="centering text-center error-contianer">
									<div class="text-center">
										<h2 class="without-margin"><span class="text-danger">
											<big>Access Denied</big>
										</span></h2>
										<h4 class="text-danger">You do not have permission for this page.</h4>
										<h4 class="text-danger">403 Error</h4>
									</div>
									<div class="text-center">
									<h3>
									<small>Choose an option from below</small>
									</h3>
									</div>
									<hr>
									<ul class="pager">
										<li><a href="{{url('/home')}}"><- Go Back</a></li>
										<li><a href="{{url('/')}}"><- Home Page</a></li>
									</ul>
								</div>
						</div>
					</div>

			</div>
@endsection