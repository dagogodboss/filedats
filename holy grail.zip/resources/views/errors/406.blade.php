@extends('layouts.app')

@section('content')
			<div class="container">
				
					<div class="row">
						<div class="col-lg-12">
								<div class="centering text-center error-contianer">
									<div class="text-center">
										<h2 class="without-margin"><span class="text-danger">
											<big>Blocked Account</big>
										</span></h2>
										<h4 class="text-danger">Your account has been Blocked and you can no longer user this account.</h4>
										<h4 class="text-danger">406 Error</h4>
									</div>
									<div class="text-center">
									<h3>
									<small>You can Contact Admin on the Telegram Group</small>
									</h3>
									</div>
									<hr>
									<ul class="pager">
										<!-- <li><a href="{{url('/home')}}"><- Go Back</a></li>
										<li><a href="{{url('/')}}"><- Home Page</a></li> -->
									</ul>
								</div>
						</div>
					</div>

			</div>
@endsection