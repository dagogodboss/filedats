@extends('layouts.auth')

@section('content')
    <style type="text/css">
         .select-bank {
            z-index: 10000;
        }
    </style>
<div class="logo">
            <a href="javascript:void(0);">{{config('app.name', 'Laravel') }}</b></a>
            <small>Registration For New Members</small>
        </div>        
        <div class="card">
            <div class="body">
                <form id="sign_up" class="form-horizontal" role="form" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}
                    <div class="msg">Please Fill The Form</div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">person</i>
                        </span>
                        <div class="form-line{{ $errors->has('name') ? ' has-error' : '' }}">
                        
                            <input id="name" type="text" placeholder="Your Account Name Valid Account Name" class="form-control" name="name" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                        </div>
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">attach_money</i>
                        </span>
                        <div class="form-line{{ $errors->has('account_number') ? ' has-error' : '' }}">
                            <input id="account_number" placeholder="Your Account Number" type="digits" maxlength="10" minlength="10" class="form-control" name="account_number" value="{{ old('account_number') }}" required>

                                @if ($errors->has('account_number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('account_number') }}</strong>
                                    </span>
                                @endif
                        </div>
                    </div>


                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">account_balance</i>
                        </span>
                        <div class="select-bank form-line{{ $errors->has('bank_name') ? ' has-error' : '' }}">
                            <select value="{{ old('bank_name') }}"  name="bank_name" class="form-control show-tick" data-show-subtext="true" required>
                                        <option value="" data-subtext=""></option>
                                        <option value="Access Bank" data-subtext="Access Bank">Access Bank</option>
                                        <option value="First Bank" data-subtext="First bank of NIgeria">First Bank</option>
                                        <option  value="First City Monument Bank Bank" data-subtext="FCMB">First City Monument Bank Bank</option>
                                        <option value="Fidelity Bank" data-subtext="We keep our Word">Fidelity Bank</option>
                                        <option value="Ecobank" data-subtext="The Pan African Bank">Ecobank</option>
                                        <option value="Enterprise Bank" data-subtext="Enterprise">Enterprise Bank</option>
                                        <option value="Diamond Bank" data-subtext="DB">Diamond Bank</option>
                                        <option value="Guaranty Trust Bank" data-subtext="GTBank">Guaranty Trust Bank</option>
                                        <option value="Heritage Bank" data-subtext="Heritage">Heritage Bank</option>
                                        <option value="Citi Bank" data-subtext="is this your Bank?">Citi Bank</option>
                                        <option value="Skye Bank" data-subtext="">Skye Bank</option>
                                        <option value="MainStreet Bank" data-subtext="">MainStreet Bank</option>
                                        <option value="keyStone Bank" data-subtext="">keyStone Bank</option>
                                        <option value="Stanbic IBTC Bank" data-subtext="">Stanbic IBTC Bank</option>
                                        <option value="Standard Chartered Bank" data-subtext="">Standard Chartered Bank</option>
                                        <option value="Sterling Bank" data-subtext="One Customer Bank">Sterling Bank</option>
                                        <option value="Sun Bank" data-subtext="">Sun Bank</option>
                                        <option value="Union Bank" data-subtext="">Union Bank</option>
                                        <option value="Unity Bank" data-subtext="">Unity Bank</option>
                                        <option value="United Bank Of Africa" data-subtext="UBA">United Bank Of Africa</option>
                                        <option value="Wema Bank" data-subtext="">Wema Bank</option>
                                        <option value="Zenith Bank" data-subtext="">Zenith Bank</option>
                                    </select>          

                                @if ($errors->has('bank_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('bank_name') }}</strong>
                                    </span>
                                @endif
                        </div>
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">local_phone</i>
                        </span>
                        <div class="form-line{{ $errors->has('phone_number') ? ' has-error' : '' }}">
                            <input id="phone_number" placeholder="Your Phone Number" type="digits" maxlength="11" minlength="11" class="form-control" name="phone_number" value="{{ old('phone_number') }}" required>

                                @if ($errors->has('phone_number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('phone_number') }}</strong>
                                    </span>
                                @endif
                        </div>
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                        <div class="form-line{{ $errors->has('password') ? ' has-error' : '' }}">
                            <input placeholder="Your Desired Password" id="password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                        </div>
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                        <div class="form-line">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" minlength="6" placeholder="Confirm Password" required>
                        </div>
                    </div>
                    <div class="input-group">
                        <input type="checkbox" name="terms" id="terms" class="filled-in chk-col-pink">
                        <label for="terms">I read and agree to the <a href="javascript:void(0);">terms of usage</a>.</label>
                    </div>
                        </p>
                    <button class="btn btn-block btn-lg bg-green waves-effect" type="submit">SIGN UP</button>
                        </p>

                    <div class="m-t-25 m-b--5 align-center">
                        <a href="{{ route('login') }}">You already have a membership?</a>
                    </div>
                </form>
            </div>
        </div>

@endsection
