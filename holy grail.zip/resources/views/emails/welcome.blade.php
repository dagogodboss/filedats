<div style="background: #eee; width: 75%;margin:0px auto;padding: 15px; border:1px #ccc solid;">


<h3 style="color: #fff;border-bottom:1px gray solid;width: 102%;background: #596398;padding: 10px;margin: -16px 16px 30px -16px;position: relative;">
Hi, {{ $firstname }}!
</h3>
 
<p style="line-height: 1.9em;color:gray;font-size: 1.4em;text-align: justify;">
We'd like to personally welcome you to the {{ config('app.name','Laravel') }} and your registration was successful
</p>

<p style="line-height: 1.9em; color:gray;"> Please feel free to contact us anytime</p>

<hr>
Thanks, {{ config('app.name') }} Team<br>
<footer style="margin:35px 16px 30px -16px;color: white;margin-top:31px;text-align:center;background: #596398;padding: 10px;font-size: large;">Copy Right &copy; {{ config('app.name') }}</footer>

</div>