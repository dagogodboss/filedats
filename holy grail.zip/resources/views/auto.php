@extends('layouts.user')

@section('content')
	
	<div class="main-panel">
         @include('partials/topnav')

        <div  class="content">

       <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Edit Profile</h4>
                            </div>
                            <div class="content">
                                <form action="{{ url('/userProfile') }}" method="post" role="form">
                                 {{ csrf_field() }}
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Email Address (disabled)</label>
                                                <input type="text" name="email" class="form-control" disabled placeholder="Company" value="{{ Auth::user()->email }}">
                                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Phone Number</label>
                                                <input type="text" name="phone_number" disabled="true" class="form-control" placeholder="Username" value="{{ Auth::user()->phone_number }}">
                                                @if ($errors->has('phone_number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('phone_number') }}</strong>
                                    </span>
                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Full Name</label>
                                                <input name="name" disabled="true" type="text" class="form-control" placeholder="" value="{{ Auth::user()->name }}">
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Bank Name</label>
                                                <input name="name"  type="text" class="form-control" placeholder="Your Bank Name" value="{{ Auth::user()->bank_name }}">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Account Name</label>
                                                <input name="name" type="text" class="form-control" placeholder="Home Address"
                                                 value="{{ Auth::user()->name }}">
                                                  @if ($errors->has('name'))
                                    			<span class="help-block">
                                        		<strong>{{ $errors->first('name') }}</strong>
                                    			</span>
                               					 @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Account Number</label>
                                                <input name="account_number"  type="text" class="form-control" placeholder="Home Address" 
                                                value="{{ Auth::user()->account_number }}">
                                                 @if ($errors->has('account_number'))
                                    			<span class="help-block">
                                        		<strong>{{ $errors->first('account_number') }}</strong>
                                   				</span>
                                				@endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input name="city" type="text" class="form-control" placeholder="City" value="{{ Auth::user()->city }}">
                                                 @if ($errors->has('city'))
                                    			<span class="help-block">
                                        		<strong>{{ $errors->first('city') }}</strong>
                                    			</span>
                                				@endif
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <input type="text" name="country" class="form-control" placeholder="Is Nigeria then Say It" value="{{ Auth::user()->country }}">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>About Me</label>
                                                <textarea name="about_name" rows="5" class="form-control" placeholder="Here can be your description" value="Mike">{{ Auth::user()->about_name }}</textarea>
                                                @if ($errors->has('city'))
                                    			<span class="help-block">
                                        		<strong>{{ $errors->first('city') }}</strong>
                                    			</span>
                                				@endif
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Profile</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                                <img src="{{ asset('img/background.jpg') }}" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                     <a href="#">
                                    <img class="avatar border-gray" src="{{ asset('img/faces/face.png') }}" alt="..."/>

                                      <h4 class="title">{{ Auth::user()->name }}<br />
                                         <small>{{ Auth::user()->email }}</small>
                                      </h4>
                                    </a>
                                </div>
                                <p class="description text-center"> "{{ Auth::user()->about_name }}"
                                </p>
                            </div>
                            <hr>
                            <div class="text-center">
                                <button href="#" class="btn btn-simple"><i class="fa fa-facebook-square"></i></button>
                                <button href="#" class="btn btn-simple"><i class="fa fa-twitter"></i></button>
                                <button href="#" class="btn btn-simple"><i class="fa fa-google-plus-square"></i></button>

                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>
        </div>

@endsection