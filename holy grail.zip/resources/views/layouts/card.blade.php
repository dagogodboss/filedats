<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>{{config('app.name')}} Credit Card Checkout</title>
  
	<link rel="icon" type="image/png" href="{{ asset('assets/img/') }}">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
  <script src="https://use.typekit.net/xft2oih.js"></script>
  <script>try{Typekit.load({ async: true });}catch(e){}</script>
  
  <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" />

  <link rel="stylesheet" href="{{asset('assets/normalize.min.css')}}">


  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Inconsolata'>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">

  
</head>

<body>
        @yield('content')


    <script src="{{ asset('assets/js/jquery-1.10.2.js') }}" type="text/javascript"></script>

    <script src="{{asset('assets/js/index.js')}}"></script>

</body>
</html>
