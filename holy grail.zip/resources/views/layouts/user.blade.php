<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
    <link rel="icon" type="image/png" href="{{ asset('images/QuickLinkers.png') }}">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title> {{ config('app.name', 'Laravel') }}</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    
    <link href="{{ asset('css/style_2.css') }}" rel="stylesheet" />
    <!-- Bootstrap core CSS     -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="{{ asset('assets/css/animate.min.css') }}" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="{{ asset('assets/css/light-bootstrap-dashboard.css') }}" rel="stylesheet"/>
    <!-- Waves Effect Css -->
    <link href="{{ asset('plugins/node-waves/waves.css') }}" rel="stylesheet" />
    
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="{{ asset('assets/css/demo.css') }}" rel="stylesheet" />
    



    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>

    <link href="{{ asset('assets/css/pe-icon-7-stroke.css') }}" rel="stylesheet" />

    <link href="{{ asset('css/font-awesome.css') }}" rel="stylesheet" />

    <link href="{{ asset('assets/css/alertify.min.css') }}" rel="stylesheet"/>

    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/css/sweetalert.css">
    
    <script src="{{ asset('assets/js/jquery-1.10.2.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/js/bootstrap.min.js') }}" type="text/javascript"></script>

    <script src="{{ url('/') }}/js/sweetalert.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="{{ asset('assets/js/alertify.min.js') }}"></script>

</head>
<body style="background: #eee;">

<div class="wrapper">
     @include('./partials/sidebar')
        @yield('content')
        @include('./partials/how-it-works')
</div>



    <!--   Core JS Files   -->
    
    <script src="{{ asset('js/user.js') }}"></script>
    <!--  Checkbox, Radio & Switch Plugins -->
    <script src="{{ asset('assets/js/bootstrap-checkbox-radio-switch.js') }}"></script>
    <!-- Waves Effect Plugin Js -->
    <script src="{{ asset('plugins/node-waves/waves.js') }}"></script>
    <!--  Charts Plugin -->
    <script src="{{ asset('assets/js/chartist.min.js') }}"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
    <script src="{{ asset('assets/js/light-bootstrap-dashboard.js') }}"></script>

    <!-- Light Bootstrap Table Core DataTable -->
    <script src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/js/dataTables.responsive.min.js') }}"></script>
    
    <!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
    <script src="{{ asset('assets/js/demo.js') }}"></script>

    <script type="text/javascript">   
        $(document).ready(function(){
        $('#adminListTable').DataTable();
        });
    </script> 

    @if(session('success'))
    <script type="text/javascript"> 
        $(document).ready(function(){
            alertify.set('notifier','position', 'top-right');
            alertify.success('{{session('success')}}', 10);
        });

    </script>
    @endif

    @if(session('error'))
    <script type="text/javascript"> 
        $(document).ready(function(){
            alertify.set('notifier','position', 'bottom-right');
            alertify.error('{{session('error')}}', 10);
        });

    </script>
    @endif

    @if(Auth::user()->provide_help()->first() != null)
    <script type="text/javascript">
        var deadline = "{{ Auth::user()->provide_help()->first()->created_at->addDays(config('app.return_count'))}}";
        initializeClock('clockdiv', deadline);
    </script>
    @endif 


        
</body>
</html>
