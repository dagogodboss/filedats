<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
     <title>{{ config('app.name', 'Laravel') }}</title>
    <!-- Favicon-->
    <link rel="icon" type="image/png" href="{{ asset('images/QuickLinkers.png') }}">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
    
    <link href="{{ asset('assets/css/alertify.min.css') }}" rel="stylesheet"/>

    <link href="{{ asset('css/font/material-icons.css') }}" rel="stylesheet" type="text/css">


    <!-- Bootstrap Core Css -->
    <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="{{ asset('plugins/node-waves/waves.css') }}" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="{{ asset('css/animate.min.css') }}" rel="stylesheet" />

     <!-- Multi Select Css -->
    <link href="../../plugins/multi-select/css/multi-select.css" rel="stylesheet">


    
    <link href="{{ asset('plugins/bootstrap-select/css/bootstrap-select.css') }}" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/css/sweetalert.css">
    
    
    <script>
        window.Laravel = {!! json_encode([
            'csrfToken' => csrf_token(),
        ]) !!};
    </script>
    <!-- Custom Css -->
    <link href="{{ asset('css/style_2.css') }}" rel="stylesheet">
    <style type="text/css">
        .overlay-bg{
            position: fixed;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 54, 123, 0.5);
            display: block;
        }
    </style>

</head>

<body style="background: url('images/img7.jpg'); background-size: cover; " class="theme-orange fp-page">
<div class="overlay-bg"></div>
        <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-deep-orange">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Verification Process...</p>
        </div>
    </div>
<div class="fp-box">

     @yield('content')

</div>
    <!-- Jquery Core Js -->
    <script src="{{ asset('js/jquery-2.2.3.min.js') }}"></script>

    <!-- Bootstrap Core Js -->
    <script src="{{ asset('js/bootstrap.js') }}"></script>
    <script src="{{ asset('plugins/bootstrap-select/js/bootstrap-select.js') }}"></script>
    <script src="{{ asset('plugins/multi-select/js/jquery.multi-select.js') }}"></script>
    <!-- Waves Effect Plugin Js -->
    <script src="{{ asset('plugins/node-waves/waves.js') }}"></script>

    <!-- Validation Plugin Js -->
    <script src="{{ asset('plugins/jquery-validation/jquery.validate.js') }}"></script>
    
    <script src="{{ url('/') }}/js/sweetalert.min.js"></script>
    <script src="{{ asset('assets/js/alertify.min.js') }}"></script>

    <!-- Custom Js -->
    <script src="{{ asset('js/admin.js') }}"></script>
    <script src="{{ asset('js/pages/examples/sign-up.js') }}"></script>
    <script src="{{ asset('js/pages/examples/sign-in.js') }}"></script>
    <script src="{{ asset('js/pages/forms/advanced-form-elements.js') }}"></script>

    <script type="text/javascript">
        $('form#forgot_password').submit(function(e){
            e.preventDefault();
            var form = $(this);
            form.fadeOut('slow');
            $.ajax({
                url     : form.attr('action'),
                type    : form.attr('method'),
                data    : form.serialize(),
                success : function(response){
                    swal({
                        title : 'Verification Done',
                        text  : response.success,
                        type  : 'success'
                    },function(){
                        window.location = 'home';
                    });
                },
                error   : function(error){
                    form.fadeIn('slow');
                    var obj = jQuery.parseJSON(error.responseText);
                    if (error.status === 422) {
                        swal({
                            title : 'Invalid Code',
                            text  : obj.phone_token,
                            type  : 'error'
                        });    
                    }

                    else if(error.status  === 406){
                            window.location = 'home';
                    }
                    else{
                        swal({
                            title : 'Invalid Code',
                            text  : obj.error,
                            type  : 'error'
                        });    
                    }
                    
                    $.ajax({
                        url     : '{{ url('/count-verify') }}',
                        type    : 'get',
                        success : function(num){
                            if (num == 3) {
                                alertify.notify("Bad News!! You have exceeded the number of trial you have. and your account has been Blocked :)", 'error', 10, function(){
                                    window.location = 'home';
                                });
                            }
                            else{
                                var remain = 3 - num;
                                alertify.notify("You have "+remain+" remaining Trial ", 'error', 10);
                            }
                        }
                    });
                }
            });

        });

        $('a.send-code').click(function(e){
            e.preventDefault();
            url = $(this).attr('href');
            $(this).fadeOut('slow');
            $.ajax({
                url : url,
                type : 'get',
                success  : function(e){
                    $('a.send-code').fadeIn('slow');
                    if (e.success) {
                        alertify.notify(e.success, 'success', 10);
                    }
                    if(e.error){
                        alertify.notify('We are so sorry about this please contact the admin for further assistance.', 'error', 10);
                    }
                }
            });

        });
    </script>

</body>

</html>
    