<!DOCTYPE html>
	<html lang="{{ config('app.locale') }}">
		<head>

			<title>{{ config('app.name', 'Laravel') }}</title>

			<meta name="viewport" content="width=device-width, initial-scale=1">

			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

			<meta name="csrf-token" content="{{ csrf_token() }}">

			<link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">


	<script type="application/x-javascript">
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); }
	</script>

	<!-- Custom Theme files -->

	<!-- Scripts -->
    <script>
        window.Laravel = {!! json_encode([
            'csrfToken' => csrf_token(),
        ]) !!};
    </script>

		<link href="{{ asset('css/bootstrap.css') }}" type="text/css" rel="stylesheet" media="all">
		<link href="{{ asset('css/style.css') }}" type="text/css" rel="stylesheet" media="all">
		<link href="{{ asset('css/slider.css') }}" type="text/css" rel="stylesheet" media="all">
		<link href="{{ asset('css/simplelightbox.min.css') }}" rel='stylesheet' type='text/css'>
    <link href="{{ asset('assets/css/alertify.min.css') }}" rel="stylesheet"/>
    <link rel="icon" type="image/png" href="{{ asset('images/QuickLinkers.png') }}">
		
		<!-- //Custom Theme files -->
		<!-- font-awesome icons -->
		<link href="{{ asset('css/font-awesome.css') }}" rel="stylesheet">
		<!-- //font-awesome icons -->
		<!-- js -->
		<script src="{{ asset('js/jquery-2.2.3.min.js') }}"></script>
		<!-- //js -->
		<!-- web-fonts -->
		<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
		<link href="//fonts.googleapis.com/css?family=Tinos:400,400i,700,700i" rel="stylesheet">
		<!-- //web-fonts -->
		<!-- start-smooth-scrolling -->
		<script type="text/javascript" src="{{ asset('js/move-top.js') }}"></script>
		<script type="text/javascript" src="{{ asset('js/easing.js') }}"></script>
		<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){
						event.preventDefault();

				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
					});
				});
		</script>

		<style type="text/css">
			.logo {

                font-family: 'Raleway', sans-serif;
                font-weight: 400;

            }
		</style>

<!-- //end-smooth-scrolling -->
</head>
<body style="min-height: 100vh;" id="app">
	<!-- banner -->
	<div class="banner">
		<div class="cd-radial-slider-wrapper">
			<div class="header agileinfo-header"><!-- header -->
				<nav class="navbar navbar-default">
					<div class="container">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<h1><a class="logo" href="index.html"><span>{{ config('app.name', 'Laravel')}}</span></a></h1>
						</div>
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav nav-center">
								<li><a href="" class="w3ls-hover active">Home</a></li>
								<!-- <li><a href="#about" class="btn w3ls-hover scroll">About</a></li>
								<li><a href="#services" class="btn w3ls-hover scroll">Services</a></li>
								<li><a href="#team" class="btn w3ls-hover scroll">Testimony</a></li>
								<li><a href="#gallery" class="btn w3ls-hover scroll">Investment Plan</a></li>
								<li><a href="#contact" class="btn w3ls-hover scroll">Contact</a></li> -->
							</ul>
							<ul class="nav navbar-nav navbar-right">
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-phone" aria-hidden="true"></i></a>
									<ul class="dropdown-menu">
										<li><a href="#"><b>Office :</b>  +234 9038020670</a></li>
									</ul>
								</li>
							</ul>
							<div class="clearfix"> </div>
						</div><!-- //navbar-collapse -->
						<!-- cd-search -->
						<div class="cd-main-header">
							<ul class="cd-header-buttons">
								<li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>
							</ul> <!-- cd-header-buttons -->
						</div>
						<div id="cd-search" class="cd-search agileinfo">
							<form action="#" method="post">
								<input name="Search" type="search" placeholder="Search...">
							</form>
						</div>
						<!-- //cd-search -->
					</div><!-- //container-fluid -->
				</nav>
			</div><!-- //header -->



			  @yield('content')













	<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="footer-left">
				<p>© 2017 {{ config('app.name')}}</p>
			</div>
			<div class="footer-right">
				<div class="wthree-icon">
					<a href="#" class="social-button twitter"><i class="fa fa-twitter"></i></a>
					<a href="web.fb.com/quicklinkers" class="social-button facebook"><i class="fa fa-facebook"></i></a>
					<a href="#" class="social-button google"><i class="fa fa-google-plus"></i></a>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //footer -->
	<!-- search jQuery -->
	<script src="{{ asset('js/search.js') }}"></script>

    <script src="{{ asset('assets/js/alertify.min.js') }}"></script>
	<!-- //search jQuery -->
	<script src="{{ asset('js/snap.svg-min.js') }}"></script>
	<script src="{{ asset('js/main.js') }}"></script> <!-- Resource jQuery -->
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
			};
			*/

			$().UItoTop({ easingType: 'easeOutQuart' });

		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="{{ asset('js/bootstrap.js') }}"></script>
    @if(session('success'))
    <script type="text/javascript"> 
        $(document).ready(function(){
            alertify.set('notifier','position', 'top-right');
            alertify.success('{{session('success')}}', 10);
        });

    </script>
    @endif

    @if(session('error'))
    <script type="text/javascript"> 
        $(document).ready(function(){
            alertify.set('notifier','position', 'bottom-right');
            alertify.error('{{session('error')}}', 10);
        });

    </script>
    @endif
</body>
</html>
