@extends('layouts.user')

@section('content')



    <div class="main-panel">
         @include('./partials/topnav')

    <div  class="content">
        <div class="container-fluid">
                <div class="row">
	                <div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
	                	<div class="card">
	                	<div class="content">
	                		<p> Your Referral Link : 
	                		<code>
	                			@foreach(Auth::user()->getReferrals() as $ref) {{ $ref->link }} @endforeach
	                		</code>
	                		</p>
	                	</div>
	                	</div>
	                </div>
                </div>

                <div class="row">
                	                
                	<div class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2">
                		<div class="card">
                			<div class="header grey">
                				<h5 class="text-center">{{ config('app.name') }} Referral Account</h5>
                			</div>
                			<div class="content">
                				 <h5>Total Referral Amount: 
                				 <big class="label label-info white large">&#8358; 
                				 @if(Auth::user()->referral_earnings != null)
                				 		{{ Auth::user()->referral_earnings}}
                				 	@else
                				 		0
                				 @endif
                				 </big>
                				 </h5>
                				 <br>
                				 <h5>Total Users Referred : 
                				 <big class="label label-info white large">
                				 	 @foreach(Auth::user()->getReferrals() as $ref) 
                				 	 
                				 	 {{ $ref->relationships()->count() }}

                				 	 @endforeach
                				 	 	
                				 </big>
                				 </h5>

                				 <div class="progress">
									<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="60"aria-valuemin="0" aria-valuemax="100" style="
									
									@foreach(Auth::user()->getReferrals() as $ref )
										
										@if($ref->relationships()->count() != 0 ) 
											
											width:{{ ceil(($ref->relationships()->count()/config('app.total_referral')) * 100) }}%; 

										@else 
											
											width: 0%; 
									
										@endif
									
									@endforeach
									 ">
									<span>
									@foreach(Auth::user()->getReferrals() as $ref )
										
										@if($ref->relationships()->count() != 0 ) 
											
										{{ ceil(($ref->relationships()->count()/config('app.total_referral')) * 100) }}%
											Referral 
										@else 
											You have Not referred any one 
										@endif
									
									@endforeach
									</span>
									</div>
								 </div>
								 <div class="footer">
                                    @foreach(Auth::user()->getReferrals() as $ref )

        								 @if($ref->relationships()->count() >= 10)
        								 	<a class="btn btn-blue" href="{{ url('add_referal_gh')}}">
        								 		Claim Your Referral Bonus
        								 	</a>

        								 @endif

        								 @if($ref->relationships()->count() < 10 )
        								 	<a class="btn btn-blue get_bonus" href="#">
        								 		Claim Your Referral Bonus
        								 	</a>
        								 @endif
                                 
                                    @endforeach
								 </div>
                			</div>
                		</div>
                	</div>
                </div>
        </div>
    </div>
    <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                   <ul>
                   <li>
                       <p><a href="#">Always Keep It in mind that we got your interest in heart</a></p>
                   </li>
                   </ul> 
                </nav>
                <p class="copyright pull-right">
                    &copy; 2017 <a href="">{{config('app.name', 'Laravel')}} </a>, made with love for a better web
                </p>
            </div>
        </footer>
    </div>


    <script type="text/javascript">
    	$('a.get_bonus').click(function(){

    		swal({
                  title: "Sorry!",
                  text: "You have not Referred up to 10 users or more",
                  type: "error",
                })
    	})

    	$('a.get_recomit').click(function(){

    		swal({
                  title: "Sorry!",
                  text: "You have not Recycled up to 10 times or more",
                  type: "error",
                })
    	})
    </script>
@endsection
