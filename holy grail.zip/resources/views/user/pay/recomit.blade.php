@extends('layouts.user')

@section('content')

    <div class="main-panel">
         @include('./partials/topnav')

        <div  class="content">
        
        <div class="container-fluid">
                <div class="row">
                @include('partials.site_news')
                @if(isset($sponsor))
                	<div class="col-md-4 col-xs-12 col-sm-12">
                        <div class="card">
                            <div class="header" style="color:#fff;background:grey; padding: 17px;">
                            <h4 class="text-center text-white plan title" style="color:#fff;">Re-Commitment Payment

                            <p class="category pull-right"><small style="color: #fff;"><em>Approved By {{ config('app.name')}} <i class="pe-7s-like2"></i></em></small></p>
                            </h4>
                            </div>
                            <div class="content text-center">
                            <hr>
                                <h4 class="title">Account Name <br><small>{{ $sponsor->name}}</small></h4>
                                <h3 class="title">Bank Name <br><small>{{ $sponsor->bank_name}}</small></h3>
                                <h5 class="title">Amount <br><small>&#8358;{{ $amount}}</small></h5>
                                <h5 class="title">Phone Number <br><small>{{ $sponsor->phone_number}}</small></h5>
                                <h3 class="title">Account Number<br><small>{{ $sponsor->account_number}}</small></h3>
                            <hr>
                            <div class="footer">
                                    <div class="legend">
                                        @if($matched_details->payment_status == 'yes')
                                            <p class="text-center text-muted"> Your Payment status is noted. Please wait for the other User To Confirm you</p>
                                        @else
                                        <a href="{{ url('send_note/'.hash('sha256',$matched_details->id. config('app.url_salt')))}}" class="read-msg btn btn-success btn-fill pull-left pay">
                                            Made Payment
                                        </a>&nbsp;&nbsp;

                                        <a href="{{ url('cant_recomit/'.hash('sha256',$matched_details->id. config('app.url_salt')))}}" style="margin-left: 5px;" class="read-msg btn btn-danger btn-fill pull-right cant">
                                          I can't Pay</a>&nbsp;&nbsp;
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    @endif
                    @include('partials.special_box')
                    <div class="clearfix"></div>
                    <div class="col-md-4 col-sm-12">
                    <div class="card">
                        <div class="content">
                            <div  id="recomit-clock" 
                            data-uri="{{ url('cant_recomit/'.hash('sha256',$matched_details->id. config('app.url_salt')))}}"
                            data-time="{{ $matched_details->created_at->addHours(config('app.recomit_timer')) }}" 
                            style="padding-top:10px;text-align: center;font-size: xx-large;color: tomato;text-transform: full-width;">
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
        </div>

        </div>
        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                   <ul>
                   <li>
                       <p><a href="#">Always Keep It in mind that we got your interest in heart</a></p>
                   </li>
                   </ul> 
                </nav>
                <p class="copyright pull-right">
                    &copy; 2017 <a href="">{{config('app.name', 'Laravel')}} </a>, made with love for a better web
                </p>
            </div>
        </footer>
    </div>

    <script type="text/javascript">
        $('a.pay').click(function(e) 
        {
            var url = $(this).attr('href')
            alertify.confirm("Are you sure, you have made the Payment? .",
                  function(){
                    $.ajax({
                        url     :  url,
                        type    : 'get',
                        success : function(res)
                        {
                            alertify.success(res.success);
                            $('div.legend').html('<p class="text-center text-muted"> Your Payment status is noted. Please wait for the other User To Confirm you</p>')
                        }, 
                        error   : function(res)
                        {
                            alertify.error('An error has occurred. Please Refresh Your Browser.')
                        }
                    })
                    
                  },
                  function(){
                    alertify.error('You have canceled the request. Please, read the available option');
            });
            e.preventDefault();
        })

        $('a.cant').click(function(e) 
        {
            var url = $(this).attr('href')
            alertify.confirm("You Can'\t Pay? ","Please Note that. This account will be Blocked. And every Reservation you have made deleted.",
                  function(){
                    $.ajax({
                        url     : url,
                        type    : 'get',
                        success : function(res){
                            alertify.notify(res.success, 'success', 7, function(){
                                window.location = 'home'
                            });
                            $('div.legend').html('<p class="text-center text-muted"> Your Account state has change Please Refresh your Browser to continue</p>')
                        }, 
                        error : function(res){
                            alertify.error('An Error has occurred, Please Refresh Your Browser');
                        }
                    })
                    
                  },
                  function(){
                    alertify.error('You have canceled the request. Please, read the available option');
            });
            e.preventDefault();
        })


        $('a.confirm').click(function(e) 
        {
            var url = $(this).attr('href')
            alertify.confirm("You are Confirming This Payment? ","Please Note that. The System will not be held responsible if the payment was forge.",
                  function(){
                    $.ajax({
                        url     : url,
                        type    : 'get',
                        success : function(res){
                            alertify.success(res.success, function(){
                                window.location = 'home'
                            })
                        }, 
                        error : function(res){
                            alertify.error('An Error has Occured, Please Refresh Your Browser');
                        }
                    })
                    
                  },
                  function(){
                    alertify.error('You have canceled the request. Please, read the available option');
            });
            e.preventDefault();
        })


        $('a.purge').click(function(e) 
        {
            var url = $(this).attr('href')
            alertify.confirm("You are Confirming This Payment? ","Please Note that. The System will not be held responsible if the payment was forge.",
                  function(){
                    $.ajax({
                        url     : url,
                        type    : 'get',
                        success : function(res){
                            alertify.success(res.success);
                        }, 
                        error : function(res){
                            alertify.error('An Error has Occured, Please Refresh Your Browser');
                        }
                    })
                    
                  },
                  function(){
                    alertify.error('You have canceled the request. Please, read the available option');
            });
            e.preventDefault();
        })

        var deadline = $('div.recomit-clock').attr('data-time');
        initializeClock('recomit-clock', deadline);
   
    </script>
@endsection