@extends('layouts.user')

@section('content')

    <div class="main-panel">
         @include('./partials/topnav')

        <div  class="content">
        
        <div class="container-fluid">
                <div class="row">

                <div class="col-md-4 col-sm-12">
                        <div class="card">
                            <div class="header">
                            <h4 class="text-center text-muted plan title">{{$plan->plan_name}}</h4>

                            <p class="category">Once you are <code> Paired</code> You have <label class="label label-danger" style="color: #fff;">30 minutes </label>  to make Payment</p>
                            </div>
                            
                            <div class="content text-center">
                               
                               <h3 class="text-info">Amount: NGN {{$plan->amount}}</h3>
                                <h4 class="text-info">Profit: {{$plan->percent}} %</h4>
                            
                            <div class="footer">
                                    <div class="legend">
                                        <a href="add_Plan/{{$plan->id}}" class="add-plan btn btn-success">I want This</a>
                                    </div>
                                    <hr>
                                    <div class="stats">
                                        <i class="fa fa-clock-o"></i> Always call your sponsor once paired.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
        </div>

        </div>
    </div>
@endsection