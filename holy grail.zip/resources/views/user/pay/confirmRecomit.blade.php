@extends('layouts.user')

@section('content')

    <div class="main-panel">
         @include('./partials/topnav')

        <div  class="content">
        <div class="container-fluid">
                <div class="row">
                
                @if(isset($payer))
                    
                    <div class="col-md-4 col-md-offset-3 col-xs-12 col-sm-12">
                        <div class="card">
                            <div class="header" style="color:#fff;background:grey; padding: 17px;">
                            <h4 class="text-center text-white plan title" style="color:#fff;">Re-Commitment Payment

                            <p class="category pull-right"><small style="color: #fff;"><em>Approved By {{ config('app.name')}} <i class="pe-7s-like2"></i></em></small></p>
                            </h4>
                            </div>
                            <div class="content text-center">
                            <hr>
                                <h4 class="title">Account Name <br><small>{{ $payer->name}}</small></h4>
                                <h3 class="title">Bank Name <br><small>{{ $payer->bank_name}}</small></h3>
                                <h5 class="title">Amount <br><small>{{ $amount}}</small></h5>
                                <h3 class="title">Account Number<br><small>{{ $payer->account_number}}</small></h3>
                            <hr>
                            <div class="footer">
                                    <div class="legend">
                                        <a href="{{ url('confirm_recomit/'.hash('sha256',$matched_details->id. config('app.url_salt')))}}" class="read-msg btn btn-green btn-fill pull-left confirm">
                                            Confirm Payment
                                        </a>&nbsp;&nbsp;

                                        <a href="{{ url('purge_recomit/'.hash('sha256',$matched_details->id. config('app.url_salt')))}}" style="margin-left: 5px;" class="read-msg btn btn-pink btn-fill pull-right purge_recomit">
                                         Purge Payment</a>&nbsp;&nbsp;
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    @endif
                </div>
        </div>

        </div>
        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                   <ul>
                   <li>
                       <p><a href="#">Always Keep It in mind that we got your interest in heart</a></p>
                   </li>
                   </ul> 
                </nav>
                <p class="copyright pull-right">
                    &copy; 2017 <a href="">{{config('app.name', 'Larave')}} </a>, made with love for a better web
                </p>
            </div>
        </footer>
    </div>

    <script type="text/javascript">
       
        $('a.confirm').click(function(e) 
        {
            var url = $(this).attr('href')
            alertify.confirm("You are Confirming This Payment? ","Please Note that. The System will not be held responsible if the payment was forge.",
                  function(){
                    $.ajax({
                        url     : url,
                        type    : 'get',
                        success : function(res){
                             alertify.set('notifier','position', 'top-right');
                              alertify.success(res.success, 3, function(e)
                                {
                                  window.location = '{{ url('/home')}}'
                                });
                        }, 
                        error : function(res){
                            alertify.error('An Error has Occured, Please Refresh Your Browser');
                        }
                    })
                    
                  },
                  function(){
                    alertify.error('You have canceled the request. Please, read the available option');
            });
            e.preventDefault();
        })


        $('a.purge').click(function(e) 
        {
            var url = $(this).attr('href')
            alertify.confirm("You are Confirming This Payment? ","Please Note that. The System will not be held responsible if the payment was forge.",
                  function(){
                    $.ajax({
                        url     : url,
                        type    : 'get',
                        success : function(res){
                            alertify.success(res.success);
                        }, 
                        error : function(res){
                            alertify.error('An Error has Occured, Please Refresh Your Browser');
                        }
                    })
                    
                  },
                  function(){
                    alertify.error('You have canceled the request. Please, read the available option');
            });
            e.preventDefault();
        })
    </script>
@endsection