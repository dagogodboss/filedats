@extends('layouts.user')

@section('content')

	
	<div class="main-panel">
         @include('./partials/topnav')

        <div  class="content">
        
        <div class="container-fluid">
                <div class="row">
                    @if(Auth::user()->waitingtimer()->first()!= null && Auth::user()->waitingtimer()->first()->created_at < Carbon\Carbon::now()->subDays(14))
                        <div class="col-md-12" style="margin:10px;">
                            <a href="{{ url('/active_gh') }}" class="btn btn-fill btn-lg bg-green reap">I want To Reap </a>
                        </div>
                    @else
                        <div class="col-md-12" style="margin:10px;">
                            <button disabled="disabled" href="#" class="btn btn-disabled btn-fill btn-lg bg-green fake-reap">I want To Reap </button>
                        </div>
                    @endif
                    @include('partials.site_news')
                    @include('partials.donation')
                    @include('partials.special_box')
                    @include('partials.timer')

                	<div class="col-md-12 col-lg-12 col-sm-12">
                        <div class="card">
                            <div class="header" style="color:#fff;background:grey; padding: 17px;">
                                <h3 class="title text-center white">You will be matched after</h3>
                            </div>
                            <div class="content">
                            <div style="padding-top: 10px;" id="clockdiv">
                              <div>
                                <span class="days"></span>
                                <div class="smalltext">Days</div>
                              </div>
                              <div>
                                <span class="hours"></span>
                                <div class="smalltext">Hours</div>
                              </div>
                              <div>
                                <span class="minutes"></span>
                                <div class="smalltext">Minutes</div>
                              </div>
                              <div>
                                <span class="seconds"></span>
                                <div class="smalltext">Seconds</div>
                              </div>
                            </div>
                                <div class="footer">
                                    <hr>
                                    <div class="stats">
                                        <i class="fa fa-history"></i> Updated {{ \Carbon\Carbon::now() }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-10 col-sm-12 col-xs-12 col-md-offset-1">
                        <div class="card">
                            <div class="content">
                                <p class="text-muted">
                                    While waiting do you know you can still earn Cash in your <a href="{{ url(config('app.name').'_account') }}"><big class="text-info">{{config('app.name')}} Verified Account</big></a>. And withdraw it when it is ready. All you have to do is to Reefer others using your Link. 
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

        </div>
       	</div>
    	<footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                   <ul>
                   <li>
                       <p><a href="#">Always Keep It in mind that we got your interest in heart</a></p>
                   </li>
                   </ul> 
                </nav>
                <p class="copyright pull-right">
                    &copy; 2017 <a href="">{{config('app.name', 'Larave')}} </a>, made with love for a better web
                </p>
            </div>
        </footer>
    </div>

@endsection