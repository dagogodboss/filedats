@extends('layouts.user')

@section('content')
	
	<style type="text/css">
		.dropzone{
			width: 300px;
			height: 300px;
			border:2px dashed darkblue;
			color: #ccc;
			background: #fff;
			line-height: 300px;
			text-align: center;
		}
		.dropzone.dragover{
			border-color:olive;
			color: #000;
			font-size: 18px;
		}
		.dropzone.drop{
			border-color: green;
		}
		.form-upload{
			width: 100%;
		}

	</style>


	<div class="main-panel">
         @include('./partials/topnav')


          		<div  class="content">
                
        			<div class="container-fluid">
        				
        				<div class="row">
        					
        					<div class="col-md-8 col-sm-12 col-md-offset-1">
						        <div class="card ">
						            <div class="header">
						                <h4 class="title">Upload Image Of Your POP</h4>
						                <p class="category">Please Don't Upload Fake POP Else you will be Barned</p>
						            </div>
						            <div class="content">

			                        <form action="{{ url('/upload_pop') }}" method="post" class="upload-form" enctype="multipart/form-data">
			                          <div class="modal-body">
			                          <p>
			                            {{ csrf_field() }}
			                            <button  type="button" class="btn btn-info btn-fill btn-block">Select Image <i style="font-size: 32px;" class="pe-7s-id"></i></button>
			                            <input type="file" name="proof_of_payment" class="upload-button" style="cursor: pointer; width: 100%;height: 51px;position: relative;top: -53px;opacity: 0;" required="required">
			                            <span class="error has-error" style="color: red;"></span>
			                            <input type="hidden" value="{{$owner_data->provider_user_id}}" name="provider_user_id">
			                            <input type="hidden" value="{{$owner_data->sponsor_user_id}}" name="sponsor_user_id">
			                            <input type="hidden" value="{{$owner_data->amount}}" name="amount">
			                            
			                          </p>
			                        </div>
			                        <div class="footer">
			                          <a href="{{ url('send_note/'.hash('sha256',$owner_data->id.config('app.url_salt')))}}" class="read-msg btn btn-info btn-fill pull-right pay">
                                            Continue Without Proof
                                        </a>&nbsp;&nbsp;
			                          <button type="submit" class="btn-fill btn btn-success upload-btn">UPLOAD YOUR PROOF</button>
			                          </form>
						   			</div>
						        </div>
                    </div>

        				</div>


        			</div>
          		</div>
        </div>

        <script type="text/javascript">
            $('form.upload-form').submit(function(e){
                        $.ajax({
                          url: $(this).attr('action'),
                          type: $(this).attr('method'),
                          data:  new FormData(this),
                          contentType: false,
                          cache: false,
                          processData:false,
                          success: function(response)
                          {
                            if(response.success)
                            { 
                              alertify.set('notifier','position', 'top-right');
                              alertify.success(response.success, 3, function(e)
                                {
                                  window.location = '{{ url('/home')}}'
                                }); 
                            }
                            
                          },
                        error       : function(res)
                        {
                            var obj = jQuery.parseJSON(res.responseText);
                              alertify.set('notifier','position', 'bottom-right');
                              alertify.error('An error has Occured.', 10);
                            
                            if(obj.error)
                            {
                                $(".error").addClass("has-error");
                                $('.error').html(obj.error);
                            }
                        
                        } 
                        }) 
                    	swal({
                          title: "Thank You",
                          text: "Please wait while i submit your request.",
                          type: "success",
                        })
                   	$(".error").removeClass("has-error");
                    $('.error').html('');
                    
                    e.preventDefault()
                    
        })

        $('a.pay').click(function(e) 
        {
            var url = $(this).attr('href')
            alertify.confirm('You Have Made Payment?',"Are you sure, you have made the Payment? .",
                  function(){
                    $.ajax({
                        url     :  url,
                        type    : 'get',
                        success : function(res)
                        {
                            
                              alertify.set('notifier','position', 'top-right');
                              alertify.success(res.success, 3, function(e)
                                {
                                  window.location = '{{ url('/home')}}'
                                });
                            
                        }, 
                        error   : function(res)
                        {
                            alertify.error('An error has occurred. Please Refresh Your Browser.')
                        }
                    })
                    
                  },
                  function(){
                    alertify.error('You have canceled the request. Please, read the available option');
            });
            e.preventDefault();
        })

        </script>

@endsection