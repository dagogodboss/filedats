@extends('layouts.user')

@section('content')



    <div class="main-panel">
         @include('./partials/topnav')

        <div  class="content">
        
        <div class="container-fluid">
                <div class="row">
                	<div class="col-md-4 col-md-offset-4 col-sm-12">
                        <div class="card">
                            <div class="header">
                            <h4 class="text-center text-muted plan title">New Message</h4>

                            <p class="category pull-right"><small><em>From {{ config('app.name')}} <i class="pe-7s-chat"></i></em></small></p>
                            
                            </div>
                            <div class="content text-justify">
                            <hr>
                               <p class="category">{{ $message->message}}</p>
                            <hr>
                            <div class="footer">
                                    <div class="legend">
                                        <a href="{{url('read_msg/'.$message->id)}}" class="read-msg btn btn-fill btn-success">I Have Read This Message </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>

        </div>
        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                   <ul>
                   <li>
                       <p><a href="#">Always Keep It in mind that we got your interest in heart</a></p>
                   </li>
                   </ul> 
                </nav>
                <p class="copyright pull-right">
                    &copy; 2017 <a href="">{{config('app.name', 'Larave')}} </a>, made with love for a better web
                </p>
            </div>
        </footer>
    </div>

    <script type="text/javascript">
        $('a.read-msg').click(function(e){
            e.preventDefault()

            var url = $(this).attr('href')

            $.ajax({
                url : url,
                type : 'get',
                success : function(res){
                    swal({
                              title: "Done",
                              text: res.success,
                              type: "success",
                            },
                                function(){
                                  location.reload(true)
                            })
                }
            })
        })
    </script>
@endsection