@extends('layouts.user')

@section('content')
	
		
		 <div class="main-panel">
         @include('./partials/topnav')

    		<div  class="content">
        		<div class="container-fluid">
        		<div class="row">
        			
        		@forelse($Ghers as $ghser)
                  <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                                <img src="{{ asset('img/background.jpg') }}" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                     <a href="#">
                                    <img class="avatar border-gray" src="{{ asset('img/faces/face.png') }}" alt="..."/>

                                      <h4 style="text-transform: capitalize;" class="title">Account Name: {{ $ghser->provider_user_name }}<br />
                                         <small>Phone: {{ $ghser->provider_user_phone }}</small>
                                      </h4>

                                      <h4 class="title">Bank: {{ $ghser->provider_user_bank_name }}<br />
                                         <small>Amount: {{ $ghser->provider_user_amount }}</small><br>
                                        <br>

                                      </h4>

                                    </a>
                                </div>
                                <p class="description text-center"> <h4 class="text-center text-muted">Account Number: "{{ $ghser->provider_user_account_number }}"</h4>
                                </p>
                                    <a href="{{url('/view/'.$ghser->provider_user_id.'/'.$ghser->sponsor_user_id)}}" class="btn-sm "> View Proof</a>
                            <hr>
                            <div class="text-center">
                            <a href="/confirm_payment/{{$ghser->provider_user_id}}" class="btn-sm btn btn-success"> Confirm Payment</a>
                         @include('partials.modals.upload_pop') 
                            <a href="/purge_payment/{{$ghser->provider_user_id}}" class="pull-right btn btn-danger btn-sm"> Purge Payment</a>

                            </div>
                            </div>
                        </div>
                    </div>
                     @empty
                     <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                                <img src="{{ asset('img/background.jpg') }}" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                     <a href="#">
                                    <img class="avatar border-gray" src="{{ asset('img/faces/face.png') }}" alt="..."/>

                                      <h4 class="title">Loading<br />
                                         <small>Check Back Later</small>
                                      </h4>
                                    </a>
                                </div>
                                <p class="description text-center"> Waiting to be Merge
                                </p>
                            </div>
                            <hr>
                            <div class="text-center">
                                <button href="#" class="btn btn-simple"><i class="fa fa-facebook-square"></i></button>
                                <button href="#" class="btn btn-simple"><i class="fa fa-twitter"></i></button>
                                <button href="#" class="btn btn-simple"><i class="fa fa-google-plus-square"></i></button>

                            </div>
                        </div>
                    </div>   
                @endforelse

        		</div>
        		</div>

        	</div>
        </div>

@endsection