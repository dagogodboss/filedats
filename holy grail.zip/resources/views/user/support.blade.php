@extends('layouts.user')

@section('content')


    
    <div class="main-panel">
         @include('./partials/topnav')
		    <div  class="content">	
		         <div class="container-fluid">
		           <div class="row">
		           	<div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Contact Support</h4>
                            </div>
                            <div class="content">
                                <form action="{{ url('/support') }}" method="post" role="form">
                                 {{ csrf_field() }}
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                            <input type="hidden" name="user_id" value="{{Auth::id()}}">
                                                <label>Message</label>
                                                <textarea style="min-height: 50vh" name="message" type="text" class="form-control" placeholder="Hello I want more Cash" ></textarea>
                                                
                                    			<span class="help-block">
                                        		<strong class="message"></strong>
                                   				</span>
                                				
                                    			<span class="help-block">
                                        		<strong class="user_id"></strong>
                                   				</span>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill">Send Message <big class="pe-7s-paper-plane"></big></button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                                <img src="{{ asset('img/sidebar-1.jpg') }}" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                     <a href="#">
                                    <img class="avatar border-gray" src="{{ asset('img/faces/face-0.jpg') }}" alt="..."/>

                                      <h4 class="title">Facebook group<br />
                                         <code><small>{{ config('app.facebook_group') }}</small></code> 
                                      </h4>
                                    </a>
                                </div>
                                <p class="description text-center"> 
                                Our Hot Line : <br>
                                "{{ config('app.phone') }}"
                                <h4 class="text-center title"><code>{{ config('app.telegram') }}</code><br />
                                         <small>Telegram</small>
                                      </h4>


                                <h4 class="text-center title"><code>{{ config('app.facebook_page') }}</code><br />
                                         <small>Facebook Page</small>
                                      </h4>
                                </p>
                            </div>
                            <hr>
                            <div class="text-center" style="padding: 7px;">
                                <big><em>Please always feel free to contact us at any time</em></big>

                            </div>
                        </div>
                    </div>



		           </div>
		        </div>
		    </div>
		@include('./partials/footer')
    </div>
    <script type="text/javascript">
            
            $('form').submit(function(e) {
                    $(".message").removeClass("has-error");
                    $('.message').html('');
                    $(".user_id").removeClass("has-error");
                    $('.user_id').html('');
                    
                    var $this = $(this)
                    swal({
                          title: "Thank You",
                          text: "Please wait while i submit your request to admin",
                          type: "success",
                        })
                e.preventDefault();

                $.ajax({

                        url        : $this.attr('action'),
                        type       : $this.attr('method'),
                        data       : $this.serialize(),
                        success    : function(res){
                            alertify.set('notifier','position', 'top-right');
                            alertify.success(res.success, 10);
                            $('textarea').val('')
                        },
                        error       : function(res)
                        {
                             var obj = jQuery.parseJSON(res.responseText);
                            alertify.set('notifier','position', 'bottom-left');
                            alertify.error('An error has Occured.', 10);
                            if(obj.message)
                            {
                                $(".message").addClass("has-error");
                                $('.message').html(obj.message);
                            }
                           
                            if(obj.user_id)
                            {
                                $(".user_id").addClass("has-error");
                                $('.user_id').html(obj.user_id);
                            }
                        }

                })

            })

    </script>
 @endsection