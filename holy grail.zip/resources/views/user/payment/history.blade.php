@extends('layouts.user')

@section('content')
    
    <style type="text/css">

        .card {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        text-align: center;
        margin-top:5px;
        margin-left: 4px;
        }

        .container {
            padding: 0 16px;
        }

        .title {
            color: grey;
        }
        button:hover, a:hover {
            opacity: 0.7;
        }
        .social{
            font-size: 2em;
            color: inherit;
        }
    </style>
        
    <div class="main-panel">
         @include('./partials/topnav')

    <div  class="content">
        <div class="container-fluid">
                <div class="row">  
                    
                <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Paid Transaction</h4>
                                <p class="category"></p>
                            </div>
                            <div  class="content table-responsive">
                                <table id="adminListTable" cellspacing="0" width="100%" class="display table table-striped table-hover">
                                    <thead>
                                        <th>Name</th>
                                        <th>Bank Name</th>
                                        <th>Acc Number</th>
                                        <th>Amount</th>
                                    </thead>
                                    <tbody>
                                        @if(isset($paid))
                                        @forelse($paid as $paid_details)
                                        @php
                                            if($paid_details != null):
                                            $data = \App\User::find($paid_details->r_user);
                                            endif
                                        @endphp
                                        <tr>
                                            <td>@if($data != null){{ $data->name}} @endif</td>
                                            <td>@if($data != null){{ $data->bank_name}} @endif</td>
                                            <td>@if($data != null){{ $data->account_number}} @endif</td>
                                            <td>{{ $paid_details->amount}} </td>
                                            
                                        </tr>
                                        <tr>Total</tr>
                                        @empty
                                        <tr>No Data Available</tr>
                                        @endforelse
                                        @endif
                                    </tbody>
                                </table>

                            </div>

                        </div>
                        
                    </div>

                    <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Receive Transaction</h4>
                                <p class="category"></p>
                            </div>
                            <div  class="content table-responsive">
                                <table id="adminListTable" cellspacing="0" width="100%" class="display table table-striped table-hover">
                                    <thead>
                                        <th>Name</th>
                                        <th>Bank Name</th>
                                        <th>Acc Number</th>
                                        <th>Amount</th>
                                    </thead>
                                    <tbody>
                                        @if(isset($receive))
                                        @forelse($receive as $paid_details)
                                        @php
                                            if($paid_details != null):
                                            $data = \App\User::find($paid_details->p_user);
                                            endif
                                        @endphp
                                        <tr>
                                            <td>@if($data != null){{ $data->name}} @endif</td>
                                            <td>@if($data != null){{ $data->bank_name}} @endif</td>
                                            <td>@if($data != null){{ $data->account_number}} @endif</td>
                                            <td>{{ $paid_details->amount}} </td>
                                            
                                        </tr>
                                        <tr>Total</tr>
                                        @empty
                                        <tr>No Data Available</tr>
                                        @endforelse
                                        @endif
                                    </tbody>
                                </table>

                            </div>

                        </div>
                        
                    </div>



                    </div>
                </div>
            </div>
            </div>

@endsection