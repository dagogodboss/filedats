@extends('layouts.landing')

@section('content')

            <ul class="cd-radial-slider" data-radius1="60" data-radius2="1364" data-centerx1="110" data-centerx2="1290">
                <li class="visible">
                    <div class="svg-wrapper">
                        <svg viewBox="0 0 1400 800">
                            <title>Animated SVG</title>
                            <defs>
                                <clipPath id="cd-image-1">
                                    <circle id="cd-circle-1" cx="110" cy="400" r="1364"/>
                                </clipPath>
                            </defs>
                            <image  height='800px' width="1400px" clip-path="url(#cd-image-1)" xlink:href="images/02.jpg"></image>
                        </svg>
                    </div> <!-- .svg-wrapper -->
                    <div class="cd-radial-slider-content">
                        <div  class="wrapper">
                            <div>
                                <h2>Welcome to <span>  {{config('app.name',  'Laravel' )}}</span> </h2>
                            @if (Auth::guest())
                                <a href="{{ route('login') }}" class="w3ls-btn button8 ">LOG IN </a>
                                <a href="{{ route('register') }}" class="w3ls-btn button8">REGISTER NOW </a>
                            @else
                                <a href="{{ url('/home') }}" class="w3ls-btn button8">My Office </a>
                            @endif
                            </div>
                        </div>
                    </div> <!-- .cd-radial-slider-content -->
                </li>
            </ul>
        </div> <!-- .cd-radial-slider-wrapper -->
    </div>
    <!-- //banner -->
    <!-- about -->
    <div class="about" id="about">
        <div class="container">
            <div class="agileits-title">
                <div class="col-md-6 agileits-title-left">
                    <h6>- Welcome to</h6>
                    <h3>Our {{ config('app.name', 'Laravel') }}</h3>
                </div>
                <div class="col-md-6 agileits-title-right">
                    <p>Our platform warmly welcomes all individuals globally from 18 years and above with the intention to fulfill their dreams.</p>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="about-w3lsrow">
                <div class="col-md-7 col-sm-7 w3about-img">
                    <div class="w3about-text">
                        <h5 class="w3l-subtitle">- About Us</h5>
                        <p>{{config('app.name')}}  is an on line donation exchange and social network, a global platform to connect users with access to Internet and a minimum of 5000 Naira or more qualify to earn an incentive of (40%) percentage from 12 hrs to 24 hours based on first come first to be listed on the donation list. The system is designed based on latest technology with peer to peer concept. <br><br>

                        When you join {{config('app.name')}}  and contribute 5000 Naira or more, you become an active member and your life begins to change for better with the privilege of affording to a basic living, might be a holiday trip, a loan, finishing house bond amongst other benefits.<br><br>

                         </p>
                    </div>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <!-- //about -->
    <!-- services -->
    <div class="about services" id="services">
        <div class="container">
            <div class="agileits-title">
                <div class="col-md-6 agileits-title-left">
                    <h6>- What we do</h6>
                    <h3>Our Services</h3>
                </div>
                <div class="col-md-6 agileits-title-right">
                    <p></p>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="services-w3ls-row">
                <div class="col-md-3 col-sm-3 col-xs-6 services-grids">
                    <div class="w3agile-servs-img">
                        <div class="icon-holder">
                            <span class="fa fa-gears icon" aria-hidden="true"></span>
                        </div>
                        <h4 class="mission">Register</h4>
                        <p class="description">Register your account and start earning</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6 services-grids">
                    <div class="w3agile-servs-img">
                        <div class="icon-holder">
                            <span class="fa fa-group icon" aria-hidden="true"></span>
                        </div>
                        <h4 class="mission">Choose A plan </h4>
                        <p class="description">From our various plans and get your 40% Return 5 days</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6 services-grids">
                    <div class="w3agile-servs-img">
                        <div class="icon-holder">
                            <span class="fa fa-briefcase icon" aria-hidden="true"></span>
                        </div>
                        <h4 class="mission">Refeeral System</h4>
                        <p class="description">Refeer others and make cool cash from talking about us to others</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6 services-grids">
                    <div class="w3agile-servs-img">
                        <div class="icon-holder">
                            <span class="fa fa-list-alt icon" aria-hidden="true"></span>
                        </div>
                        <h4 class="mission">Recommitment is A must</h4>
                        <p class="description">To Prevent Cyber Beggers and Hit and Run User You Must Pay 50% of Your Donation to Continue using the system</p>
                    </div>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <!-- //services -->
    <!-- features -->
    <div class="features">
        <div class="tabs w3-agileits-tabs">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li class="active"><a href="#home" aria-controls="home" data-toggle="tab"><span>Question 1</span></a></li>
                <li><a href="#profile" aria-controls="profile" data-toggle="tab"><span>Question 2</span></a></li>
                <li><a href="#messages" aria-controls="messages" data-toggle="tab"><span>Question 3</span></a></li>
                <li><a href="#settings" aria-controls="settings" data-toggle="tab"><span>Question 4</span></a></li>
            </ul>
            <!-- Tab panes -->
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="home">
                    <div class="col-md-6 features-right">
                        <div class="agileits-title">
                            <h6>- Frequently Ask Question</h6>
                            <h3> Is this a HIYP </h3>
                        </div>
                        <p>No it isn't </p>
                    </div>
                    <div class="col-md-6 features-left agileinfo-img">

                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div role="tabpanel" class="tab-pane" id="profile">
                    <div class="col-md-6 features-right">
                        <div class="agileits-title">
                            <h6>- Our Features</h6>
                            <h3>What Plan Do you Have </h3>
                        </div>
                        <p>Our Plans ranges from 5,000 to 100,000 and it is still loading  </p>
                    </div>
                    <div class="col-md-6 features-left agileinfo-img2">

                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div role="tabpanel" class="tab-pane" id="messages">
                    <div class="col-md-6 features-right w3-agile">
                        <div class="agileits-title">
                            <h6>- Our Features</h6>
                            <h3>How do I get Mached</h3>
                        </div>
                        <p>The program runs through its Database and get a Sponsor to pay in no time</p>
                    </div>
                    <div class="col-md-6 features-left agileinfo-img3">

                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div role="tabpanel" class="tab-pane" id="settings">
                    <div class="col-md-6 features-right">
                        <div class="agileits-title">
                            <h6>- Our Features</h6>
                            <h3> can I make many Investment </h3>
                        </div>
                        <p>Yes! as you can </p>
                    </div>
                    <div class="col-md-6 features-left agileinfo-img4">

                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div><!-- /tabs -->
    </div>
    <!-- //features -->
    <!-- team -->

    <!-- //team -->
    <!-- gallery -->
    <div id="gallery" class="gallery">
        <div class="container">
            <div class="agileits-title">
                <div class="col-md-6 agileits-title-left">
                    <h6>- Our Sky Lifted</h6>
                    <h3>Investment Plan</h3>
                </div>
                <div class="col-md-6 agileits-title-right">
                    <p>A list of our investment plan</p>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
        <div class="agileinfo-gallery-row">
            <div class="col-md-3 col-sm-3 col-xs-6 w3gallery-grids">
                <a href="images/img4.jpg" class="imghvr-hinge-right figure">
                    <img src="images/img4.jpg" alt="" title="Smart Buzz Image"/>
                    <div class="agile-figcaption">
                      <h4>Super Diamond</h4>
                      <p>Loading</p>
                    </div>
                </a>
            </div>

            <div class="clearfix"> </div>
            <script type="text/javascript" src="js/simple-lightbox.min.js"></script>
            <script>
                $(function(){
                    var gallery = $('.agileinfo-gallery-row a').simpleLightbox({navText:        ['&lsaquo;','&rsaquo;']});
                });
            </script>
        </div>
    </div>
    <!-- //gallery -->
    <!-- contact -->
    <div id="contact" class="contact">
        <div class="container">
            <div class="agileits-title">
                <div class="col-md-6 agileits-title-left">
                    <h6>-Write a message</h6>
                    <h3>Contact Us</h3>
                </div>
                <div class="col-md-6 agileits-title-right">
                    <p>Have an issue just contact us</p>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="contact-w3ls-row">
                <form action="#" method="post">
                    <div class="col-md-5 col-sm-5 contact-right agileits-w3layouts">
                        <textarea name="Message" placeholder="Message" required=""></textarea>
                    </div>
                    <div class="col-md-7 col-sm-7 contact-left agileits-w3layouts">
                        <input type="text" name="First Name" placeholder="First Name" required="">
                        <input class="email" name="Last Name" type="text" placeholder="Last Name" required="">
                        <input type="text" name="Number" placeholder="Mobile Number" required="">
                        <input class="email" name="Email" type="text" placeholder="Email" required="">
                        <input type="submit" value="SUBMIT">
                    </div>
                    <div class="clearfix"> </div>
                </form>
            </div>
        </div>
    </div>
    <!-- //contact -->
    <!-- address -->
    <div class="address w3layouts-address">
        <div class="col-md-6 address-left">
            <div class="agileits-title">
                <h6>- Get in </h6>
                <h3>Touch</h3>
            </div>
            <ul>
                <li><i class="fa fa-map-marker"></i> Lagos , Nigeria.</li>
                <li><i class="fa fa-mobile"></i> 09038020670</li>
                <li><i class="fa fa-phone"></i> +234 9038020670 </li>
                <li><i class="fa fa-envelope-o"></i> <a href="mailto:example@mail.com"> mail@example.com</a></li>
            </ul>
        </div>
        <div class="col-md-6 address-right">
        </div>
        <div class="clearfix"> </div>
    </div>
    <!-- //address -->
    <!-- subscribe -->
    <!-- //subscribe -->

@endsection
